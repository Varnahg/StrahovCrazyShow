// Explicit isolated GREEN process only. Never imported by portable repository tests.
import fs from'node:fs';import path from'node:path';import{registerHooks}from'node:module';import{fileURLToPath}from'node:url';
const file=process.env.NATIVE_SHADOW_CORE_MODULE,selected=process.env.NATIVE_SHADOW_PAYLOAD;
if(!file||!selected)throw Error('Explicit isolated overlay paths required');const target=fs.realpathSync(file).replaceAll('\\','/'),source=fs.readFileSync(selected,'utf8');
registerHooks({load(url,context,next){if(url.startsWith('file:')&&fileURLToPath(url).replaceAll('\\','/')===target)return{format:'module',source,shortCircuit:true};return next(url,context);}});
