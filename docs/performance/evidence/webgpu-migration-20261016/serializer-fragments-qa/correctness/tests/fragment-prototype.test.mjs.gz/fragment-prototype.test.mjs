import test from'node:test';import assert from'node:assert/strict';import{pathToFileURL}from'node:url';
const C=(await import(pathToFileURL(process.env.FRAGMENT_PAYLOAD))).MaterialDefines;
test('Neemitovaný index nevytvoří čtení/zápis zděděného prototype getter/setter',()=>{
 const d=new C();d._keys=['Z','OMITTED','A'];d.Z=true;d.OMITTED=false;d.A=2;const expected=d.toString();assert.equal(expected,'#define A 2\n#define Z\n');
 const prior=Object.getOwnPropertyDescriptor(Object.prototype,'1');let reads=0,writes=0,result,error;
 try {Object.defineProperty(Object.prototype,'1',{configurable:true,get(){reads++;return'#define POISON\n';},set(){writes++;}});try{result=d.toString();}catch(e){error=e;}}
 finally{if(prior)Object.defineProperty(Object.prototype,'1',prior);else delete Object.prototype[1];}
 assert.equal(error,undefined);assert.equal(result,expected);assert.equal(reads,0);assert.equal(writes,0);
});
