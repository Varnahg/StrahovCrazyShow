# Systémový GPU záznam

Vzorků: 20.

- NVIDIA GeForce GTX 1060: GPU maximum 0 %, VRAM maximum 300 / 6144 MiB; začátek/konec 300 / 300 MiB.

Identit procesů: 218. Herních relací: 3.

Režie samotného loggeru: maximum včetněstartup 85.7657861753537 % jednoho logického CPU; ustálené maximum 4.3903848744848615 % (5 steadyvzorků).

- Per-process GPU paměť se nesčítá do fyzické VRAM; sdílené alokace se počítají vícekrát.

- GPU engine utilization perPID je maximum, nikoli součet paralelních enginů.

- CPU walltime herního snímku zahrnuje preempci a synchronní čekání; není procesorový CPUtime.

- Sekundové čítače a querybrackets neurčují přesnou příčinu krátkého záseku; driver vyžaduje stack/scheduler trace.

- Browser GPU proces může obsluhovat více karet; herní log neobsahuje PID.

- UTC kotva hry nemá korekci pozdější změny systémových hodin.
