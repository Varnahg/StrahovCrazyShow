$ErrorActionPreference = 'Stop'
$scriptPath = Join-Path $PSScriptRoot '../../scripts/capture-system-gpu.ps1'
$tokens = $null; $errors = $null
$tree = [Management.Automation.Language.Parser]::ParseFile([IO.Path]::GetFullPath($scriptPath), [ref]$tokens, [ref]$errors)
if ($errors.Count) { throw 'collector parse failed' }
foreach ($node in $tree.FindAll({ param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] }, $false)) {
    Invoke-Expression $node.Extent.Text
}
$checks = [Collections.Generic.List[string]]::new()
function Check([bool]$condition, [string]$label) { if (-not $condition) { throw $label }; [void]$checks.Add($label) }
Check ($null -eq (Numeric 'N/A')) 'unknown numeric stays null'
Check ((Numeric '0') -eq 0) 'observed zero stays zero'
Check ((Numeric '1.25') -eq 1.25) 'invariant decimal parses'
$identity = InstanceIdentity 'pid_123_luid_0x00000000_0x0001_phys_0_eng_2_engtype_3D'
Check ($identity.pid -eq 123 -and $identity.engine -eq 2 -and $identity.engineType -eq '3D') 'PID engine instance parsed'
$adapter = InstanceIdentity 'luid_0x00000000_0x0001_phys_1'
Check ($adapter.physicalAdapter -eq 1 -and $null -eq $adapter.pid) 'adapter identity has no fabricated PID'
Check ($null -eq (InstanceIdentity 'unrecognized').pid) 'unknown instance has unknown PID'
$private = [pscustomobject]@{Name='msedge.exe';CommandLine='msedge --type=renderer https://private.invalid/secret --profile-directory=private'}
Check ((BrowserRole $private) -eq 'renderer') 'browser arguments reduce to fixed role enum'
Check ((BrowserRole ([pscustomobject]@{Name='msedge.exe';CommandLine=$null})) -eq 'unknown') 'unavailable command line is unknown role'
$script:cleanupErrors = [Collections.Generic.List[object]]::new()
$script:stops = 0
$date = [DateTime]::Parse('2026-10-19T10:00:00Z').ToUniversalTime()
function Get-Process { param($Id,$ErrorAction) return [pscustomobject]@{StartTime=$date.AddSeconds(1);Path='C:\fake\nvidia-smi.exe'} }
function Stop-Process { param($InputObject,[switch]$Force) $script:stops++ }
StopOwnedChild @{process=[pscustomobject]@{HasExited=$false};identity=@{pid=123;startTicks=[string]$date.Ticks;path='C:\fake\nvidia-smi.exe'}}
Check ($script:stops -eq 0 -and $script:cleanupErrors.Count -eq 1) 'PID reuse refuses cleanup kill'
$script:cleanupErrors.Clear()
StopOwnedChild @{process=[pscustomobject]@{HasExited=$true};identity=@{pid=123;startTicks=[string]$date.Ticks;path='C:\fake\nvidia-smi.exe'}}
Check ($script:cleanupErrors.Count -eq 0 -and $script:stops -eq 0) 'already-exited helper never follows reused PID'
function Get-CimInstance { param($ClassName,$OperationTimeoutSec,$Filter,$Property) throw [InvalidOperationException]::new('test provider unavailable') }
$rowLimit=4096
$provider=ReadGpuCim 'GPUEngine' 'engine'
Check ($provider.status -eq 'unavailable' -and $provider.rows.Count -eq 0 -and $null -ne $provider.error) 'missing GPU provider is error not utilization zero'
$clock=[pscustomobject]@{Elapsed=[pscustomobject]@{TotalMilliseconds=2000.0}}
$logicalProcessors=4
$script:previousProcesses=@{}
$script:fakeProcesses=@([pscustomobject]@{ProcessId=123;Name='msedge.exe';CreationDate=$date;CommandLine='msedge --type=gpu-process secret';UserModeTime=[uint64]10000000;KernelModeTime=[uint64]0})
function Get-CimInstance { param($ClassName,$OperationTimeoutSec,$Filter,$Property) return $script:fakeProcesses }
$engineProvider=@{rows=@(@{pid=123})};$memoryProvider=@{rows=@()}
$first=ReadProcesses $engineProvider $memoryProvider
$initial=@($first.rows | Where-Object pid -eq 123)[0]
Check ($null -eq $initial.cpuUserOneCorePercent) 'first process CPU delta is unknown'
$clock.Elapsed.TotalMilliseconds=3000.0;$script:fakeProcesses[0].UserModeTime=[uint64]20000000
$second=ReadProcesses $engineProvider $memoryProvider
$cpu=@($second.rows | Where-Object pid -eq 123)[0]
Check ($cpu.cpuUserOneCorePercent -eq 100 -and $cpu.cpuSystemNormalizedPercent -eq 25) '100ns delta yields one-core100 and separate system25'
Check ((ConvertTo-Json $second -Depth 8) -notmatch 'secret|CommandLine') 'export contains no full browser arguments'
$clock.Elapsed.TotalMilliseconds=4000.0;$script:fakeProcesses[0].CreationDate=$date.AddSeconds(5)
$reused=ReadProcesses $engineProvider $memoryProvider
Check ($null -eq @($reused.rows | Where-Object pid -eq 123)[0].cpuUserOneCorePercent) 'PID reuse cannot inherit previous CPU delta'
$result=@{passed=$checks.Count;failed=0;checks=@($checks.ToArray());scope='Pure helpers and mocked provider/process identity fault paths, no OS sampling'}
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'function-results.json'),(ConvertTo-Json $result -Depth 5))
$result | ConvertTo-Json -Depth 5
