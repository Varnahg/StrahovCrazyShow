$ErrorActionPreference='Stop'
$source=[IO.File]::ReadAllText([IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../scripts/capture-system-gpu.ps1')))
$tokens=$null;$errors=$null
[void][Management.Automation.Language.Parser]::ParseInput($source,[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'PowerShell parse failed'}
$match=[regex]::Match($source,"(?s)Add-Type -TypeDefinition @'\r?\n(?<native>.*?)\r?\n'@")
if(-not $match.Success){throw 'Native source missing'}
Add-Type -TypeDefinition $match.Groups['native'].Value
$item=[StrahovExternalPdh].GetNestedType('Item',[Reflection.BindingFlags]::NonPublic)
$value=[StrahovExternalPdh].GetNestedType('Value',[Reflection.BindingFlags]::NonPublic)
Add-Type -TypeDefinition 'public static class StrahovPdhLayoutProbe { public static int Size(System.Type t) { return System.Runtime.InteropServices.Marshal.SizeOf(t); } }'
$sizes=@{item=[StrahovPdhLayoutProbe]::Size($item);value=[StrahovPdhLayoutProbe]::Size($value)}
if($sizes.item -ne 24 -or $sizes.value -ne 16){throw 'Unexpected PDH marshalling layout'}
$result=@{powershellParse='pass';nativeCompile='pass';layout=$sizes;scope='Compile and native structure layout only; no PDH calls/provider query/constructor or OS samples'}
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'native-check.json'),(ConvertTo-Json $result -Depth 4))
$result | ConvertTo-Json -Depth 4
