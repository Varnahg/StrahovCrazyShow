[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$OutputDirectory,
    [ValidateRange(1, 3600)][int]$DurationSeconds = 1200,
    [ValidateRange(1, 60)][double]$IntervalSeconds = 1,
    [string]$StopFile,
    [ValidateRange(0, 3600)][int]$MaxSamples = 0
)

# External read-only telemetry. Never changes clocks, drivers, game or browser.
$ErrorActionPreference = 'Stop'
$outputPath = [IO.Path]::GetFullPath($OutputDirectory)
[void][IO.Directory]::CreateDirectory($outputPath)
$samplePath = Join-Path $outputPath 'samples.jsonl'
$runtimePath = Join-Path $outputPath 'runtime.json'
if ((Test-Path -LiteralPath $samplePath) -or (Test-Path -LiteralPath $runtimePath)) {
    throw 'Output already contains samples.jsonl or runtime.json; choose a fresh directory.'
}
if (-not $StopFile) { $StopFile = Join-Path $outputPath 'STOP' }
elseif (-not [IO.Path]::IsPathRooted($StopFile)) { $StopFile = Join-Path $outputPath $StopFile }
$stopPath = [IO.Path]::GetFullPath($StopFile)
if (-not $stopPath.StartsWith($outputPath.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) {
    throw 'StopFile must be inside OutputDirectory.'
}
$clock = [Diagnostics.Stopwatch]::StartNew()
$logicalProcessors = [Environment]::ProcessorCount
$selfProcess = Get-Process -Id $PID
$selfIdentity = @{ pid = $PID; startUtc = $selfProcess.StartTime.ToUniversalTime().ToString('o'); path = $selfProcess.Path }
$script:children = [Collections.Generic.List[object]]::new()
$script:cleanupErrors = [Collections.Generic.List[object]]::new()
$script:previousProcesses = @{}
$script:nvidiaRows = @{}
$script:nvidiaPending = ''
$script:nvidiaReader = $null
$script:nvidiaProcess = $null
$script:nvidiaFields = @()
$script:nvidiaMissing = @()
$script:nvidiaError = $null
$script:nvidiaLastReadUtc = $null
$jsonStream = [IO.FileStream]::new($samplePath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::Read)
$writer = [IO.StreamWriter]::new($jsonStream, [Text.UTF8Encoding]::new($false))
$writer.AutoFlush = $true
$outputLimitBytes = 134217728
$rowLimit = 4096

function Utc { [DateTime]::UtcNow.ToString('o') }
function Field($object, [string]$name) {
    if ($null -eq $object) { return $null }
    $property = $object.PSObject.Properties[$name]
    if ($null -ne $property) { return $property.Value }
    return $null
}
function Numeric($value) {
    if ($null -eq $value) { return $null }
    $parsed = 0.0
    if ([double]::TryParse([string]$value, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$parsed) -and
        -not [double]::IsNaN($parsed) -and -not [double]::IsInfinity($parsed)) { return $parsed }
    return $null
}
function ErrorFact([string]$provider, $errorRecord) {
    # No command line, invocation source, credentials or arbitrary stderr.
    return @{ provider = $provider; category = [string]$errorRecord.CategoryInfo.Category; exceptionType = $errorRecord.Exception.GetType().FullName; hresult = $errorRecord.Exception.HResult }
}
function WriteRecord($record) {
    $line = ConvertTo-Json -InputObject $record -Depth 12 -Compress
    if ($jsonStream.Position + [Text.Encoding]::UTF8.GetByteCount($line) + 2 -gt $outputLimitBytes -and $record.recordType -eq 'sample') { return $false }
    $writer.WriteLine($line)
    return $true
}
function ChildIdentity($process) {
    $process.Refresh()
    return @{ pid = $process.Id; startTicks = [string]$process.StartTime.ToUniversalTime().Ticks; startUtc = $process.StartTime.ToUniversalTime().ToString('o'); path = $process.Path }
}
function StopOwnedChild($entry) {
    try {
        if ($entry.process.HasExited) { return }
        $current = Get-Process -Id $entry.identity.pid -ErrorAction SilentlyContinue
        if ($null -eq $current) { return }
        $matches = ([string]$current.StartTime.ToUniversalTime().Ticks -eq $entry.identity.startTicks) -and
            [string]::Equals($current.Path, $entry.identity.path, [StringComparison]::OrdinalIgnoreCase)
        if ($matches) { Stop-Process -InputObject $current -Force; [void]$current.WaitForExit(2000) }
        else { [void]$script:cleanupErrors.Add(@{ provider = 'child-cleanup'; reason = 'identity-mismatch'; pid = $entry.identity.pid }) }
    } catch { [void]$script:cleanupErrors.Add((ErrorFact 'child-cleanup' $_)) }
}
function StartOwnedChild([string]$executable, [string[]]$arguments, [string]$label) {
    $stdout = Join-Path $outputPath ($label + '.stdout.txt')
    $stderr = Join-Path $outputPath ($label + '.stderr.txt')
    if ((Test-Path -LiteralPath $stdout) -or (Test-Path -LiteralPath $stderr)) { throw 'Auxiliary output already exists.' }
    $process = Start-Process -FilePath $executable -ArgumentList $arguments -WindowStyle Hidden -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr
    try { $identity = ChildIdentity $process }
    catch {
        # Retain the Process handle from this exact Start-Process, never look up
        # and kill a PID whose start/path ownership was not established.
        try { if (-not $process.HasExited) { $process.Kill(); [void]$process.WaitForExit(2000) } } catch { }
        throw
    }
    $entry = @{ process = $process; identity = $identity; stdout = $stdout; stderr = $stderr; label = $label }
    [void]$script:children.Add($entry)
    return $entry
}
function InitializeNvidia {
    $command = Get-Command nvidia-smi.exe -ErrorAction SilentlyContinue
    if (-not $command) { $script:nvidiaError = @{ reason = 'executable-unavailable' }; return }
    try {
        $help = StartOwnedChild $command.Source @('--help-query-gpu') 'nvidia-help'
        if (-not $help.process.WaitForExit(3000)) { StopOwnedChild $help; throw 'NVIDIA help timed out.' }
        if ($help.process.ExitCode -ne 0) { throw 'NVIDIA help failed.' }
        $helpText = [IO.File]::ReadAllText($help.stdout)
        $definitions = @(
            @('index','index','number'), @('uuid','uuid','text'), @('name','name','text'), @('timestamp','driverTimestampRaw','text'),
            @('utilization.gpu','utilGpuPercent','number'), @('utilization.memory','utilMemoryPercent','number'),
            @('memory.used','memoryUsedMiB','number'), @('memory.total','memoryTotalMiB','number'),
            @('clocks.current.graphics','graphicsMHz','number'), @('clocks.current.memory','memoryMHz','number'),
            @('temperature.gpu','tempC','number'), @('power.draw','powerW','number'), @('pstate','pstate','text'),
            @('clocks_event_reasons.active','throttleRaw','text'), @('clocks_event_reasons.gpu_idle','gpuIdleRaw','text'),
            @('clocks_event_reasons.sw_power_cap','swPowerCapRaw','text'), @('clocks_event_reasons.sw_thermal_slowdown','swThermalRaw','text'),
            @('clocks_event_reasons.hw_thermal_slowdown','hwThermalRaw','text'), @('clocks_event_reasons.hw_power_brake_slowdown','hwPowerBrakeRaw','text')
        )
        foreach ($definition in $definitions) {
            $query = $definition[0]
            if ($helpText -notmatch ('"' + [regex]::Escape($query) + '"') -and $query.StartsWith('clocks_event_reasons.')) {
                $query = $query.Replace('clocks_event_reasons.', 'clocks_throttle_reasons.')
            }
            if ($helpText -match ('"' + [regex]::Escape($query) + '"')) {
                $script:nvidiaFields += ,@{ query = $query; name = $definition[1]; type = $definition[2] }
            } else { $script:nvidiaMissing += $definition[1] }
        }
        if ($script:nvidiaFields.Count -eq 0) { throw 'No recognized NVIDIA fields.' }
        $queryArgument = '--query-gpu=' + (($script:nvidiaFields | ForEach-Object { $_.query }) -join ',')
        $milliseconds = [int][Math]::Round($IntervalSeconds * 1000)
        $script:nvidiaProcess = StartOwnedChild $command.Source @($queryArgument, '--format=csv,noheader,nounits', '--loop-ms=' + $milliseconds) 'nvidia'
        $script:nvidiaReader = [IO.FileStream]::new($script:nvidiaProcess.stdout, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
    } catch { $script:nvidiaError = ErrorFact 'nvidia' $_ }
}
function ReadNvidia {
    $startedUtc = Utc
    $errors = [Collections.Generic.List[object]]::new()
    if ($script:nvidiaReader) {
        try {
            $buffer = [byte[]]::new(65536)
            $read = $script:nvidiaReader.Read($buffer, 0, $buffer.Length)
            if ($read -gt 0) {
                $script:nvidiaLastReadUtc = Utc
                $script:nvidiaPending += [Text.Encoding]::UTF8.GetString($buffer, 0, $read)
                $lines = $script:nvidiaPending -split "`n"
                $script:nvidiaPending = $lines[-1]
                if ($script:nvidiaPending.Length -gt 8192) { $script:nvidiaPending = ''; [void]$errors.Add(@{ reason = 'oversized-line' }) }
                for ($lineIndex = 0; $lineIndex -lt $lines.Count - 1; $lineIndex++) {
                    $line = $lines[$lineIndex].Trim()
                    if (-not $line) { continue }
                    $headers = @($script:nvidiaFields | ForEach-Object { $_.name })
                    $csv = $line | ConvertFrom-Csv -Header $headers
                    $row = @{ receivedUtc = $script:nvidiaLastReadUtc; missingFields = @($script:nvidiaMissing) }
                    foreach ($field in $script:nvidiaFields) {
                        $raw = [string](Field $csv $field.name)
                        $raw = $raw.Trim()
                        if (-not $raw -or $raw -match '^(?:\[?N/A\]?|Not Supported|Unknown Error)$') { $row[$field.name] = $null; $row.missingFields += $field.name }
                        elseif ($field.type -eq 'number') { $row[$field.name] = Numeric $raw; if ($null -eq $row[$field.name]) { $row.missingFields += $field.name } }
                        else { $row[$field.name] = $raw.Substring(0, [Math]::Min(200, $raw.Length)) }
                    }
                    if ($null -ne $row.index) { $script:nvidiaRows[[string]$row.index] = $row }
                    else { [void]$errors.Add(@{ reason = 'unrecognized-output-line' }) }
                }
            }
        } catch { [void]$errors.Add((ErrorFact 'nvidia-read' $_)) }
    }
    $status = 'ok'
    if ($script:nvidiaError) { $status = 'unavailable'; [void]$errors.Add($script:nvidiaError) }
    elseif (-not $script:nvidiaRows.Count) { $status = 'pending' }
    if ($script:nvidiaProcess) {
        $script:nvidiaProcess.process.Refresh()
        if ($script:nvidiaProcess.process.HasExited) { $status = 'exited'; [void]$errors.Add(@{ reason = 'child-exited'; exitCode = $script:nvidiaProcess.process.ExitCode }) }
    }
    return @{ status = $status; startedUtc = $startedUtc; endedUtc = Utc; rows = @($script:nvidiaRows.Values); errors = @($errors.ToArray()); latestRowReceivedUtc = $script:nvidiaLastReadUtc; missingFields = @($script:nvidiaMissing); sampleWindow = 'NVIDIA driver window, not collector interval; rows retain receivedUtc/driverTimestampRaw and may be stale' }
}
function InstanceIdentity([string]$name) {
    $identity = @{ instance = $name.Substring(0, [Math]::Min(256, $name.Length)); pid = $null; luid = $null; physicalAdapter = $null; engine = $null; engineType = $null }
    if ($name -match '^pid_(\d+)_luid_(0x[0-9a-f]+)_(0x[0-9a-f]+)_phys_(\d+)(?:_eng_(\d+)_engtype_(.+))?$') {
        $identity.pid = [int]$Matches[1]; $identity.luid = $Matches[2] + '_' + $Matches[3]; $identity.physicalAdapter = [int]$Matches[4]
        if ($Matches[5]) { $identity.engine = [int]$Matches[5]; $identity.engineType = $Matches[6] }
    } elseif ($name -match '^luid_(0x[0-9a-f]+)_(0x[0-9a-f]+)_phys_(\d+)$') {
        $identity.luid = $Matches[1] + '_' + $Matches[2]; $identity.physicalAdapter = [int]$Matches[3]
    }
    return $identity
}
function ReadGpuCim([string]$suffix, [string]$kind) {
    $startedUtc = Utc
    try {
        $raw = @(Get-CimInstance -ClassName ('Win32_PerfFormattedData_GPUPerformanceCounters_' + $suffix) -OperationTimeoutSec 2)
        $rows = [Collections.Generic.List[object]]::new()
        foreach ($item in $raw | Select-Object -First $rowLimit) {
            $row = InstanceIdentity ([string]$item.Name)
            $row.missingFields = @()
            foreach ($pair in @(@('Timestamp_Sys100NS','timestampSys100ns'), @('Frequency_Sys100NS','frequencySys100ns'))) {
                $value = Field $item $pair[0]
                $row[$pair[1]] = if ($null -ne $value) { [string]$value } else { $null }
                if ($null -eq $value) { $row.missingFields += $pair[1] }
            }
            $fields = if ($kind -eq 'engine') { @{ UtilizationPercentage = 'utilizationPercent' } }
                else { @{ DedicatedUsage = 'dedicatedBytes'; SharedUsage = 'sharedBytes'; TotalCommitted = 'committedBytes' } }
            if ($kind -eq 'process-memory') { $fields.LocalUsage = 'localBytes'; $fields.NonLocalUsage = 'nonLocalBytes' }
            foreach ($key in $fields.Keys) { $row[$fields[$key]] = Numeric (Field $item $key); if ($null -eq $row[$fields[$key]]) { $row.missingFields += $fields[$key] } }
            [void]$rows.Add($row)
        }
        return @{ status = 'ok'; startedUtc = $startedUtc; endedUtc = Utc; rows = @($rows.ToArray()); error = $null; omitted = [Math]::Max(0, $raw.Count - $rowLimit); provider = 'CIM formatted GPUPerformanceCounters'; sampleWindow = 'Windows provider formatted interval; integer utilization is not instantaneous or the collector period' }
    } catch { return @{ status = 'unavailable'; startedUtc = $startedUtc; endedUtc = Utc; rows = @(); error = ErrorFact ('cim-' + $suffix) $_; omitted = 0 } }
}
function ReadSystemCpu {
    $startedUtc = Utc
    try {
        $raw = Get-CimInstance -ClassName Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'" -OperationTimeoutSec 2
        if ($null -eq $raw) { throw 'CPU total instance unavailable.' }
        return @{ status = 'ok'; startedUtc = $startedUtc; endedUtc = Utc; rows = @(@{ instance = '_Total'; cpuPercent = Numeric $raw.PercentProcessorTime; dpcPercent = Numeric $raw.PercentDPCTime; interruptPercent = Numeric $raw.PercentInterruptTime; timestampSys100ns = [string]$raw.Timestamp_Sys100NS; frequencySys100ns = [string]$raw.Frequency_Sys100NS }); error = $null }
    } catch { return @{ status = 'unavailable'; startedUtc = $startedUtc; endedUtc = Utc; rows = @(); error = ErrorFact 'system-cpu' $_ } }
}
function BrowserRole($processInfo) {
    if ($processInfo.Name -notmatch '^(?:msedge|chrome|chromium|brave|vivaldi|opera|codex|code)\.exe$') { return $null }
    $commandLine = Field $processInfo 'CommandLine'
    if (-not $commandLine) { return 'unknown' }
    if ($commandLine -match '(?:^|\s)--type=(?:"?)([a-z-]+)') {
        if ($Matches[1] -in @('renderer','gpu-process','utility','crashpad-handler','zygote')) { return $Matches[1] }
        return 'other-browser-subprocess'
    }
    return 'browser'
}
function ReadProcesses($gpuEngine, $gpuMemory) {
    $startedUtc = Utc
    try {
        $needed = @{}
        foreach ($row in @($gpuEngine.rows) + @($gpuMemory.rows)) { if ($null -ne $row.pid) { $needed[[string]$row.pid] = $true } }
        $needed[[string]$PID] = $true
        $atMs = $clock.Elapsed.TotalMilliseconds
        $raw = @(Get-CimInstance -ClassName Win32_Process -Property ProcessId,CreationDate,Name,CommandLine,UserModeTime,KernelModeTime -OperationTimeoutSec 2)
        $rows = [Collections.Generic.List[object]]::new(); $next = @{}
        foreach ($item in $raw) {
            $processId = [int]$item.ProcessId
            $role = BrowserRole $item
            if (-not $needed.ContainsKey([string]$processId) -and $null -eq $role -and $item.Name -notmatch '^(?:nvidia-smi|WmiPrvSE)\.exe$') { continue }
            $startUtc = if ($item.CreationDate) { $item.CreationDate.ToUniversalTime().ToString('o') } else { $null }
            $userRaw = Field $item 'UserModeTime'; $kernelRaw = Field $item 'KernelModeTime'
            $row = @{ pid = $processId; startUtc = $startUtc; name = ([string]$item.Name).Substring(0,[Math]::Min(128,([string]$item.Name).Length)); browserRole = $role; user100ns = if ($null -ne $userRaw) { [string]$userRaw } else { $null }; kernel100ns = if ($null -ne $kernelRaw) { [string]$kernelRaw } else { $null }; cpuUserOneCorePercent = $null; cpuKernelOneCorePercent = $null; cpuSystemNormalizedPercent = $null; intervalMs = $null; identityKnown = ($null -ne $startUtc); status = 'ok' }
            if ($startUtc -and $null -ne $userRaw -and $null -ne $kernelRaw) {
                $identityKey = [string]$processId + '|' + $startUtc
                $old = $script:previousProcesses[$identityKey]
                if ($old -and $atMs -gt $old.atMs) {
                    $deltaUser = [decimal]$userRaw - $old.user; $deltaKernel = [decimal]$kernelRaw - $old.kernel
                    if ($deltaUser -ge 0 -and $deltaKernel -ge 0) {
                        $periodMs = $atMs - $old.atMs
                        $row.intervalMs = $periodMs
                        $row.cpuUserOneCorePercent = [double]$deltaUser / ($periodMs * 100)
                        $row.cpuKernelOneCorePercent = [double]$deltaKernel / ($periodMs * 100)
                        $row.cpuSystemNormalizedPercent = ($row.cpuUserOneCorePercent + $row.cpuKernelOneCorePercent) / $logicalProcessors
                    }
                }
                $next[$identityKey] = @{ atMs = $atMs; user = [decimal]$userRaw; kernel = [decimal]$kernelRaw }
            }
            [void]$rows.Add($row); [void]$needed.Remove([string]$processId)
        }
        foreach ($missingId in $needed.Keys) { [void]$rows.Add(@{ pid = [int]$missingId; startUtc = $null; name = $null; browserRole = $null; identityKnown = $false; status = 'not-observed'; cpuUserOneCorePercent = $null; cpuKernelOneCorePercent = $null; cpuSystemNormalizedPercent = $null; intervalMs = $null }) }
        $script:previousProcesses = $next
        return @{ status = 'ok'; startedUtc = $startedUtc; endedUtc = Utc; rows = @($rows.ToArray()); error = $null; scope = 'GPU PIDs, Chromium/Electron roles, collector/NVIDIA/WMI; no complete command lines retained' }
    } catch { return @{ status = 'unavailable'; startedUtc = $startedUtc; endedUtc = Utc; rows = @(); error = ErrorFact 'processes' $_ } }
}

$reason = 'duration'
$samples = 0
$lastSampleAt = $null
$lastCpuMs = $null
$lastCpuAt = $null
$startedUtc = Utc
try {
    InitializeNvidia
    $metadata = @{ schemaVersion = 1; recordType = 'metadata'; utc = Utc; requestedDurationSeconds = $DurationSeconds; requestedIntervalSeconds = $IntervalSeconds; maxSamples = $MaxSamples; logicalProcessors = $logicalProcessors; collector = $selfIdentity; stopFile = $stopPath; units = @{ memoryWindows = 'bytes'; memoryNvidia = 'MiB'; cpuRaw = '100ns strings'; cpuOneCore = '100%=one logical core; may exceed100'; cpuSystemNormalized = 'oneCorePercent/logicalProcessors'; gpuUtilization = 'raw per-engine percentage; do not sum engines'; processMemory = 'per PID/adapter raw; do not sum into whole VRAM' }; providers = @{ windows = 'CIM Win32_PerfFormattedData_GPUPerformanceCounters'; systemCpu = 'CIM PerfOS_Processor _Total'; processCpu = 'Win32_Process user/kernel deltas keyed PID+CreationDate'; nvidia = 'single hidden NVIDIA-SMI stream, independent driver window' }; nvidiaFields = @($script:nvidiaFields); nvidiaMissingFields = @($script:nvidiaMissing); outputLimitBytes = $outputLimitBytes }
    [void](WriteRecord $metadata)
    $runtime = @{ schemaVersion = 1; status = 'running'; startedUtc = $startedUtc; collector = $selfIdentity; outputDirectory = $outputPath; sampleFile = $samplePath; stopFile = $stopPath; helpers = @($script:children | ForEach-Object { $_.identity }) }
    [IO.File]::WriteAllText($runtimePath, (ConvertTo-Json $runtime -Depth 6), [Text.UTF8Encoding]::new($false))
    $captureStarted = $clock.Elapsed.TotalMilliseconds
    $nextAt = $captureStarted
    while ($clock.Elapsed.TotalMilliseconds - $captureStarted -lt $DurationSeconds * 1000) {
        if (Test-Path -LiteralPath $stopPath) { $reason = 'stop-file'; break }
        if ($MaxSamples -gt 0 -and $samples -ge $MaxSamples) { $reason = 'max-samples'; break }
        $waitMs = $nextAt - $clock.Elapsed.TotalMilliseconds
        if ($waitMs -gt 0) { Start-Sleep -Milliseconds ([int][Math]::Min($waitMs, 250)); continue }
        $at = $clock.Elapsed.TotalMilliseconds; $utc = Utc
        $engineRows = ReadGpuCim 'GPUEngine' 'engine'
        $memoryRows = ReadGpuCim 'GPUProcessMemory' 'process-memory'
        $adapterRows = ReadGpuCim 'GPUAdapterMemory' 'adapter-memory'
        $systemCpu = ReadSystemCpu
        $processRows = ReadProcesses $engineRows $memoryRows
        $nvidia = ReadNvidia
        $selfProcess.Refresh(); $cpuMs = $selfProcess.TotalProcessorTime.TotalMilliseconds
        $cpuAt = $clock.Elapsed.TotalMilliseconds
        $logger = @{ cpuMs = $cpuMs; intervalCpuMs = $null; oneCorePercent = $null; workingSetBytes = $selfProcess.WorkingSet64; scope = 'collector process only; helper/provider CPU visible separately in process rows' }
        if ($null -ne $lastCpuMs -and $cpuAt -gt $lastCpuAt) { $logger.intervalCpuMs = $cpuMs - $lastCpuMs; $logger.oneCorePercent = ($cpuMs - $lastCpuMs) * 100 / ($cpuAt - $lastCpuAt) }
        $sample = @{ schemaVersion = 1; recordType = 'sample'; seq = $samples; utc = $utc; endedUtc = Utc; elapsedMs = $at - $captureStarted; periodMs = if ($null -ne $lastSampleAt) { $at - $lastSampleAt } else { $null }; collectionMs = $clock.Elapsed.TotalMilliseconds - $at; intervalOverrun = ($clock.Elapsed.TotalMilliseconds - $at -gt $IntervalSeconds * 1000); providers = @{ gpuEngine = $engineRows; gpuProcessMemory = $memoryRows; gpuAdapterMemory = $adapterRows; systemCpu = $systemCpu; nvidia = $nvidia; processes = $processRows }; processes = @($processRows.rows); logger = $logger; errors = @() }
        if (-not (WriteRecord $sample)) { $reason = 'output-limit'; break }
        $samples++; $lastSampleAt = $at; $lastCpuMs = $cpuMs; $lastCpuAt = $cpuAt
        # Avoid a burst of catch-up queries when a provider was slow.
        $nextAt = [Math]::Max($nextAt + $IntervalSeconds * 1000, $clock.Elapsed.TotalMilliseconds)
    }
} catch {
    $reason = 'error'
    try { [void](WriteRecord @{ schemaVersion = 1; recordType = 'error'; utc = Utc; error = ErrorFact 'collector' $_ }) } catch { }
} finally {
    if ($script:nvidiaReader) { $script:nvidiaReader.Dispose() }
    foreach ($child in $script:children) { StopOwnedChild $child }
    $selfProcess.Refresh()
    try {
        [void](WriteRecord @{ schemaVersion = 1; recordType = 'summary'; utc = Utc; reason = $reason; samples = $samples; elapsedMs = $clock.Elapsed.TotalMilliseconds; collectorCpuMs = $selfProcess.TotalProcessorTime.TotalMilliseconds; cleanupErrors = @($script:cleanupErrors.ToArray()) })
        $runtime = @{ schemaVersion = 1; status = 'stopped'; reason = $reason; startedUtc = $startedUtc; endedUtc = Utc; collector = $selfIdentity; outputDirectory = $outputPath; sampleFile = $samplePath; stopFile = $stopPath; samples = $samples; cleanupErrors = @($script:cleanupErrors.ToArray()) }
        [IO.File]::WriteAllText($runtimePath, (ConvertTo-Json $runtime -Depth 6), [Text.UTF8Encoding]::new($false))
    } finally { $writer.Dispose(); $jsonStream.Dispose(); $selfProcess.Dispose() }
}
if ($reason -eq 'error' -or $script:cleanupErrors.Count -gt 0) { exit 1 }
