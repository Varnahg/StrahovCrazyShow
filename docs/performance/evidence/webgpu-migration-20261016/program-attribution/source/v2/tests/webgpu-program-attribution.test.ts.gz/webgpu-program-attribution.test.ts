import test from "node:test";
import assert from "node:assert/strict";
import { Observable } from "@babylonjs/core/Misc/observable";
import { NullEngine } from "@babylonjs/core/Engines/nullEngine";
import { Scene } from "@babylonjs/core/scene";
import { FreeCamera } from "@babylonjs/core/Cameras/freeCamera";
import { Vector3 } from "@babylonjs/core/Maths/math.vector";
import { MeshBuilder } from "@babylonjs/core/Meshes/meshBuilder";
import { StandardMaterial } from "@babylonjs/core/Materials/standardMaterial";
import { PBRMaterial } from "@babylonjs/core/Materials/PBR/pbrMaterial";
import type { Effect } from "@babylonjs/core/Materials/effect";
import { WebGpuCompilationProfile, type ProgramUser } from "../client/webgpu-compilation-profile";
import { RenderIncidentProfile } from "../client/render-incident-profile";
import { SessionDiagnostics } from "../client/session-diagnostics";
import { readFileSync } from "node:fs";
import vm from "node:vm";
import ts from "typescript";
import { sanitizeDiagnosticsData, validateDiagnosticsBatch, diagnosticsByteLength, MAX_DIAGNOSTICS_RECORD_BYTES } from "../shared/session-diagnostics";

const turn = () => new Promise<void>(resolve => setImmediate(resolve));
const user = (id = 1): ProgramUser => ({ material: "receiver", materialId: id, mesh: "mesh", meshId: id,
  renderingMesh: "mesh", renderingMeshId: id, geometryId: "geometry", subMeshId: 0, renderPassId: 2,
  vertices: 24, indices: 36, thinInstances: 0, attributes: ["position", "normal"], attributesOmitted: 0,
  geometryAttributes: ["position", "normal"], geometryAttributesOmitted: 0,
  receiveShadows:true,isInstance:false,regularInstances:0,vertexStart:0,indexStart:0,
  lightingEnabled:true,observedLights:[],lightsOmitted:0 });
function fixture() {
  const events: any[] = [];
  const engine = { isWebGPU: true, _device: {} as object,
    onDisposeObservable: new Observable<void>(), onContextRestoredObservable: new Observable<void>(),
    _initializeLimits() {}, _preparePipelineContextAsync(...args: unknown[]) { return args[0]; } };
  const profile = new WebGpuCompilationProfile(engine, { onProgramAttribution: event => events.push(event) });
  const prepare = (context: object, defines = "#define A\n") => engine._preparePipelineContextAsync(context, "DO NOT EXPORT VERTEX", "DO NOT EXPORT FRAGMENT", false, "", "", null, defines);
  const effect = (context: object | null = null, id = 7) => {
    const state = { context, uniqueId: id, onCompileObservable: new Observable<Effect>(), getPipelineContext() { return this.context; } };
    return state;
  };
  const observe = (e: ReturnType<typeof effect>, u = user()) => profile.observeProgramUser(e as unknown as Effect, u);
  return { events, engine, profile, prepare, effect, observe, requests: () => events.filter(x => x.kind === "request") };
}

test("only actual requests count: identical defines on distinct contexts, repeated context and cache-hit switches", () => {
  const f = fixture(); f.profile.beginProgramAttribution();
  const a = {}, b = {}; f.prepare(a); f.prepare(b); f.prepare(a);
  const e = f.effect(a); for (let n=0;n<20;n++) f.observe(e);
  f.observe(f.effect(b,8)); f.observe(f.effect({},9));
  f.profile.endProgramAttribution(); f.profile.dispose();
  assert.equal(f.requests().length,3);
  assert.deepEqual(f.requests().map(x=>x.contextId),[1,2,1]);
  assert.deepEqual(f.requests().map(x=>x.users.length),[1,1,1]);
  assert.ok(f.requests().every(x=>x.outcome==="returned" && !x.unmatched));
  assert.equal(e.onCompileObservable.observers.length,0);
  assert.equal(JSON.stringify(f.events).includes("DO NOT EXPORT"),false);
});

test("late context uses one real compile observer, shared users and fallback's replacement context", () => {
  const f = fixture(); f.profile.beginProgramAttribution(); const e = f.effect();
  for(let n=1;n<=4;n++) f.observe(e,user(n));
  assert.equal(e.onCompileObservable.observers.length,1);
  const discarded={}, final={}; f.prepare(discarded); f.prepare(final);
  e.context=final; e.onCompileObservable.notifyObservers(e as unknown as Effect);
  f.profile.endProgramAttribution(); f.profile.dispose();
  assert.deepEqual(f.requests().map(x=>x.unmatched),[true,false]);
  assert.equal(f.requests()[1].users.length,4);
  assert.ok(f.requests()[1].users.every((x:any)=>x.relation==="compile-notification"));
});

test("request/user/observer caps remain explicit and real sanitizer preserves complete bounded define chunks", () => {
  const f=fixture();f.profile.beginProgramAttribution();
  const text="#define URL https://host/path?token=private\n"+"#define REAL 1\n".repeat(1600)+"\u0000".repeat(1000);
  const context={};f.prepare(context,text);for(let n=1;n<=7;n++)f.observe(f.effect(context,n),user(n));
  for(let n=0;n<40;n++) { f.prepare({});f.observe(f.effect()); }
  f.profile.endProgramAttribution();f.profile.dispose();
  assert.equal(f.requests().length,32);assert.equal(f.events.at(-1).omitted,9);
  assert.equal(f.requests()[0].users.length,4);assert.equal(f.requests()[0].usersOmitted,3);
  assert.ok(f.events.at(-1).observersOmitted>0);
  const records=f.events.map((data,seq)=>({seq,atMs:seq,kind:"webgpu-program-attribution",data:sanitizeDiagnosticsData(data)}));
  assert.ok(records.every(record=>diagnosticsByteLength(record)<=MAX_DIAGNOSTICS_RECORD_BYTES));
  const first=records[0].data as any;
  assert.equal(first.defines.truncated,true);assert.ok(first.defines.chunks.every((part:string)=>part.length<=1024));
  assert.ok(new TextEncoder().encode(first.defines.chunks.join("")).length<=16384);
  assert.equal(JSON.stringify(records).includes("private"),false);
  // Collector has a batch byte cap too: validate each real record envelope.
  for(const record of records) assert.ok(validateDiagnosticsBatch({schemaVersion:1,sessionId:"00000000-0000-4000-8000-000000000001",batchId:1,records:[record]}));
});

test("stop/restart, device generation and disposal detach pending observers and reject stale callbacks", () => {
  const f=fixture();f.profile.beginProgramAttribution();const e=f.effect();f.observe(e);
  const stale=e.onCompileObservable.observers[0].callback;
  f.profile.beginProgramAttribution();assert.equal(e.onCompileObservable.observers.length,0);
  const context={};f.prepare(context);e.context=context;stale(e as unknown as Effect,new (class {} as any)());
  const pending=f.effect();f.observe(pending);
  f.engine._device={};f.engine.onContextRestoredObservable.notifyObservers();
  assert.equal(pending.onCompileObservable.observers.length,0);
  f.profile.beginProgramAttribution();const last=f.effect();f.observe(last);f.engine.onDisposeObservable.notifyObservers();
  assert.equal(last.onCompileObservable.observers.length,0);f.profile.dispose();
  assert.deepEqual(f.events.filter(x=>x.kind==="summary").map(x=>x.reason),["restarted","device-generation","disposed"]);
  assert.equal(f.requests()[0].unmatched,true);
});

test("actual pinned Effect and PBR/Standard observer chain links preparation without getMaterial or ready polling in attribution", async t => {
  const engine=new NullEngine(), scene=new Scene(engine);
  const camera=new FreeCamera("camera",new Vector3(0,0,-5),scene);camera.setTarget(Vector3.Zero());scene.activeCamera=camera;
  const events:any[]=[];
  // Capability adapter enables only profile installation; real NullEngine rendering remains GLSL/CPU.
  Object.defineProperty(engine,"isWebGPU",{value:true,configurable:true});
  const profile=new WebGpuCompilationProfile(engine,{onProgramAttribution:event=>events.push(event)});profile.beginProgramAttribution();
  Reflect.deleteProperty(engine,"isWebGPU");
  const incident=new RenderIncidentProfile(scene);const stop=incident.observeProgramUsers((effect,user)=>profile.observeProgramUser(effect,user));
  t.after(()=>{stop();profile.dispose();incident.dispose();scene.dispose();engine.dispose();});
  const captures:Effect[]=[];
  for(const material of [new StandardMaterial("standard",scene),new PBRMaterial("pbr",scene)]) {
    const mesh=MeshBuilder.CreateBox(material.name,{},scene);mesh.material=material;
    material.onEffectCreatedObservable.add(({effect})=>captures.push(effect));
  }
  await turn();
  const deadline=performance.now()+3000;
  while((!captures.length||!scene.isReady())&&performance.now()<deadline) {scene.render();await turn();}
  assert.equal(scene.isReady(),true);scene.render();
  profile.endProgramAttribution();const requests=events.filter(x=>x.kind==="request");
  assert.ok(requests.length>=2,JSON.stringify(events));
  assert.ok(requests.some(x=>x.users.some((u:any)=>u.material==="standard")));
  assert.ok(requests.some(x=>x.users.some((u:any)=>u.material==="pbr")));
  assert.ok(requests.every(x=>x.users.length<=4));
  assert.ok(requests.some(x=>x.users.some((u:any)=>u.attributes.includes("position")&&u.geometryAttributes.includes("position"))));
});

for (const metadataKind of ["unicode-controls", "redaction-expansion"] as const) {
test(`real local logger and collector retain bounded program records: ${metadataKind}`, async () => {
  const posts:any[]=[];
  const recorder=new SessionDiagnostics({hostname:"localhost",now:()=>100,wallNow:()=>1700000000000,
    makeSessionId:()=>"00000000-0000-4000-8000-000000000001",setInterval:()=>1,clearInterval:()=>{},
    fetch:async (url,init)=>{
      if(String(url).endsWith("/status")) return new Response(JSON.stringify({enabled:true,schemaVersion:1,sourceId:"frozen"}));
      const batch=JSON.parse(String(init?.body));posts.push(batch);
      return new Response(JSON.stringify({saved:true,sessionId:batch.sessionId,batchId:batch.batchId,savedAt:"2026-10-18T00:00:00Z"}));
    }});
  recorder.start();await turn();
  const f=fixture();f.profile.beginProgramAttribution();
  for(let i=0;i<32;i++) {
    const context={};f.prepare(context,"#define VALUE 1\n".repeat(1400));
    for(let n=1;n<=4;n++) {
      const long = metadataKind === "redaction-expansion" ? "token=a ".repeat(12) : "\u0000😀".repeat(48).slice(0,96);
      const attributes = Array(24).fill(metadataKind === "redaction-expansion" ? "token=a ".repeat(4) : "\u0000😀".repeat(11).slice(0,32));
      f.observe(f.effect(context),{...user(n),material:long,mesh:long,renderingMesh:long,geometryId:long,
        attributes,geometryAttributes:attributes,
        observedLights:Array.from({length:4},(_,id)=>({id,name:long,type:0,shadowEnabled:true,falloff:0}))});
    }
  }
  f.profile.endProgramAttribution();f.profile.dispose();
  for(const event of f.events)recorder.event("webgpu-program-attribution",event);
  await recorder.flush();await turn();await recorder.flush();
  const events=posts.flatMap(batch=>batch.records).filter(event=>event.kind==="webgpu-program-attribution");
  assert.equal(events.length,33);assert.equal(recorder.status().dropped,0);
  assert.ok(events.slice(0,32).every(event=>event.data.metadataTruncated===true && event.data.usersOmitted>0));
  for (const batch of posts) {
    const received = validateDiagnosticsBatch(batch);
    assert.ok(received);
    assert.ok(received.records.every(record=>diagnosticsByteLength(record)<=MAX_DIAGNOSTICS_RECORD_BYTES));
    assert.deepEqual(validateDiagnosticsBatch(received),received,"repeated collector sanitization remains stable for these bounded records");
  }
  if (metadataKind === "redaction-expansion") assert.equal(JSON.stringify(events).includes("token=a"),false);
  assert.equal(events[0].data.defines.chunks.join(""),f.events[0].defines.chunks.join(""));
  recorder.dispose();
});
}

test("actual Game benchmark method gates attribution on local recording/WebGPU and replaces the old observer", () => {
  const source=readFileSync(new URL("../client/game.ts",import.meta.url),"utf8"),tree=ts.createSourceFile("game.ts",source,ts.ScriptTarget.Latest,true);
  const game=tree.statements.find(ts.isClassDeclaration)!;
  const method=game.members.find(node=>ts.isMethodDeclaration(node)&&node.name.getText(tree)==="startBenchmark")!;
  const code=ts.transpileModule(`class Extracted { ${method.getText(tree)} }; Extracted.prototype.startBenchmark`,{compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText;
  let recording=true, begins=0,ends=0,callbacks=0,active=0;
  const start=vm.runInNewContext(code,{performance:{now:()=>100},innerWidth:100,innerHeight:50,
    structuredClone,sessionDiagnostics:{get isRecording(){return recording;},event:()=>{}},
    BenchmarkRenderProfile:class {constructor(){throw new Error("existing incident profiler must be reused");}}});
  const fixture:any={ready:true,disposed:false,rendererFailed:false,environmentProfile:{},engine:{isWebGPU:true,getRenderWidth:()=>100,getRenderHeight:()=>50},
    renderIncidentProfile:{observeProgramUsers:()=>{active++;return()=>{active--;};}},
    compilationProfile:{beginProgramAttribution:()=>{begins++;},endProgramAttribution:()=>{ends++;},observeProgramUser:()=>{callbacks++;},snapshot:()=>({})},
    renderHealth:{rendererId:1,snapshot:()=>({})},avatars:new Map(),actor:{position:{x:0,y:0,z:0}},yaw:0,pitch:0,
    camera:{globalPosition:{x:0,y:0,z:0},fov:.8,minZ:.1,maxZ:100},quality:"low"};
  assert.equal(start.call(fixture),true);const old=fixture.stopProgramAttribution;
  assert.equal(start.call(fixture),true);old();assert.equal(active,1);assert.equal(begins,2);assert.equal(ends,1);
  fixture.stopProgramAttribution();assert.equal(active,0);assert.equal(ends,2);
  fixture.engine.isWebGPU=false;assert.equal(start.call(fixture),true);assert.equal(begins,2);
  fixture.engine.isWebGPU=true;recording=false;assert.equal(start.call(fixture),true);assert.equal(begins,2);
  recording=true;fixture.environmentProfile=undefined;assert.equal(start.call(fixture),true);assert.equal(begins,2);
  fixture.ready=false;assert.equal(start.call(fixture),false);assert.equal(callbacks,0);
});
