import fs from 'node:fs';import path from 'node:path';import{registerHooks}from'node:module';import{fileURLToPath,pathToFileURL}from'node:url';
export const core=path.resolve(process.env.SHADOW_SHARE_CORE||new URL('../webgpu-serializer-schema-qa-20261019/native-clean-f3/node_modules/@babylonjs/core',import.meta.url).pathname.replace(/^\/([A-Z]:)/i,'$1'));
const target=fs.realpathSync(path.join(core,'Materials/shadowDepthWrapper.js'));
const selected=process.env.SHADOW_SHARE_MODULE||fileURLToPath(new URL('./candidate/Materials/shadowDepthWrapper.js',import.meta.url));
if(process.env.SHADOW_SHARE_VARIANT!=='A')registerHooks({load(url,context,next){if(url.startsWith('file:')&&fileURLToPath(url).replaceAll('\\','/')===target.replaceAll('\\','/'))return{format:'module',source:fs.readFileSync(selected,'utf8'),shortCircuit:true};return next(url,context);}});
export const moduleAt=rel=>import(pathToFileURL(path.join(core,rel)).href);
