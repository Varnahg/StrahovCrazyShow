import{moduleAt}from'./loader.mjs';
const{NullEngine}=await moduleAt('Engines/nullEngine.js'),{WebGPUEngine}=await moduleAt('Engines/webgpuEngine.pure.js'),{Scene}=await moduleAt('scene.js');
const engine=new NullEngine();const scene=new Scene(engine);Object.defineProperty(engine,'isWebGPU',{value:true,configurable:true});
const effect=WebGPUEngine.prototype.createEffect.call(engine,{vertexSource:'attribute vec3 position;void main(void){gl_Position=vec4(position,1.);}',fragmentSource:'void main(void){gl_FragColor=vec4(1.);}'},{attributes:['position'],uniformsNames:[],uniformBuffersNames:[],samplers:[],defines:'',shaderLanguage:0},engine);
await new Promise(r=>setTimeout(r,30));console.log({ready:effect.isReady(),error:effect.getCompilationError(),refs:effect._refCount,source:effect.vertexSourceCodeBeforeMigration.length});effect.dispose();console.log({disposed:effect.isDisposed,refs:effect._refCount});scene.dispose();engine.dispose();
