import{fixture,ready}from'./fixture.mjs';
const f=await fixture({gpu:process.env.CASE_GPU!=='0',options:{remappedVariables:['worldPos','worldPosition']}}),w=f.wrapper(),a=f.mesh(),b=f.mesh();
f.creates.length=0;await ready(w._makeEffect(a.sub,f.depth,f.generator,0));await ready(w._makeEffect(b.sub,[...f.depth,'#define DEPTHPREPASS'],f.generator,1));
const descriptors=f.creates.map(({base,options})=>({base:{vertexSource:base.vertexSource,fragmentSource:base.fragmentSource},options}));f.dispose();console.log('RESULT_JSON '+JSON.stringify(descriptors));
