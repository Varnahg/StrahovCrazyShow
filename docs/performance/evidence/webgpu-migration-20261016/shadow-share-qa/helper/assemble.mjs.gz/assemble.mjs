import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import{spawnSync}from'node:child_process';
const root=process.cwd(),dir=path.join(root,'.cache/webgpu-shadow-share-helper-20261019'),core=path.join(root,'.cache/webgpu-serializer-schema-qa-20261019/native-clean-f3/node_modules/@babylonjs/core');
const file='Materials/shadowDepthWrapper.js',source=fs.readFileSync(path.join(core,file),'utf8'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
if(sha(source)!=='bd2bfe313728751f375d613492e7210adb09733556dcb8e6f2d8e720b55f122c')throw Error('Pinned F3 preimage changed');
const edits=[];let next=source;const edit=(before,after)=>{if(next.split(before).length!==2)throw Error('Ambiguous hunk '+before.slice(0,90));next=next.replace(before,()=>after);edits.push({before,after});};
edit('        this._options = options;',`        this._options = options;
        // WebGPU only: metadata tokens, never an Effect/resource cache.
        this._depthTokens = this._scene.getEngine().isWebGPU ? new WeakMap() : null;
        this._depthDisposed = false;`);
edit('        this._onEffectCreatedObserver = this._baseMaterial.onEffectCreatedObservable.add((params) => {',`        this._onEffectCreatedObserver = this._baseMaterial.onEffectCreatedObservable.add((params) => {
            if (this._depthDisposed) return;`);
edit('                            this._deleteDepthWrapperEffect(subMesh);\n                        }\n                    }\n                }));',`                            this._deleteDepthWrapperEffect(subMesh);
                        }
                    }
                    if (this._depthTokens) this._meshes.delete(mesh);
                }));`);
edit('                depthWrapper.mainDrawWrapper.effect?.dispose();',`                if (this._depthTokens) this._releaseDepthEntry(depthWrapper);
                else depthWrapper.mainDrawWrapper.effect?.dispose();`);
edit('    /**\n     * Gets the effect to use to generate the depth map',`    _releaseDepthEntry(entry) {
        const effect = entry.mainDrawWrapper.effect;
        // Each entry acquired once. Pass aliases must not each release it.
        for (const wrapper of new Set([entry.mainDrawWrapper, ...entry.drawWrapper.filter(Boolean)])) {
            wrapper.effect = null;
            wrapper.dispose(true);
        }
        if (effect && !effect.isDisposed) effect.dispose();
    }
    _getDepthProgramToken(original, vertexCode, fragmentCode, options, fallback) {
        let signature;
        try {
            const lists = [options.attributes, options.uniformsNames, options.uniformBuffersNames, options.samplers];
            const copied = [];
            for (const list of lists) {
                if (!Array.isArray(list)) return fallback;
                const names = [];
                for (let index = 0; index < list.length; index++) {
                    const descriptor = Object.getOwnPropertyDescriptor(list, String(index));
                    if (!descriptor || !("value" in descriptor) || typeof descriptor.value !== "string") return fallback;
                    names.push(descriptor.value);
                }
                copied.push(names);
            }
            const parameters = options.indexParameters;
            let indexes;
            if (parameters === undefined) indexes = ["undefined"];
            else if (parameters === null) indexes = ["null"];
            else {
                if (Object.getPrototypeOf(parameters) !== Object.prototype && Object.getPrototypeOf(parameters) !== null) return fallback;
                indexes = ["object"];
                for (const key of Reflect.ownKeys(parameters)) {
                    if (typeof key !== "string") return fallback;
                    const descriptor = Object.getOwnPropertyDescriptor(parameters, key);
                    if (!descriptor || !("value" in descriptor)) return fallback;
                    const value = descriptor.value, type = typeof value;
                    if (value !== null && type !== "string" && type !== "boolean" && type !== "undefined" && (type !== "number" || !Number.isFinite(value))) return fallback;
                    indexes.push([key, type, type === "number" && Object.is(value, -0) ? "-0" : value]);
                }
            }
            if (typeof vertexCode !== "string" || typeof fragmentCode !== "string" || !Number.isSafeInteger(options.shaderLanguage)) return fallback;
            signature = JSON.stringify([vertexCode, fragmentCode, options.shaderLanguage, copied, indexes]);
        } catch { return fallback; }
        const previous = this._depthTokens.get(original);
        if (previous?.signature === signature) return previous.token;
        const token = RandomGUID();
        this._depthTokens.set(original, { signature, token });
        return token;
    }
    /**
     * Gets the effect to use to generate the depth map`);
edit('    isReadyForSubMesh(subMesh, defines, shadowGenerator, useInstances, passIdForDrawWrapper) {',`    isReadyForSubMesh(subMesh, defines, shadowGenerator, useInstances, passIdForDrawWrapper) {
        if (this._depthDisposed) return false;`);
edit('    dispose() {\n        this._baseMaterial.onEffectCreatedObservable.remove(this._onEffectCreatedObserver);',`    dispose() {
        if (this._depthTokens && this._depthDisposed) return;
        if (this._depthTokens) this._depthDisposed = true;
        this._baseMaterial.onEffectCreatedObservable.remove(this._onEffectCreatedObserver);`);
edit('            mesh.onDisposeObservable.remove(observer);\n        }\n    }\n    _makeEffect',`            mesh.onDisposeObservable.remove(observer);
        }
        if (this._depthTokens) {
            for (const entries of this._subMeshToDepthWrapper.mm.values())
                for (const entry of entries.values()) this._releaseDepthEntry(entry);
            this._subMeshToDepthWrapper.mm.clear();
            this._subMeshToEffect.clear();
            this._meshes.clear();
            this._depthTokens = new WeakMap();
        }
    }
    _makeEffect`);
edit('        const engine = this._scene.getEngine();\n        const origEffectAndRenderPassId',`        if (this._depthDisposed) return null;
        const engine = this._scene.getEngine();
        const origEffectAndRenderPassId`);
edit('        if (!origEffect.isReady()) {','        if (!origEffect.isReady() || (this._depthTokens && origEffect.isDisposed)) {');
edit('            if (join === params.depthDefines) {','            if (join === params.depthDefines && (!this._depthTokens || !params.mainDrawWrapper.effect.isDisposed)) {');
edit('        params.depthDefines = join;','        if (!this._depthTokens) params.depthDefines = join;');
const before=`        params.mainDrawWrapper.effect = engine.createEffect({
            vertexSource: vertexCode,
            fragmentSource: fragmentCode,
            vertexToken: params.token,
            fragmentToken: params.token,
        }, {
            attributes: origEffect.getAttributesNames(),
            uniformsNames: uniforms,
            uniformBuffersNames: origEffect.getUniformBuffersNames(),
            samplers: origEffect.getSamplers(),
            defines: join + "\\n" + origEffect.defines.replace("#define SHADOWS", "").replace(/#define SHADOW\\d/g, ""),
            indexParameters: origEffect.getIndexParameters(),
            shaderLanguage: origEffect.shaderLanguage,
        }, engine);`;
const after=`        const effectOptions = {
            attributes: origEffect.getAttributesNames(),
            uniformsNames: uniforms,
            uniformBuffersNames: origEffect.getUniformBuffersNames(),
            samplers: origEffect.getSamplers(),
            defines: join + "\\n" + origEffect.defines.replace("#define SHADOWS", "").replace(/#define SHADOW\\d/g, ""),
            indexParameters: origEffect.getIndexParameters(),
            shaderLanguage: origEffect.shaderLanguage,
        };
        const token = this._depthTokens
            ? this._getDepthProgramToken(origEffect, vertexCode, fragmentCode, effectOptions, params.token)
            : params.token;
        const nextEffect = engine.createEffect({
            vertexSource: vertexCode,
            fragmentSource: fragmentCode,
            vertexToken: token,
            fragmentToken: token,
        }, effectOptions, engine);
        if (this._depthTokens) {
            // A synchronous engine callback may retire the current entry.
            if (this._depthDisposed || this._subMeshToDepthWrapper.get(subMesh, shadowGenerator) !== params || this._subMeshToEffect.get(subMesh)?.[0] !== origEffect) {
                if (!nextEffect.isDisposed) nextEffect.dispose();
                return null;
            }
            const previousEffect = params.mainDrawWrapper.effect;
            params.depthDefines = join;
            for (const wrapper of new Set([params.mainDrawWrapper, ...params.drawWrapper.filter(Boolean)]))
                wrapper.setEffect(nextEffect, params.mainDrawWrapper.defines);
            if (previousEffect && !previousEffect.isDisposed) previousEffect.dispose();
            return nextEffect;
        }
        params.mainDrawWrapper.effect = nextEffect;`;
edit(before,after);
let inverse=next;for(const e of [...edits].reverse()){if(inverse.split(e.after).length!==2)throw Error('Inverse ambiguous');inverse=inverse.replace(e.after,()=>e.before);}if(inverse!==source)throw Error('Inverse mismatch');
fs.mkdirSync(path.join(dir,'candidate/Materials'),{recursive:true});fs.mkdirSync(path.join(dir,'preimages/Materials'),{recursive:true});
fs.writeFileSync(path.join(dir,'candidate',file),next);fs.writeFileSync(path.join(dir,'preimages',file),source);
const inputs={};for(const p of [file,'Materials/effect.pure.js','Materials/drawWrapper.js','Engines/webgpuEngine.pure.js'])inputs[p]=sha(fs.readFileSync(path.join(core,p)));
fs.writeFileSync(path.join(dir,'source-inverse.json'),JSON.stringify({core,input:file,before:sha(source),after:sha(next),inverse:sha(inverse),exact:true,edits,inputs},null,2)+'\n');
const diff=spawnSync('git',['-c','core.autocrlf=false','diff','--no-index','--no-ext-diff','--',path.join(dir,'preimages',file),path.join(dir,'candidate',file)],{encoding:'utf8'});if(diff.status!==1)throw Error('diff');fs.writeFileSync(path.join(dir,'runtime.diff'),diff.stdout);console.log(JSON.stringify({before:sha(source),candidate:sha(next),hunks:edits.length}));
