import test from 'node:test';import assert from 'node:assert/strict';import{fixture,ready}from'./fixture.mjs';

test('same actual base/source/ABI shares real engine Effect while draw/material contexts remain separate',async t=>{
 const f=await fixture();t.after(f.dispose);const w=f.wrapper(),a=f.mesh(),b=f.mesh();
 const one=await ready(w._makeEffect(a.sub,f.depth,f.generator,0)),two=await ready(w._makeEffect(b.sub,f.depth,f.generator,0));
 assert.equal(one,two);assert.equal(one._refCount,2);const left=w.getEffect(a.sub,f.generator,0),right=w.getEffect(b.sub,f.generator,0);assert.notEqual(left,right);assert.notEqual(left.drawContext,right.drawContext);assert.notEqual(left.materialContext,right.materialContext);
 const alias=w.getEffect(a.sub,f.generator,7);assert.notEqual(alias,left);assert.equal(alias.effect,one);assert.equal(one._refCount,2);assert.notEqual(alias.drawContext,left.drawContext);
 a.mesh.dispose();assert.equal(one.isDisposed,false);assert.equal(one._refCount,1);assert.equal(w.getEffect(a.sub,f.generator,0),null);assert.equal(alias.effect,null);
 b.mesh.dispose();assert.equal(one.isDisposed,true);assert.equal(one._refCount,0);assert.equal(f.engine._compiledEffects[one._key],undefined);
 for(const context of [left.drawContext,right.drawContext,alias.drawContext])assert.equal(f.contexts.find(x=>x.context===context).releases(),1);
});

test('depth replacement balances real cache references and failed acquisition preserves old entry',async t=>{
 const f=await fixture();t.after(f.dispose);const w=f.wrapper(),a=f.mesh(),b=f.mesh();const old=await ready(w._makeEffect(a.sub,f.depth,f.generator,0));await ready(w._makeEffect(b.sub,f.depth,f.generator,0));
 const next=await ready(w._makeEffect(a.sub,[...f.depth,'#define DEPTHPREPASS'],f.generator,0));assert.notEqual(next,old);assert.equal(old._refCount,1);assert.equal(next._refCount,1);
 const create=f.engine.createEffect;f.engine.createEffect=()=>{throw new Error('creation failure');};assert.throws(()=>w._makeEffect(a.sub,['#define FAIL'],f.generator,0),/creation failure/);f.engine.createEffect=create;
 assert.equal(w.getEffect(a.sub,f.generator,0).effect,next);assert.equal(w._makeEffect(a.sub,[...f.depth,'#define DEPTHPREPASS'],f.generator,0),next);
 const back=await ready(w._makeEffect(a.sub,f.depth,f.generator,0));assert.equal(back,old);assert.equal(old._refCount,2);assert.equal(next._refCount,0);assert.equal(next.isDisposed,true);
 w.dispose();assert.equal(old._refCount,0);assert.equal(old.isDisposed,true);w.dispose();assert.equal(old._refCount,0);
});

test('base replacement releases only its owner and disposed wrappers cannot recreate entries',async t=>{
 const f=await fixture();t.after(f.dispose);const w=f.wrapper(),a=f.mesh(),b=f.mesh();const old=await ready(w._makeEffect(a.sub,f.depth,f.generator,0));await ready(w._makeEffect(b.sub,f.depth,f.generator,0));
 const newer=await f.base();f.notify(a.sub,newer);assert.equal(old._refCount,1);assert.equal(w.getEffect(a.sub,f.generator,0),null);
 const next=await ready(w._makeEffect(a.sub,f.depth,f.generator,0));assert.notEqual(next,old);w.dispose();assert.equal(old.isDisposed,true);assert.equal(next.isDisposed,true);assert.equal(newer.isDisposed,false);assert.equal(f.original.isDisposed,false);
 f.notify(a.sub,newer);assert.equal(w._subMeshToEffect.size,0);assert.equal(w._makeEffect(a.sub,f.depth,f.generator,0),null);assert.equal(w.isReadyForSubMesh(a.sub,f.depth,f.generator,false,0),false);
});
