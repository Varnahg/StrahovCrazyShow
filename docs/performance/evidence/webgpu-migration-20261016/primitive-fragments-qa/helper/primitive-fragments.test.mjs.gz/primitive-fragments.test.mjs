import test from 'node:test';import assert from 'node:assert/strict';
import {loadCandidate,F3,fresh} from './inspection.mjs';

function accounting(F){
 const store=F.inspectFragments();assert.ok(store.holders.length<=1024);assert.equal(store.queueKeys.length,store.holders.length);
 let slots=0,units=0;
 for(const holder of store.holders){
  assert.deepEqual(Object.keys(holder),['payload','queued']);assert.equal(holder.queued,true);const p=holder.payload;assert.ok(p);
  assert.deepEqual(Object.keys(p),['names','values','fragments','slots','stringUnits']);
  assert.ok(Object.isFrozen(p)&&Object.isFrozen(p.names)&&Object.isFrozen(p.values)&&Object.isFrozen(p.fragments));
  assert.equal(Object.getPrototypeOf(p.values),null);assert.equal(Object.getPrototypeOf(p.fragments),null);assert.ok(p.names.length<=1024);
  assert.equal(p.slots,2*p.names.length);assert.equal(Object.keys(p.values).length,p.names.length);assert.equal(Object.keys(p.fragments).length,p.names.length);
  assert.ok(p.names.every(n=>typeof n==='string'));assert.ok(p.names.reduce((n,s)=>n+s.length,0)<=32768);
  let ownUnits=0,emitted=0;
  for(let i=0;i<p.names.length;i++){
   const v=p.values[i],fragment=p.fragments[i];assert.ok(v===null||['undefined','boolean','number','string'].includes(typeof v));
   if(typeof v==='number')assert.ok(Number.isFinite(v));if(typeof v==='string')ownUnits+=v.length;
   assert.ok(fragment===undefined||typeof fragment==='string');if(fragment!==undefined){ownUnits+=fragment.length;emitted+=fragment.length;}
  }
  assert.equal(p.stringUnits,ownUnits);assert.ok(emitted<=32768);slots+=p.slots;units+=ownUnits;
 }
 assert.equal(store.slots,slots);assert.equal(store.stringUnits,units);assert.ok(slots<=524288);assert.ok(units<=4194304);return store;
}

test('unchanged primitive snapshots skip literal checks; typed changes publish only exact complete values',async()=>{
 const F=await loadCandidate(),d=fresh(F),a=fresh(F3);let checks=0;const original=F.literalPattern.test;
 F.literalPattern.test=function(value){checks++;return Reflect.apply(original,this,[value]);};
 assert.equal(d.toString(),a.toString());assert.equal(checks,1);const first=F.inspectHolder(d).payload;
 assert.equal(d.toString(),a.toString());assert.equal(checks,1);assert.equal(F.inspectHolder(d).payload,first);
 for(const value of [1,-0,0,false,true,null,undefined,'1','-0','+1.00e-2','.5','1.']){
  d.Z=a.Z=value;assert.equal(d.toString(),a.toString());const p=F.inspectHolder(d).payload;assert.ok(Object.is(p.values[0],value));accounting(F);
 }
 assert.ok(checks>1);
});

test('invalid values and names use original formatting/fallback and cannot publish foreign references',async()=>{
 const F=await loadCandidate();
 for(const value of [NaN,Infinity,-Infinity,'01','1\n','1\r','1\n#define EXTRA 2','1e999',{},()=>1,Symbol('value'),1n]){
  const d=fresh(F),a=fresh(F3);d.toString();const previous=F.inspectHolder(d).payload;
  d.Z=a.Z=value;assert.equal(d.toString(),a.toString());assert.equal(F.inspectHolder(d).payload,previous);accounting(F);
 }
 for(const key of ['A__B','GL_A','constructor','defined','Z\n#define X','Z\r','Å']){
  const d=fresh(F,[[key,1],['A',true]]),a=fresh(F3,[[key,1],['A',true]]);assert.equal(d.toString(),a.toString());assert.equal(F.inspectHolder(d),undefined);
 }
 const duplicate=fresh(F);duplicate._keys=['Z','Z'];duplicate.toString();assert.equal(F.inspectHolder(duplicate),undefined);
});

test('all original proxy/key/value reads and inline coercion/throw identities survive hits and mutations',async()=>{
 const F=await loadCandidate();
 function specimen(C,trace,sentinel){
  const d=fresh(C);let keys=['Z','A'];Object.defineProperty(d,'_keys',{get(){trace.push('keys');return new Proxy(keys,{get(t,p){trace.push('index:'+String(p));return Reflect.get(t,p);}});}});
  let z='1';Object.defineProperty(d,'Z',{get(){trace.push('Z');if(z===sentinel)throw sentinel;return z;},set(v){z=v;}});
  return{d,key(v){keys=v;}};
 }
 const left=[],right=[],sentinel=new Error('same throw'),a=specimen(F3,left,sentinel),d=specimen(F,right,sentinel);
 for(const value of ['1','1',2,'01',sentinel,'1']){
  left.length=right.length=0;a.d.Z=d.d.Z=value;
  let av,dv,ae,de;try{av=a.d.toString();}catch(e){ae=e;}try{dv=d.d.toString();}catch(e){de=e;}
  assert.equal(av,dv);assert.equal(ae,de);assert.deepEqual(right,left);
 }
 function keySpec(C,trace){const d=fresh(C);const key={[Symbol.toPrimitive](hint){trace.push(hint);return hint==='string'?'Z':'A';}};d._keys=[key,'A'];return d;}
 const at=[],dt=[];assert.equal(keySpec(F,dt).toString(),keySpec(F3,at).toString());assert.deepEqual(dt,at);
 const symbol=Symbol('key');for(const active of [false,true]){const x=fresh(F,[[symbol,active]]),y=fresh(F3,[[symbol,active]]);if(active){assert.throws(()=>x.toString(),TypeError);assert.throws(()=>y.toString(),TypeError);}else assert.equal(x.toString(),y.toString());assert.equal(F.inspectHolder(x),undefined);}
});

test('full name sequence including middle/count changes remains required for fragment reuse',async()=>{
 const F=await loadCandidate(),d=fresh(F,[['A',1],['M',2],['N',3],['Z',4]]),a=fresh(F3,[['A',1],['M',2],['N',3],['Z',4]]);
 d.toString();for(const keys of [['A','N','M','Z'],['A','N'],['A','N','M','Z'],['A','N','M','Z','L']]){
  d._keys=a._keys=keys;d.L=a.L=5;assert.equal(d.toString(),a.toString());assert.deepEqual(F.inspectHolder(d).payload.names,keys);accounting(F);
 }
});

test('nested completion uses a stable outer snapshot and thrown outer calls publish nothing',async()=>{
 const F=await loadCandidate(),d=fresh(F);d.toString();const original=F.inspectHolder(d).payload;let nested=false,mode='outer',throwOuter=false;
 Object.defineProperty(d,'Z',{get(){if(nested)return '2';nested=true;try{assert.equal(d.toString(),'#define A\n#define Z 2\n');}finally{nested=false;}if(throwOuter)throw sentinel;return mode==='outer'?'1':'3';}});
 const sentinel=new Error('outer throw');assert.equal(d.toString(),'#define A\n#define Z 1\n');assert.equal(F.inspectHolder(d).payload,original,'Completed all-hit outer re-publishes its immutable snapshot after inner publication');
 assert.equal(F.inspectHolder(d).payload.values[0],'1');
 throwOuter=true;assert.throws(()=>d.toString(),e=>e===sentinel);assert.equal(F.inspectHolder(d).payload.values[0],'2');
 throwOuter=false;mode='changed';assert.equal(d.toString(),'#define A\n#define Z 3\n');assert.equal(F.inspectHolder(d).payload.values[0],'3');accounting(F);
});

test('holder-count eviction clears live weak holders and re-admission is bounded',async()=>{
 const F=await loadCandidate(),d=fresh(F);d.toString();const held=F.inspectHolder(d);const before=held.payload;
 for(let i=0;i<1024;i++)fresh(F).toString();const store=accounting(F);assert.equal(store.holders.length,1024);assert.equal(held.payload,undefined);assert.equal(held.queued,false);assert.equal(F.inspectHolder(d),held);
 assert.ok(before);assert.equal(d.toString(),'#define A\n#define Z 1\n');assert.ok(held.payload);assert.equal(held.queued,true);accounting(F);
});

test('all-hit outer completion re-admits its snapshot after nested calls evict the live holder',async()=>{
 const F=await loadCandidate(),d=fresh(F);d.toString();const holder=F.inspectHolder(d),snapshot=holder.payload;let once=true;
 Object.defineProperty(d,'Z',{get(){if(once){once=false;for(let i=0;i<1024;i++)fresh(F).toString();assert.equal(holder.payload,undefined);}return '1';}});
 assert.equal(d.toString(),'#define A\n#define Z 1\n');assert.equal(holder.payload,snapshot);assert.equal(holder.queued,true);accounting(F);
});

test('slot cap evicts payloads while names metadata and live receivers remain valid',async()=>{
 const F=await loadCandidate(),entries=Array.from({length:1024},(_,i)=>['K'+String(i).padStart(4,'0'),false]);const first=fresh(F,entries);assert.equal(first.toString(),'');const held=F.inspectHolder(first);
 for(let i=0;i<256;i++)fresh(F,entries).toString();const store=accounting(F);assert.equal(store.slots,524288);assert.equal(store.holders.length,256);assert.equal(held.payload,undefined);assert.ok(F.inspectSchema(first));
});

test('string-unit cap counts value strings plus fragments and clears evicted live payloads',async()=>{
 const F=await loadCandidate(),value='0.'+'1'.repeat(31800),first=fresh(F,[['A',value]]);first.toString();const held=F.inspectHolder(first),one=held.payload.stringUnits;
 assert.equal(one,value.length+('#define A '+value+'\n').length);
 for(let i=0;i<80;i++)fresh(F,[['A',value]]).toString();const store=accounting(F);assert.equal(held.payload,undefined);assert.equal(store.holders.length,Math.floor(4194304/one));
 const tooLong=fresh(F,[['A','0.'+'1'.repeat(32768)]]);tooLong.toString();assert.equal(F.inspectHolder(tooLong),undefined);
});

test('prototype index setters are not invoked by scratch, FIFO insertion or immutable payload publication',async()=>{
 const F=await loadCandidate(),seed=fresh(F);seed.toString();const d=fresh(F),a=fresh(F3);a.toString();let touched=0,output,error;
 const prior=Object.getOwnPropertyDescriptor(Array.prototype,'1');
 try{
  Object.defineProperty(Array.prototype,'1',{configurable:true,set(){touched++;throw new Error('numeric prototype setter');}});
  output=d.toString();d.Z='2';output=d.toString();
 }catch(e){error=e;}finally{if(prior)Object.defineProperty(Array.prototype,'1',prior);else delete Array.prototype[1];}
 assert.equal(error,undefined);assert.equal(touched,0);assert.equal(output,'#define A\n#define Z 2\n');accounting(F);
});
