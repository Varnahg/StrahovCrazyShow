import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
const root=process.cwd(),out=path.join(root,'.cache/webgpu-primitive-fragments-helper-20261019');
const input='.cache/webgpu-serializer-schema-qa-20261019/native-clean-f3/node_modules/@babylonjs/core/Materials/materialDefines.js';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const source=fs.readFileSync(input,'utf8');if(sha(source)!=='3cc739bea27f7ec1f1b0f43e089d72d63ab15952166e7d3557c88af10ed34768')throw Error('F3 input changed');
const edits=[];const replace=(before,after)=>{if(source.split(before).length!==2)throw Error('Ambiguous source hunk');edits.push({before,after});};
const header=`// Private QA: bounded primitive fragment payloads, separate from F3 name schemas.
var primitiveFragmentHolders = new WeakMap();
var primitiveFragmentQueue = { __proto__: null };
var primitiveFragmentQueueHead = 0;
var primitiveFragmentQueueTail = 0;
var primitiveFragmentSlots = 0;
var primitiveFragmentUnits = 0;
function publishPrimitiveFragments(receiver, names, values, fragments, count, prior) {
    let payload;
    if (!values && prior && count === prior.names.length) {
        payload = prior;
    } else {
        const storedValues = values || { __proto__: null };
        let stringUnits = 0;
        for (let index = 0; index < count; index++) {
            const value = values ? values[index] : prior.values[index];
            if (!values) storedValues[index] = value;
            const fragment = fragments[index];
            if (typeof value === "string") stringUnits += value.length;
            if (typeof fragment === "string") stringUnits += fragment.length;
        }
        // The completed call no longer mutates its private null-prototype scratch.
        payload = Object.freeze({ names, values: Object.freeze(storedValues),
            fragments: Object.freeze(fragments), slots: count * 2, stringUnits });
    }
    let holder = primitiveFragmentHolders.get(receiver);
    // A nested completed call may have published or evicted another payload.
    // Skip only if this completed snapshot is still the resident one.
    if (holder?.payload === payload && holder.queued) return;
    if (!holder) {
        holder = { payload: undefined, queued: false };
        primitiveFragmentHolders.set(receiver, holder);
    }
    if (holder.payload) {
        primitiveFragmentSlots -= holder.payload.slots;
        primitiveFragmentUnits -= holder.payload.stringUnits;
    }
    holder.payload = payload;
    primitiveFragmentSlots += payload.slots;
    primitiveFragmentUnits += payload.stringUnits;
    if (!holder.queued) {
        holder.queued = true;
        primitiveFragmentQueue[primitiveFragmentQueueTail++] = holder;
    }
    while (primitiveFragmentQueueTail - primitiveFragmentQueueHead > 1024 || primitiveFragmentSlots > 524288 || primitiveFragmentUnits > 4194304) {
        const oldest = primitiveFragmentQueue[primitiveFragmentQueueHead];
        delete primitiveFragmentQueue[primitiveFragmentQueueHead++];
        oldest.queued = false;
        if (oldest.payload) {
            primitiveFragmentSlots -= oldest.payload.slots;
            primitiveFragmentUnits -= oldest.payload.stringUnits;
            oldest.payload = undefined;
        }
    }
}

`;
replace('var defineSchemas = new WeakMap();',header+'var defineSchemas = new WeakMap();');
replace('// QA metadata-only fastpath: state exists before class binding for ESM cycles.','// Private QA: F3 name metadata plus a separately bounded primitive-fragment cache.');
replace(' * preprocessor text. No property reads, _keys changes or persistent cache.',' * preprocessor text. canonicalResult itself has no property reads, _keys changes or persistent cache.');
replace('        const fragments = { __proto__: null };',`        const priorFragments = cacheable && defineSchemaReady ? primitiveFragmentHolders.get(this)?.payload : undefined;
        let primitiveValues = priorFragments ? null : { __proto__: null };
        const fragments = { __proto__: null };`);
const before=`            let fragment;
            switch (type) {
                case "number":
                case "string":
                    fragment = "#define " + prop + " " + value + "\\n";
                    break;
                default:
                    if (value) {
                        fragment = "#define " + prop + "\\n";
                    }
                    break;
            }
            fragments[index] = fragment;
            if (fragment !== undefined) { chars += fragment.length; rows++; }
            if (type === "number") safeValues = safeValues && Number.isFinite(value);
            else if (type === "string") safeValues = safeValues && schemaLiteralPattern.test(value) && Number.isFinite(Number(value));
            else if (type !== "boolean" && type !== "undefined" && value !== null) safeValues = false;`;
const after=`            let fragment;
            const reused = !!priorFragments && typeof prop === "string" && priorFragments.names[index] === prop && Object.is(priorFragments.values[index], value);
            if (reused) {
                fragment = priorFragments.fragments[index];
            } else {
                switch (type) {
                    case "number":
                    case "string":
                        fragment = "#define " + prop + " " + value + "\\n";
                        break;
                    default:
                        if (value) {
                            fragment = "#define " + prop + "\\n";
                        }
                        break;
                }
                if (type === "number") safeValues = safeValues && Number.isFinite(value);
                else if (type === "string") safeValues = safeValues && schemaLiteralPattern.test(value) && Number.isFinite(Number(value));
                else if (type !== "boolean" && type !== "undefined" && value !== null) safeValues = false;
                if (!primitiveValues) {
                    primitiveValues = { __proto__: null };
                    for (let previous = 0; previous < index && previous < SCHEMA_MAX_NAMES; previous++) primitiveValues[previous] = priorFragments.values[previous];
                }
            }
            if (primitiveValues && index < SCHEMA_MAX_NAMES && (type === "number" || type === "string" || type === "boolean" || type === "undefined" || value === null)) primitiveValues[index] = value;
            fragments[index] = fragment;
            if (fragment !== undefined) { chars += fragment.length; rows++; }`;
replace(before,after);
replace('            if (sharedPointer) defineSchemas.set(this, schema);\n            return result;',`            if (sharedPointer) defineSchemas.set(this, schema);
            publishPrimitiveFragments(this, schema.names, primitiveValues, fragments, count, priorFragments);
            return result;`);
replace('                defineSchemas.set(this, internDefineSchema(observed, order, units));',`                schema = internDefineSchema(observed, order, units);
                defineSchemas.set(this, schema);
                if (safeValues && chars <= 32768 && rows <= 1024) publishPrimitiveFragments(this, schema.names, primitiveValues, fragments, count, priorFragments);`);
let candidate=source;for(const e of edits)candidate=candidate.replace(e.before,()=>e.after);
let inverse=candidate;for(const e of [...edits].reverse()){if(inverse.split(e.after).length!==2)throw Error('Inverse hunk ambiguous');inverse=inverse.replace(e.after,()=>e.before);}if(inverse!==source)throw Error('Inverse mismatch');
fs.mkdirSync(path.join(out,'candidate/Materials'),{recursive:true});fs.mkdirSync(path.join(out,'preimages'),{recursive:true});
fs.writeFileSync(path.join(out,'candidate/Materials/materialDefines.mjs'),candidate);fs.writeFileSync(path.join(out,'preimages/materialDefines.mjs'),source);
fs.writeFileSync(path.join(out,'source-inverse.json'),JSON.stringify({input,before:sha(source),candidate:sha(candidate),inverse:sha(inverse),exact:true,edits},null,2)+'\n');
console.log(JSON.stringify({before:sha(source),candidate:sha(candidate),hunks:edits.length}));
