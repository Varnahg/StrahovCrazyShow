import fs from 'node:fs';
export const source=fs.readFileSync(new URL('./candidate/Materials/materialDefines.mjs',import.meta.url),'utf8');
export const f3Source=fs.readFileSync(new URL('./preimages/materialDefines.mjs',import.meta.url),'utf8');
let sequence=0;
export async function loadCandidate(){
 const inspection=`
export const inspectSchema = receiver=>defineSchemas.get(receiver);
export const inspectInterns = ()=>({entries:defineSchemaInterns.slice(),units:defineSchemaInternUnits});
export const inspectHolder = receiver=>primitiveFragmentHolders.get(receiver);
export const inspectFragments = ()=>{const holders=[];for(let i=primitiveFragmentQueueHead;i<primitiveFragmentQueueTail;i++)holders.push(primitiveFragmentQueue[i]);return{holders,slots:primitiveFragmentSlots,stringUnits:primitiveFragmentUnits,queueKeys:Object.keys(primitiveFragmentQueue)};};
export const literalPattern = schemaLiteralPattern;
`;
 return import('data:text/javascript;base64,'+Buffer.from(source+inspection+'\n// inspection '+sequence++).toString('base64'));
}
export const F3=await import('data:text/javascript;base64,'+Buffer.from(f3Source).toString('base64'));
export function fresh(F,entries=[['Z','1'],['A',true]]){const d=new F.MaterialDefines();for(const[k,v]of entries)Object.defineProperty(d,k,{value:v,writable:true,configurable:true,enumerable:true});d._keys=entries.map(([k])=>k);return d;}
