import assert from'node:assert/strict';import{readFileSync,writeFileSync}from'node:fs';import{join}from'node:path';import{PBRMaterialDefines}from'@babylonjs/core/Materials/PBR/pbrBaseMaterial.pure.js';import{StandardMaterialDefines}from'@babylonjs/core/Materials/standardMaterial.pure.js';
const root=import.meta.dirname,source=JSON.parse(readFileSync(join(root,'pressure-input-warm.json'))),rows=source.cases.filter(c=>!c.fail&&['pbr','standard'].includes(c.kind)),objects=[];
const counts={pbr:348,standard:151};for(const row of rows){const C=row.kind==='pbr'?PBRMaterialDefines:StandardMaterialDefines;for(let i=0;i<counts[row.kind];i++){const d=new C();const off=row.variantSnapshots.off,on=row.variantSnapshots.on;d._keys=Object.keys(off.values);for(const key of d._keys)d[key]=off.values[key];assert.equal(d.toString(),off.defines);objects.push({d,off,on});}}
assert.equal(objects.length,499);const samples=[];let checksum=0;for(let cycle=0;cycle<12;cycle++)for(const state of ['on','off']){
 // Updates deliberately outside measured serializer interval. These are actual
 // PBR/Standard define classes populated from a prior exact CPU fixture, not
 // a reproduction of the full production world or its receiver distribution.
 for(const {d,...states}of objects)for(const key of d._keys)d[key]=states[state].values[key];
 const start=performance.now();for(const {d}of objects)checksum+=d.toString().length;const elapsedMs=performance.now()-start;
 for(const {d,...states}of objects)assert.equal(d.toString(),states[state].defines);
 samples.push({cycle,state,calls:objects.length,elapsedMs});
}
const output={mode:process.env.FRAGMENT_VARIANT,objects:objects.length,kinds:counts,keys:Object.fromEntries(rows.map(row=>[row.kind,Object.keys(row.variantSnapshots.off.values).length])),slots:objects.reduce((n,{d})=>n+d._keys.length*2,0),samples,checksum,scope:'CPU serializer working-set projection:499 actual PBR/Standard define instances from exact prior warm states; updates and validation outside timed interval, additional validation calls disclosed. Not world/GPU/FPS proof.'};assert.ok(process.env.PRESSURE_REPORT);writeFileSync(process.env.PRESSURE_REPORT,JSON.stringify(output,null,2)+'\n',{flag:'wx'});
