// Private QA: F3 name metadata plus a separately bounded primitive-fragment cache.
// Private QA: bounded primitive fragment payloads, separate from F3 name schemas.
var primitiveFragmentHolders = new WeakMap();
var primitiveFragmentQueue = { __proto__: null };
var primitiveFragmentQueueHead = 0;
var primitiveFragmentQueueTail = 0;
var primitiveFragmentSlots = 0;
var primitiveFragmentUnits = 0;
function publishPrimitiveFragments(receiver, names, values, fragments, count, prior) {
    let payload;
    if (!values && prior && count === prior.names.length) {
        payload = prior;
    } else {
        const storedValues = values || { __proto__: null };
        let stringUnits = 0;
        for (let index = 0; index < count; index++) {
            const value = values ? values[index] : prior.values[index];
            if (!values) storedValues[index] = value;
            const fragment = fragments[index];
            if (typeof value === "string") stringUnits += value.length;
            if (typeof fragment === "string") stringUnits += fragment.length;
        }
        // The completed call no longer mutates its private null-prototype scratch.
        payload = Object.freeze({ names, values: Object.freeze(storedValues),
            fragments: Object.freeze(fragments), slots: count * 2, stringUnits });
    }
    let holder = primitiveFragmentHolders.get(receiver);
    // A nested completed call may have published or evicted another payload.
    // Skip only if this completed snapshot is still the resident one.
    if (holder?.payload === payload && holder.queued) return;
    if (!holder) {
        holder = { payload: undefined, queued: false };
        primitiveFragmentHolders.set(receiver, holder);
    }
    if (holder.payload) {
        primitiveFragmentSlots -= holder.payload.slots;
        primitiveFragmentUnits -= holder.payload.stringUnits;
    }
    holder.payload = payload;
    primitiveFragmentSlots += payload.slots;
    primitiveFragmentUnits += payload.stringUnits;
    if (!holder.queued) {
        holder.queued = true;
        primitiveFragmentQueue[primitiveFragmentQueueTail++] = holder;
    }
    while (primitiveFragmentQueueTail - primitiveFragmentQueueHead > 1024 || primitiveFragmentSlots > 524288 || primitiveFragmentUnits > 4194304) {
        const oldest = primitiveFragmentQueue[primitiveFragmentQueueHead];
        delete primitiveFragmentQueue[primitiveFragmentQueueHead++];
        oldest.queued = false;
        if (oldest.payload) {
            primitiveFragmentSlots -= oldest.payload.slots;
            primitiveFragmentUnits -= oldest.payload.stringUnits;
            oldest.payload = undefined;
        }
    }
}

var defineSchemas = new WeakMap();
var defineSchemaReady = false;
var defineSchemaInterns = [];
var defineSchemaInternUnits = 0;
function findInternedDefineSchema(count, names, previousNames) {
    for (const entry of defineSchemaInterns) {
        const candidate = entry.schema;
        if (candidate.names.length !== count) continue;
        // Cheap miss rejection only; a hit still requires the entire sequence.
        if (count > 0 && (candidate.names[0] !== (names ? names[0] : previousNames[0]) ||
            candidate.names[count - 1] !== (names ? names[count - 1] : previousNames[count - 1]))) continue;
        let equal = true;
        for (let index = 0; index < count; index++) {
            if (candidate.names[index] !== (names ? names[index] : previousNames[index])) { equal = false; break; }
        }
        if (equal) return candidate;
    }
    return undefined;
}
function internDefineSchema(names, order, units) {
    // Re-check in case a reentrant completed call published the same shape.
    const prior = findInternedDefineSchema(names.length, names, undefined);
    if (prior) return prior;
    const schema = Object.freeze({ names: Object.freeze(names), order: Object.freeze(order), validNames: true });
    while (defineSchemaInterns.length >= 32 || defineSchemaInternUnits + units > 262144) {
        const oldest = defineSchemaInterns.shift();
        defineSchemaInternUnits -= oldest.units;
    }
    defineSchemaInterns.push(Object.freeze({ schema, units }));
    defineSchemaInternUnits += units;
    return schema;
}


const schemaNamePattern = /^[A-Za-z_][A-Za-z0-9_]*(?![\s\S])/;
const schemaLiteralPattern = /^[+-]?(?:(?:0|[1-9][0-9]*)(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?(?![\s\S])/;
const SCHEMA_MAX_NAMES = 1024, SCHEMA_MAX_NAME_UNITS = 32768;

/**
 * Manages the defines for the Material
 */
export class MaterialDefines {
    /**
     * Creates a new instance
     * @param externalProperties list of external properties to inject into the object
     */
    constructor(externalProperties) {
        this.VERTEXOUTPUT_INVARIANT = false;
        /** @internal */
        this._keys = [];
        this._isDirty = true;
        /** @internal */
        this._areLightsDirty = true;
        /** @internal */
        this._areLightsDisposed = false;
        /** @internal */
        this._areAttributesDirty = true;
        /** @internal */
        this._areTexturesDirty = true;
        /** @internal */
        this._areFresnelDirty = true;
        /** @internal */
        this._areMiscDirty = true;
        /** @internal */
        this._arePrePassDirty = true;
        /** @internal */
        this._areImageProcessingDirty = true;
        /** @internal */
        this._normals = false;
        /** @internal */
        this._uvs = false;
        /** @internal */
        this._needNormals = false;
        /** @internal */
        this._needUVs = false;
        this._externalProperties = externalProperties;
        // Initialize External Properties
        if (externalProperties) {
            for (const prop in externalProperties) {
                if (Object.prototype.hasOwnProperty.call(externalProperties, prop)) {
                    this._setDefaultValue(prop);
                }
            }
        }
    }
    /**
     * Specifies if the material needs to be re-calculated
     */
    get isDirty() {
        return this._isDirty;
    }
    /**
     * Marks the material to indicate that it has been re-calculated
     */
    markAsProcessed() {
        this._isDirty = false;
        this._areAttributesDirty = false;
        this._areTexturesDirty = false;
        this._areFresnelDirty = false;
        this._areLightsDirty = false;
        this._areLightsDisposed = false;
        this._areMiscDirty = false;
        this._arePrePassDirty = false;
        this._areImageProcessingDirty = false;
    }
    /**
     * Marks the material to indicate that it needs to be re-calculated
     */
    markAsUnprocessed() {
        this._isDirty = true;
    }
    /**
     * Marks the material to indicate all of its defines need to be re-calculated
     */
    markAllAsDirty() {
        this._areTexturesDirty = true;
        this._areAttributesDirty = true;
        this._areLightsDirty = true;
        this._areFresnelDirty = true;
        this._areMiscDirty = true;
        this._arePrePassDirty = true;
        this._areImageProcessingDirty = true;
        this._isDirty = true;
    }
    /**
     * Marks the material to indicate that image processing needs to be re-calculated
     */
    markAsImageProcessingDirty() {
        this._areImageProcessingDirty = true;
        this._isDirty = true;
    }
    /**
     * Marks the material to indicate the lights need to be re-calculated
     * @param disposed Defines whether the light is dirty due to dispose or not
     */
    markAsLightDirty(disposed = false) {
        this._areLightsDirty = true;
        this._areLightsDisposed = this._areLightsDisposed || disposed;
        this._isDirty = true;
    }
    /**
     * Marks the attribute state as changed
     */
    markAsAttributesDirty() {
        this._areAttributesDirty = true;
        this._isDirty = true;
    }
    /**
     * Marks the texture state as changed
     */
    markAsTexturesDirty() {
        this._areTexturesDirty = true;
        this._isDirty = true;
    }
    /**
     * Marks the fresnel state as changed
     */
    markAsFresnelDirty() {
        this._areFresnelDirty = true;
        this._isDirty = true;
    }
    /**
     * Marks the misc state as changed
     */
    markAsMiscDirty() {
        this._areMiscDirty = true;
        this._isDirty = true;
    }
    /**
     * Marks the prepass state as changed
     */
    markAsPrePassDirty() {
        this._arePrePassDirty = true;
        this._isDirty = true;
    }
    /**
     * Rebuilds the material defines
     */
    rebuild() {
        this._keys.length = 0;
        for (const key of Object.keys(this)) {
            if (key[0] === "_") {
                continue;
            }
            this._keys.push(key);
        }
        if (this._externalProperties) {
            for (const name in this._externalProperties) {
                if (this._keys.indexOf(name) === -1) {
                    this._keys.push(name);
                }
            }
        }
    }
    /**
     * Specifies if two material defines are equal
     * @param other - A material define instance to compare to
     * @returns - Boolean indicating if the material defines are equal (true) or not (false)
     */
    isEqual(other) {
        if (this._keys.length !== other._keys.length) {
            return false;
        }
        for (let index = 0; index < this._keys.length; index++) {
            const prop = this._keys[index];
            if (this[prop] !== other[prop]) {
                return false;
            }
        }
        return true;
    }
    /**
     * Clones this instance's defines to another instance
     * @param other - material defines to clone values to
     */
    cloneTo(other) {
        if (this._keys.length !== other._keys.length) {
            other._keys = this._keys.slice(0);
        }
        for (let index = 0; index < this._keys.length; index++) {
            const prop = this._keys[index];
            other[prop] = this[prop];
        }
    }
    /**
     * Resets the material define values
     */
    reset() {
        for (const prop of this._keys) {
            this._setDefaultValue(prop);
        }
    }
    _setDefaultValue(prop) {
        const type = this._externalProperties?.[prop]?.type ?? typeof this[prop];
        const defValue = this._externalProperties?.[prop]?.default;
        switch (type) {
            case "number":
                this[prop] = defValue ?? 0;
                break;
            case "string":
                this[prop] = defValue ?? "";
                break;
            default:
                this[prop] = defValue ?? false;
                break;
        }
    }
    /**
     * Converts the material define values to a string
     * @returns - String of material define information
     */
    toString() {
        const cacheable = this !== null && (typeof this === "object" || typeof this === "function");
        let schema = cacheable && defineSchemaReady ? defineSchemas.get(this) : undefined;
        const priorFragments = cacheable && defineSchemaReady ? primitiveFragmentHolders.get(this)?.payload : undefined;
        let primitiveValues = priorFragments ? null : { __proto__: null };
        const fragments = { __proto__: null };
        let names = schema ? null : { __proto__: null };
        let matches = !!schema, count = 0, chars = 0, rows = 0, safeValues = true;
        for (let index = 0; index < this._keys.length; index++) {
            const prop = this._keys[index];
            const value = this[prop];
            const type = typeof value;
            let fragment;
            const reused = !!priorFragments && typeof prop === "string" && priorFragments.names[index] === prop && Object.is(priorFragments.values[index], value);
            if (reused) {
                fragment = priorFragments.fragments[index];
            } else {
                switch (type) {
                    case "number":
                    case "string":
                        fragment = "#define " + prop + " " + value + "\n";
                        break;
                    default:
                        if (value) {
                            fragment = "#define " + prop + "\n";
                        }
                        break;
                }
                if (type === "number") safeValues = safeValues && Number.isFinite(value);
                else if (type === "string") safeValues = safeValues && schemaLiteralPattern.test(value) && Number.isFinite(Number(value));
                else if (type !== "boolean" && type !== "undefined" && value !== null) safeValues = false;
                if (!primitiveValues) {
                    primitiveValues = { __proto__: null };
                    for (let previous = 0; previous < index && previous < SCHEMA_MAX_NAMES; previous++) primitiveValues[previous] = priorFragments.values[previous];
                }
            }
            if (primitiveValues && index < SCHEMA_MAX_NAMES && (type === "number" || type === "string" || type === "boolean" || type === "undefined" || value === null)) primitiveValues[index] = value;
            fragments[index] = fragment;
            if (fragment !== undefined) { chars += fragment.length; rows++; }
            if (matches && schema.names[index] !== prop) {
                matches = false;
                names = { __proto__: null };
                for (let previous = 0; previous < index && previous < SCHEMA_MAX_NAMES; previous++) names[previous] = schema.names[previous];
            }
            if (names && index < SCHEMA_MAX_NAMES) names[index] = prop;
            count++;
        }
        if (matches && count !== schema.names.length) matches = false;
        let sharedPointer = false;
        if (cacheable && defineSchemaReady && !matches && count <= SCHEMA_MAX_NAMES) {
            const shared = findInternedDefineSchema(count, names, schema?.names);
            if (shared) { schema = shared; matches = true; sharedPointer = true; }
        }
        if (matches && safeValues && chars <= 32768 && rows <= 1024) {
            let result = "";
            for (const index of schema.order) { const fragment = fragments[index]; if (fragment !== undefined) result += fragment; }
            if (sharedPointer) defineSchemas.set(this, schema);
            publishPrimitiveFragments(this, schema.names, primitiveValues, fragments, count, priorFragments);
            return result;
        }
        let raw = "";
        for (let index = 0; index < count; index++) { const fragment = fragments[index]; if (fragment !== undefined) raw += fragment; }
        const result = canonicalResult(raw);
        if (sharedPointer) defineSchemas.set(this, schema);
        if (cacheable && defineSchemaReady && count <= SCHEMA_MAX_NAMES && !matches) {
            const observed = [], seen = new Set();
            let units = 0, valid = true;
            for (let index = 0; index < count; index++) {
                const name = names ? names[index] : schema.names[index];
                if (typeof name !== "string" || !schemaNamePattern.test(name) || name.includes("__") || name.startsWith("GL_") || reserved.has(name) || seen.has(name)) { valid = false; break; }
                units += name.length;
                if (units > SCHEMA_MAX_NAME_UNITS) { valid = false; break; }
                seen.add(name); observed.push(name);
            }
            if (valid) {
                const order = observed.map((_, index) => index).sort((a, b) => observed[a] < observed[b] ? -1 : observed[a] > observed[b] ? 1 : 0);
                schema = internDefineSchema(observed, order, units);
                defineSchemas.set(this, schema);
                if (safeValues && chars <= 32768 && rows <= 1024) publishPrimitiveFragments(this, schema.names, primitiveValues, fragments, count, priorFragments);
            }
        }
        return result;
    }
}
// Project QA: bounded flat-literal serialization only. Custom order-sensitive
// processors are outside the verified contract; no universal API guarantee.
/** Project QA candidate derived from the accepted isolated CPU proof.
 * Input contract: a completed flat literal define block, not arbitrary shader
 * preprocessor text. canonicalResult itself has no property reads, _keys changes or persistent cache.
 */
const MAX_CHARS = 32768;
const MAX_DEFINES = 1024;
// Signed decimal constants cover native -1 indices and PBR numeric strings.
// Hex/suffixes/expressions are deliberately outside this proof's contract.
const literal = '[+-]?(?:(?:0|[1-9][0-9]*)(?:\\.[0-9]*)?|\\.[0-9]+)(?:[eE][+-]?[0-9]+)?';
const linePattern = new RegExp(`^#define ([A-Za-z_][A-Za-z0-9_]*)(?: (${literal}))?$`);
const reserved = new Set(['defined', 'true', 'false', 'WEBGPU', 'WEBGL1', 'WEBGL2', 'NATIVE', 'IS_NDC_HALF_ZRANGE', 'USE_REVERSE_DEPTHBUFFER', 'USE_EXACT_SRGB_CONVERSIONS', ...Object.getOwnPropertyNames(Object.prototype)]);
function canonicalResult(text) {
    if (!text || text.length > MAX_CHARS || !text.endsWith('\n') || /[^\x20-\x7e\n]/.test(text))
        return text;
    const lines = text.slice(0, -1).split('\n');
    if (lines.length > MAX_DEFINES)
        return text;
    const seen = new Set();
    const records = [];
    for (const line of lines) {
        const match = linePattern.exec(line);
        if (!match)
            return text;
        const [, name, value] = match;
        if (name.includes('__') || name.startsWith('GL_') || reserved.has(name) || seen.has(name) || value !== undefined && !Number.isFinite(Number(value)))
            return text;
        seen.add(name);
        records.push({ name, line });
    }
    records.sort((a, b) => a.name < b.name ? -1 : a.name > b.name ? 1 : 0);
    return records.map(record => record.line).join('\n') + '\n';
}
//# sourceMappingURL=materialDefines.js.map
defineSchemaReady = true;
