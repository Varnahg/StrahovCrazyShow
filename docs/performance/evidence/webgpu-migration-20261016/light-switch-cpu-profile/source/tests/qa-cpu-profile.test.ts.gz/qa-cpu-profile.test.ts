import test from "node:test";
import assert from "node:assert/strict";
import { createCpuSampler, type CpuProfiler, type CpuProfileEntry } from "../client/qa-cpu-profile";

function fixture() {
  let resolve!: (trace: unknown) => void, reject!: (error: unknown) => void;
  const pending = new Promise<unknown>((yes, no) => { resolve = yes; reject = no; });
  let now = 100, created = 0, stops = 0, removals = 0;
  const listeners = new Set<() => void>(), entries: CpuProfileEntry[] = [];
  const profiler: CpuProfiler = {
    sampleInterval: 16.7,
    stop: () => { stops++; return pending; },
    addEventListener: (type, listener) => { assert.equal(type, "samplebufferfull"); listeners.add(listener); },
    removeEventListener: (type, listener) => { assert.equal(type, "samplebufferfull"); removals++; listeners.delete(listener); },
  };
  const runtime = {
    create: (): CpuProfiler | undefined => { created++; return profiler; },
    now: () => now,
    timeOrigin: () => 1720000000000,
    publish: (entry: CpuProfileEntry) => { entries.push(entry); },
  };
  const sampler = createCpuSampler(runtime);
  return { sampler, runtime, profiler, entries, resolve, reject, listeners,
    setNow: (value: number) => { now = value; }, counts: () => ({ created, stops, removals }) };
}
const flush = async () => { await Promise.resolve(); await Promise.resolve(); };

test("one owned capture; stop once; no export until Promise resolves; preserve raw trace and clocks", async () => {
  const x = fixture(), stop = x.sampler.begin();
  assert.equal(typeof stop, "function"); assert.equal(x.sampler.begin(), undefined);
  assert.equal(x.listeners.size, 1); assert.equal(x.entries.length, 0);
  x.setNow(10100); stop!("benchmark-end"); stop!("dispose");
  assert.equal(x.listeners.size, 0); assert.equal(x.sampler.begin(), undefined);
  assert.deepEqual(x.counts(), { created: 1, stops: 1, removals: 1 });
  const raw = { samples: [{ timestamp: 900, stackId: 0 }], stacks: [{ frameId: 0 }], frames: [], resources: [] };
  x.resolve(raw); assert.equal(x.entries.length, 0); await flush();
  assert.deepEqual(x.entries[0], { id: 1, status: "captured", reason: "benchmark-end", timeOrigin: 1720000000000,
    startedAtMs: 100, stoppedAtMs: 10100, sampleInterval: 16.7, trace: raw });
  assert.equal(x.entries[0].trace, raw); assert.equal(typeof x.sampler.begin(), "function");
});

test("construction and synchronous stop reentrance cannot create a second profiler", async () => {
  const x = fixture(), create = x.runtime.create, stop = x.profiler.stop;
  x.runtime.create = () => { assert.equal(x.sampler.begin(), undefined); return create(); };
  x.profiler.stop = () => { assert.equal(x.sampler.begin(), undefined); return stop(); };
  x.sampler.begin()!("restart"); assert.equal(x.sampler.begin(), undefined);
  x.resolve({}); await flush(); assert.deepEqual(x.counts(), { created: 1, stops: 1, removals: 1 });
});

test("old stop closure cannot touch a reentrant new capture published after settlement", async () => {
  const x = fixture(); let next: ((reason: string) => void) | undefined;
  x.runtime.publish = entry => { x.entries.push(entry); next = x.sampler.begin(); };
  const first = x.sampler.begin()!; first("restart"); x.resolve({}); await flush();
  assert.equal(typeof next, "function"); first("stale-dispose");
  assert.deepEqual(x.counts(), { created: 2, stops: 1, removals: 1 });
  assert.equal(x.entries.length, 1); assert.equal(x.listeners.size, 1);
});

test("samplebufferfull stops and detaches once; late manual stop preserves reason", async () => {
  const x = fixture(), stop = x.sampler.begin()!;
  x.setNow(800); const bufferFull = [...x.listeners][0]; bufferFull(); bufferFull(); stop("benchmark-end");
  assert.equal(x.listeners.size, 0); assert.equal(x.sampler.begin(), undefined);
  x.resolve({ samples: [] }); await flush();
  assert.equal(x.entries[0].reason, "buffer-full"); assert.equal(x.entries[0].stoppedAtMs, 800);
  assert.equal(x.counts().stops, 1);
});

test("unavailable and constructor exceptions publish truthful status and release reservation", () => {
  const x = fixture(); x.runtime.create = () => undefined;
  assert.equal(x.sampler.begin(), undefined); assert.equal(x.entries[0].status, "unavailable");
  x.runtime.create = () => { throw new Error("policy denied"); };
  assert.equal(x.sampler.begin(), undefined); assert.equal(x.entries[1].status, "error");
  assert.match(x.entries[1].error!, /policy denied/); assert.equal(x.entries[1].id, 2);
  x.runtime.create = () => x.profiler; assert.equal(typeof x.sampler.begin(), "function");
});

for (const synchronous of [false, true]) test(`stop ${synchronous ? "throw" : "rejection"} is handled asynchronously and unblocks next capture`, async () => {
  const x = fixture();
  if (synchronous) x.profiler.stop = () => { throw new Error("sync stop failure"); };
  const stop = x.sampler.begin()!;
  assert.doesNotThrow(() => stop("renderer-failure")); assert.equal(x.entries.length, 0);
  assert.equal(x.sampler.begin(), undefined);
  if (!synchronous) x.reject(new Error("async stop failure"));
  await flush(); assert.equal(x.entries[0].status, "error"); assert.match(x.entries[0].error!, /stop failure/);
  assert.equal(x.entries[0].reason, "renderer-failure"); assert.equal(typeof x.sampler.begin(), "function");
});

test("publisher exceptions never escape or leave sampler busy", async () => {
  const x = fixture(); x.runtime.publish = () => { throw new Error("broken DOM"); };
  const stop = x.sampler.begin()!; stop("dispose"); x.resolve({}); await flush();
  assert.equal(typeof x.sampler.begin(), "function");
  const y = fixture(); y.runtime.create = () => undefined; y.runtime.publish = x.runtime.publish;
  assert.doesNotThrow(() => y.sampler.begin()); assert.doesNotThrow(() => y.sampler.begin());
});

test("listener failures still stop constructed profiler and remove failure cannot suppress stop", async () => {
  const x = fixture(); x.profiler.addEventListener = () => { throw new Error("listener"); };
  x.profiler.removeEventListener = () => { throw new Error("remove"); };
  assert.equal(x.sampler.begin(), undefined); assert.equal(x.sampler.begin(), undefined);
  assert.equal(x.counts().stops, 1); x.resolve({}); await flush();
  assert.equal(x.entries[0].reason, "initialization-error");
  assert.equal(x.entries[0].status, "error"); assert.match(x.entries[0].error!, /listener/);
  x.profiler.addEventListener = () => {}; assert.equal(typeof x.sampler.begin(), "function");
});

test("clock failures and unprintable errors cannot leak exceptions", () => {
  const x = fixture(); x.runtime.now = () => { throw new Error("clock"); };
  x.runtime.timeOrigin = () => { throw new Error("origin"); };
  x.runtime.create = () => { throw { toString() { throw new Error("string"); } }; };
  assert.doesNotThrow(() => x.sampler.begin()); assert.equal(x.entries[0].error, "Unknown profiler failure");
  assert.ok(Number.isNaN(x.entries[0].startedAtMs)); assert.ok(Number.isNaN(x.entries[0].timeOrigin));
});

test("default singleton constructs exactly 16ms/2000 and publishes only last raw trace in owned DOM", async () => {
  const previousWindow = Object.getOwnPropertyDescriptor(globalThis, "window");
  const previousDocument = Object.getOwnPropertyDescriptor(globalThis, "document");
  const nodes: { tag: string; id?: string; textContent?: string; style: { cssText: string }; children: unknown[]; append(...children: unknown[]): void }[] = [];
  const element = (tag: string) => {
    const node = { tag, style: { cssText: "" }, children: [] as unknown[], append(...children: unknown[]) { this.children.push(...children); } };
    nodes.push(node); return node;
  };
  const body = element("body"); let created = 0; const traces = [{ samples: [1] }, { samples: [2] }];
  class BrowserProfiler {
    sampleInterval = 16; index = created++;
    constructor(options: unknown) { assert.deepEqual(options, { sampleInterval: 16, maxBufferSize: 2000 }); }
    addEventListener() {} removeEventListener() {}
    stop() { return Promise.resolve(traces[this.index]); }
  }
  Object.defineProperty(globalThis, "window", { configurable: true, value: { Profiler: BrowserProfiler } });
  Object.defineProperty(globalThis, "document", { configurable: true, value: { body, createElement: element } });
  try {
    const { beginQaCpuProfile } = await import("../client/qa-cpu-profile");
    beginQaCpuProfile()!("benchmark-end"); assert.equal(beginQaCpuProfile(), undefined);
    assert.equal(nodes.length, 1); await flush();
    const pre = nodes.find(node => node.tag === "pre")!;
    assert.equal(pre.id, "cpu-profile-result"); assert.deepEqual(JSON.parse(pre.textContent!).trace, traces[0]);
    beginQaCpuProfile()!("dispose"); await flush();
    assert.deepEqual(JSON.parse(pre.textContent!).trace, traces[1]);
    assert.equal(nodes.filter(node => node.tag === "pre").length, 1);
    assert.equal(nodes.filter(node => node.tag === "details").length, 1);
  } finally {
    if (previousWindow) Object.defineProperty(globalThis, "window", previousWindow); else Reflect.deleteProperty(globalThis, "window");
    if (previousDocument) Object.defineProperty(globalThis, "document", previousDocument); else Reflect.deleteProperty(globalThis, "document");
  }
});
