// Temporary copied QA code. No session recorder, transport, or production hook.
export interface CpuProfiler {
  readonly sampleInterval: number;
  stop(): Promise<unknown>;
  addEventListener(type: "samplebufferfull", listener: () => void): void;
  removeEventListener(type: "samplebufferfull", listener: () => void): void;
}

export interface CpuProfileEntry {
  id: number;
  status: "captured" | "unavailable" | "error";
  reason: string;
  timeOrigin: number;
  startedAtMs: number;
  stoppedAtMs: number;
  sampleInterval: number | null;
  trace?: unknown;
  error?: string;
}

export interface CpuSamplerRuntime {
  create(): CpuProfiler | undefined;
  now(): number;
  timeOrigin(): number;
  publish(entry: CpuProfileEntry): void;
}

export function createCpuSampler(runtime: CpuSamplerRuntime) {
  let nextId = 0;
  let busy = false;
  const publish = (entry: CpuProfileEntry) => {
    try { runtime.publish(entry); } catch { /* Export cannot break rendering. */ }
  };
  const clock = (read: () => number) => {
    try { return read(); } catch { return Number.NaN; }
  };
  const errorText = (error: unknown) => {
    try { return String(error); } catch { return "Unknown profiler failure"; }
  };

  return {
    begin(): ((reason: string) => void) | undefined {
      if (busy) return undefined;
      // Reserve before construction: injected constructors may call back.
      busy = true;
      const metadata = {
        id: ++nextId,
        timeOrigin: clock(() => runtime.timeOrigin()),
        startedAtMs: clock(() => runtime.now()),
        stoppedAtMs: Number.NaN,
        sampleInterval: null as number | null,
      };
      let profiler: CpuProfiler | undefined;
      let stopping = false;
      let initializationError: string | undefined;
      const finish = (entry: CpuProfileEntry) => {
        busy = false;
        publish(entry);
      };
      const stop = (reason: string) => {
        if (stopping || !profiler) return;
        stopping = true;
        metadata.stoppedAtMs = clock(() => runtime.now());
        try { profiler.removeEventListener("samplebufferfull", onBufferFull); } catch { /* Still stop. */ }
        let operation: Promise<unknown>;
        try { operation = profiler.stop(); }
        catch (error) {
          // Even synchronous failures publish after the caller closes metrics.
          operation = Promise.reject(error);
        }
        void Promise.resolve(operation).then(
          trace => finish(initializationError === undefined
            ? { ...metadata, status: "captured", reason, trace }
            : { ...metadata, status: "error", reason, error: initializationError, trace }),
          error => finish({ ...metadata, status: "error", reason, error: errorText(error) }),
        );
      };
      const onBufferFull = () => stop("buffer-full");
      try {
        profiler = runtime.create();
        if (!profiler) {
          metadata.stoppedAtMs = clock(() => runtime.now());
          finish({ ...metadata, status: "unavailable", reason: "unavailable" });
          return undefined;
        }
        metadata.sampleInterval = profiler.sampleInterval;
        profiler.addEventListener("samplebufferfull", onBufferFull);
        return stop;
      } catch (error) {
        if (profiler) {
          initializationError = errorText(error);
          stop("initialization-error");
        } else {
          metadata.stoppedAtMs = clock(() => runtime.now());
          finish({ ...metadata, status: "error", reason: "initialization-error", error: errorText(error) });
        }
        return undefined;
      }
    },
  };
}

let output: { panel: HTMLDetailsElement; pre: HTMLPreElement } | undefined;
function publishToDom(entry: CpuProfileEntry) {
  if (typeof document === "undefined") return;
  if (!output) {
    const panel = document.createElement("details");
    panel.style.cssText = "position:fixed;bottom:8px;left:8px;z-index:2147483647;max-width:90vw;max-height:45vh;overflow:auto;background:#111;color:#fff;padding:8px;font:12px monospace";
    const summary = document.createElement("summary");
    summary.textContent = "QA CPU profile — last export";
    const pre = document.createElement("pre");
    pre.id = "cpu-profile-result";
    panel.append(summary, pre);
    document.body.append(panel);
    output = { panel, pre };
  }
  // The sampler calls this only after stop settles (or before an unavailable run).
  output.pre.textContent = JSON.stringify(entry);
}

const qaSampler = createCpuSampler({
  create: () => {
    if (typeof window === "undefined") return undefined;
    const Constructor = (window as unknown as {
      Profiler?: new (options: { sampleInterval: number; maxBufferSize: number }) => CpuProfiler;
    }).Profiler;
    return Constructor ? new Constructor({ sampleInterval: 16, maxBufferSize: 2000 }) : undefined;
  },
  now: () => performance.now(),
  timeOrigin: () => performance.timeOrigin,
  publish: publishToDom,
});

export function beginQaCpuProfile(): ((reason: string) => void) | undefined {
  return qaSampler.begin();
}
