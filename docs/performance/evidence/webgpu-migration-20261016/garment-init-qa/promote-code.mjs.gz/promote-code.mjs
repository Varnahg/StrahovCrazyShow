import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync,mkdirSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const root=import.meta.dirname,repo=resolve(root,'../..'),main='C:/Users/rezac/Documents/GitHub/StrahovCrazyShow',native=resolve(root,'../webgpu-garment-init-native-20261019');
const hash=b=>createHash('sha256').update(b).digest('hex'),git=(cwd,args)=>execFileSync('git',args,{cwd,encoding:'utf8',maxBuffer:64*1024*1024}).trim();
// This script is prepared under QA ownership; it may execute only after the
// dependency gate and a successful distinct native reservation.
execFileSync(process.execPath,['scripts/agent-tasks.mjs','heartbeat','--task','webgpu-garment-init-native-20261019','--owner','webgpu-01a15102-garment-init-native'],{cwd:repo,stdio:'inherit'});
const validated=JSON.parse(readFileSync(join(root,'checkpoint-validated.json'))),gpu=JSON.parse(readFileSync(join(root,'gpu-acceptance.json')));
assert.equal(validated.allPassed,true);assert.equal(validated.jobs,6);assert.equal(gpu.accepted,true);assert.equal(gpu.scope,'garment initialization only');assert.equal(gpu.source,'c29a7da7dd9e66024a8ae59db803ef1b0e16a74d62ab0e533d8ac2821c49fe58');
for(const[p,h]of Object.entries(gpu.images))assert.equal(hash(readFileSync(join(root,p))),h,p);
const expected={'client/avatar-garments.ts':'068dc194c63ad686269f80f4b55bb177cb6e16eac67e284a4544cd92b8d604e1','tests/student-garment-init.test.ts':'a8817fe6f5cdd9e2cd881670b3cb6bfbbbd2bbad4f12f72dd6b8c0d3e3fa721a'},paths=Object.keys(expected);
for(const p of paths)assert.equal(hash(readFileSync(join(root,'snapshot',p))),expected[p],p);
for(const cwd of [repo,main]){assert.equal(hash(readFileSync(join(cwd,paths[0]))),'40173ae81387516755d96b8097b0b331dd1e96b5d3cf183a85b8462eed4f8f6d');assert.equal(existsSync(join(cwd,paths[1])),false);assert.equal(git(cwd,['diff','--cached','--name-only']),'');}
assert.equal(git(main,['branch','--show-current']),'main');assert.equal(git(repo,['rev-parse','HEAD^{tree}']),git(main,['rev-parse','HEAD^{tree}']));
const owned=[...paths,'docs/agents/tasks/webgpu-garment-init-helper-20261019.json','docs/agents/tasks/webgpu-garment-init-qa-20261019.json','docs/agents/tasks/webgpu-garment-init-integration-20261019.json','docs/agents/tasks/webgpu-garment-init-native-20261019.json','docs/agents/handoffs/webgpu-garment-init-helper-20261019.md','docs/agents/handoffs/webgpu-garment-init-qa-20261019.md','docs/agents/handoffs/webgpu-garment-init-integration-20261019.md','docs/agents/handoffs/webgpu-garment-init-native-20261019.md','docs/performance/evidence/webgpu-migration-20261016/garment-init-qa/','_bmad-output/implementation-artifacts/webgpu-garment-init-qa-20261019/'];
const isOwn=p=>owned.some(x=>p===x||p.startsWith(x.endsWith('/')?x:x+'/'));
const foreign=cwd=>Object.fromEntries([...new Set([...git(cwd,['diff','--name-only','-z']).split('\0'),...git(cwd,['ls-files','--others','--exclude-standard','-z']).split('\0')])].filter(p=>p&&!isOwn(p)).sort().map(p=>[p,existsSync(join(cwd,p))?hash(readFileSync(join(cwd,p))):null]));
const before=foreign(repo),beforeMain=foreign(main),base=git(repo,['rev-parse','HEAD']),mainBase=git(main,['rev-parse','HEAD']);assert.equal(Object.keys(before).length,133);assert.equal(Object.keys(beforeMain).length,133);
for(const p of paths)writeFileSync(join(repo,p),readFileSync(join(root,'snapshot',p)));
git(repo,['diff','--check','--',...paths]);git(repo,['add','--',...paths]);assert.deepEqual(git(repo,['diff','--cached','--name-only','-z']).split('\0').filter(Boolean).sort(),paths.slice().sort());
git(repo,['commit','-m','perf(avatars): batch initial garment material updates']);const commit=git(repo,['rev-parse','HEAD']);assert.deepEqual(foreign(repo),before);
git(main,['cherry-pick',commit]);const integrated=git(main,['rev-parse','HEAD']);assert.deepEqual(foreign(main),beforeMain);assert.equal(git(repo,['rev-parse','HEAD^{tree}']),git(main,['rev-parse','HEAD^{tree}']));
for(const cwd of [repo,main]){for(const p of paths)assert.equal(hash(readFileSync(join(cwd,p))),expected[p]);assert.equal(git(cwd,['diff','--cached','--name-only']),'');}
mkdirSync(native,{recursive:true});writeFileSync(join(native,'integration-receipt.json'),JSON.stringify({commit,integrated,base,mainBase,paths,expected,foreignCount:133,primaryForeignCount:133,foreignBytesPreserved:true,qaSources:validated.sources,gpuSource:gpu.source,scope:'Initial garment CPU traversal reduction only; full KEY31/32/default/migration remains open.'},null,2)+'\n');
console.log(JSON.stringify({commit,integrated,paths,foreignBytesPreserved:true}));
