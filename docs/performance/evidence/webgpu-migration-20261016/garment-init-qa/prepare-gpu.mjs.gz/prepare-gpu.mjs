import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
const root=import.meta.dirname,v=JSON.parse(readFileSync(join(root,'checkpoint-validated.json'))),m=JSON.parse(readFileSync(join(root,'combined/source-manifest.json')));assert.equal(v.allPassed,true);assert.ok(v.sources.includes(m.snapshotId));
for(const name of ['start.ps1','stop.ps1']){const text=readFileSync(join(root,name),'utf8');assert.ok(text.includes("'snapshot'"));writeFileSync(join(root,name.replace('.ps1','-combined.ps1')),text.replaceAll("'snapshot'","'combined'"));}
const p=JSON.parse(readFileSync(join(root,'protocol.json')));p.source=m.snapshotId;p.scope='Plain known-combined production garment initialization candidate; limited functional/image smoke, no matched FPS A/B.';writeFileSync(join(root,'protocol.json'),JSON.stringify(p,null,2)+'\n');
let promote=readFileSync(join(root,'promote-code.mjs'),'utf8');promote=promote.replace("assert.equal(gpu.source,'06754993e63049552768a7114f7a7fb8233cae0c2770a23336e9e071df8bc220');",`assert.equal(gpu.source,'${m.snapshotId}');`);writeFileSync(join(root,'promote-code.mjs'),promote);console.log(JSON.stringify({gpuSource:m.snapshotId,validatedSources:v.sources}));
