import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,existsSync,symlinkSync,realpathSync} from 'node:fs';
import {join,dirname,resolve,basename} from 'node:path';
import {createHash} from 'node:crypto';
const root=import.meta.dirname,base=resolve(root,'../webgpu-shadow-share-native-qa-20261019/clean'),helper=resolve(root,'../webgpu-garment-init-helper-20261019'),out=join(root,'snapshot');
const hash=b=>createHash('sha256').update(b).digest('hex'),m=JSON.parse(readFileSync(join(base,'source-manifest.json')));
assert.equal(m.snapshotId,'8fb217a11a338de1cc687b953177d6cad8291e5f67bb2e1d02d781c4a6ab320e');assert.equal(hash(JSON.stringify(m.files)),m.snapshotId);assert.ok(!existsSync(out));
const inverse=JSON.parse(readFileSync(join(helper,'source-inverse.json'))),payload=readFileSync(join(helper,'candidate/client/avatar-garments.ts')),testPath=resolve(process.argv[2]),testName='tests/'+basename(testPath);
assert.equal(inverse.before,m.files['client/avatar-garments.ts']);assert.equal(inverse.candidate,'068dc194c63ad686269f80f4b55bb177cb6e16eac67e284a4544cd92b8d604e1');assert.equal(hash(payload),inverse.candidate);assert.equal(inverse.inverseExact,true);assert.match(testName,/\.test\.ts$/);assert.equal(m.files[testName],undefined);
mkdirSync(out,{recursive:true});const files={...m.files};
function put(p,b){mkdirSync(dirname(join(out,p)),{recursive:true});writeFileSync(join(out,p),b);files[p]=hash(b);}
for(const[p,sha]of Object.entries(m.files)){const b=readFileSync(join(base,p));assert.equal(hash(b),sha,p);put(p,b);}
put('client/avatar-garments.ts',payload);put(testName,readFileSync(testPath));
for(const p of ['assets','public','docs','node_modules'])symlinkSync(realpathSync(join(base,p)),join(out,p),'junction');
assert.equal(hash(readFileSync(join(out,'node_modules/@babylonjs/core/Materials/Textures/texture.pure.js'))),'f27fd4a566579ea2cc99c43ae056e48546b3d433aded037ab97c997c6299a976');assert.equal(hash(readFileSync(join(out,'node_modules/@babylonjs/core/Materials/shadowDepthWrapper.js'))),'f8a8c6091af9caa96ba897f28d7d490f3607d7856dee86b3a05321e1477aba29');
const snapshotId=hash(JSON.stringify(files));writeFileSync(join(out,'source-manifest.json'),JSON.stringify({snapshotId,base:m.snapshotId,files},null,2)+'\n');
writeFileSync(join(root,'assembly.json'),JSON.stringify({snapshotId,files:Object.keys(files).length,base:m.snapshotId,changes:['client/avatar-garments.ts',testName],before:inverse.before,after:inverse.candidate,inverseExact:true,scope:'Ordinary production source, public initial material batch only; no SDK transform, profiler or extra cache.'},null,2)+'\n');
for(const name of ['start.ps1','stop.ps1','preview.mjs','weather.json','collect.mjs','gpu-state.mjs']){
 let t=readFileSync(resolve(root,'../webgpu-first-uv-qa-20261019',name),'utf8').replaceAll('webgpu-first-uv-qa-20261019','webgpu-garment-init-qa-20261019').replaceAll('webgpu-01a15102-first-uv-qa','webgpu-01a15102-garment-init-qa');writeFileSync(join(root,name),t);
}
const validation=readFileSync(resolve(root,'../webgpu-medium-cpu-profile-20261019/validate.mjs'),'utf8')
 .replace("'tests/qa-cpu-profile.test.ts','tests/game-light-switch-profile.test.ts','tests/mesh-draw-profile.test.ts'",`'${testName}','tests/student-garments.test.ts'`)
 .replace(",'--sourcemap','hidden'",'').replaceAll('v2-','qa-');writeFileSync(join(root,'validate.mjs'),validation);
const protocol=JSON.parse(readFileSync(resolve(root,'../webgpu-first-uv-qa-20261019/protocol.json')));protocol.source=snapshotId;protocol.conditions.route=['D550','benchmark10s','E','W8000','space2500'];protocol.scope='Plain production garment initialization batch candidate; limited smoke, no matched FPS A/B.';writeFileSync(join(root,'protocol.json'),JSON.stringify(protocol,null,2)+'\n');
console.log(JSON.stringify({snapshotId,files:Object.keys(files).length,testName,payload:inverse.candidate}));
