import fs from 'node:fs';
import path from 'node:path';
import {registerHooks,createRequire} from 'node:module';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
export const own=path.dirname(fileURLToPath(import.meta.url));
export const clean=path.resolve(own,'../webgpu-shadow-share-native-qa-20261019/clean');
export const core=fs.realpathSync(path.join(clean,'node_modules/@babylonjs/core'));
const require=createRequire(path.join(clean,'package.json')),ts=require('typescript');
const target=path.join(clean,'client/avatar-garments.ts');
const payload=path.resolve(process.env.GARMENT_MODULE||path.join(own,'candidate/client/avatar-garments.ts'));
const sha=b=>createHash('sha256').update(b).digest('hex');
if(sha(fs.readFileSync(target))!=='40173ae81387516755d96b8097b0b331dd1e96b5d3cf183a85b8462eed4f8f6d')throw Error('Unexpected garment base');
if(sha(fs.readFileSync(payload))!=='068dc194c63ad686269f80f4b55bb177cb6e16eac67e284a4544cd92b8d604e1')throw Error('Unexpected garment candidate');
registerHooks({
 resolve(specifier,context,next){
  if(specifier.startsWith('@babylonjs/core/'))return{url:pathToFileURL(path.join(core,specifier.slice('@babylonjs/core/'.length)+(specifier.endsWith('.js')?'':'.js'))).href,shortCircuit:true};
  if(specifier.startsWith('.')&&context.parentURL?.startsWith('file:')){
   const stem=fileURLToPath(new URL(specifier,context.parentURL));
   if(!path.extname(stem))for(const ext of ['.ts','.tsx','.js'])if(fs.existsSync(stem+ext))return{url:pathToFileURL(stem+ext).href,shortCircuit:true};
  }
  return next(specifier,context);
 },
 load(url,context,next){
  if(!url.startsWith('file:'))return next(url,context);
  const filename=fileURLToPath(url);
  if(filename.endsWith('.ts')||filename.endsWith('.tsx')){
   const source=fs.readFileSync(filename===target&&process.env.GARMENT_VARIANT!=='A'?payload:filename,'utf8');
   return{format:'module',source:ts.transpileModule(source,{fileName:filename,compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022,jsx:ts.JsxEmit.ReactJSX,experimentalDecorators:true,useDefineForClassFields:false}}).outputText,shortCircuit:true};
  }
  if(filename.startsWith(clean)&&filename.endsWith('.json'))return{format:'module',source:'export default '+fs.readFileSync(filename,'utf8')+';',shortCircuit:true};
  return next(url,context);
 }
});
export const appAt=relative=>import(pathToFileURL(path.join(clean,relative)).href);
export const moduleAt=relative=>import(pathToFileURL(path.join(core,relative)).href);
