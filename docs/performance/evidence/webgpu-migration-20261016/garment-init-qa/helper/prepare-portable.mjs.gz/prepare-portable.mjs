import fs from'node:fs';import path from'node:path';import{fileURLToPath}from'node:url';import{createRequire}from'node:module';import{createHash}from'node:crypto';
const own=path.dirname(fileURLToPath(import.meta.url)),clean=path.resolve(own,'../webgpu-shadow-share-native-qa-20261019/clean'),candidate=path.join(own,'candidate'),require=createRequire(path.join(clean,'package.json')),ts=require('typescript'),seen=new Set(),borrowed={};
function copy(relative){
 relative=relative.replaceAll('\\','/');
 if(seen.has(relative))return;seen.add(relative);
 const source=path.join(clean,relative),dest=path.join(candidate,relative);
 if(relative==='client/avatar-garments.ts')return;
 const text=fs.readFileSync(source,'utf8');
 if(!fs.existsSync(dest)){fs.mkdirSync(path.dirname(dest),{recursive:true});fs.copyFileSync(source,dest);}
 borrowed[relative]=createHash('sha256').update(text).digest('hex');
 if(!relative.endsWith('.ts')&&!relative.endsWith('.tsx'))return;
 const emitted=ts.transpileModule(text,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022,jsx:ts.JsxEmit.ReactJSX}}).outputText;
 for(const m of emitted.matchAll(/(?:from\s*|import\s*)["'](\.[^"']+)["']/g)){
  const stem=path.resolve(path.dirname(source),m[1]);let file=stem;
  if(!path.extname(file))file=['.ts','.tsx','.json'].map(ext=>stem+ext).find(f=>fs.existsSync(f));
  if(!file||!file.startsWith(clean+path.sep))throw Error('unsupported dependency '+m[1]);
  copy(path.relative(clean,file));
 }
}
copy('client/avatar-renderer.ts');copy('client/avatar-presets.ts');
fs.writeFileSync(path.join(own,'portable-borrowed-sources.json'),JSON.stringify({source:clean,files:borrowed,links:['candidate/node_modules','candidate/shared','candidate/client/data'],note:'Read-only borrowed dependency/data junctions; source copies byte exact, only avatar-garments is changed.'},null,2));console.log(Object.keys(borrowed).length+' borrowed runtime source/data witnesses');
