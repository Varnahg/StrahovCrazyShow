import fs from'node:fs';import path from'node:path';import{fileURLToPath,pathToFileURL}from'node:url';import{createRequire}from'node:module';import{spawnSync}from'node:child_process';import assert from'node:assert/strict';
const own=path.dirname(fileURLToPath(import.meta.url)),clean=path.resolve(own,'../webgpu-shadow-share-native-qa-20261019/clean'),require=createRequire(path.join(clean,'package.json'));
const args=['--import',pathToFileURL(require.resolve('tsx/esm')).href,'--test','tests/student-garment-init.test.ts'],startedUTC=new Date().toISOString();
const r=spawnSync(process.execPath,args,{cwd:path.join(own,'candidate'),encoding:'utf8'});
fs.writeFileSync(path.join(own,'portable.log'),(r.stdout||'')+(r.stderr||''));
fs.writeFileSync(path.join(own,'portable-result.json'),JSON.stringify({args,startedUTC,endedUTC:new Date().toISOString(),exitCode:r.status,error:r.error?.message||null,scope:'Normal portable .test.ts using actual candidate and borrowed readonly core, no QAloader/env override'},null,2));
assert.equal(r.status,0);console.log(r.stdout);
