import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {appAt,moduleAt} from './loader.mjs';
const {NullEngine}=await moduleAt('Engines/nullEngine.js');
const {Scene}=await moduleAt('scene.js');
const {MeshBuilder}=await moduleAt('Meshes/meshBuilder.js');
const {PBRMaterial}=await moduleAt('Materials/PBR/pbrMaterial.js');
const {AvatarPrimitivePool,createAvatarRig}=await appAt('client/avatar-renderer.ts');
const {installStudentGarments}=await appAt('client/avatar-garments.ts');
const {applyAvatarPreset}=await appAt('client/avatar-presets.ts');
const {DEFAULT_AVATAR}=await appAt('shared/types.ts');
const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const engine=new NullEngine(),scene=new Scene(engine),pool=new AvatarPrimitivePool(scene);
const foreign=new PBRMaterial('foreign',scene),foreignMeshes=[];
let visits=0;
for(let i=0;i<16;i++){
 const mesh=MeshBuilder.CreateBox('foreign '+i,{},scene);mesh.material=foreign;
 const sm=mesh.subMeshes[0];sm._getDrawWrapper(0,true);
 const original=sm.getMaterial;
 sm.getMaterial=function(...args){visits++;return original.apply(this,args);};
 foreignMeshes.push(mesh);
}
const rows=[],rigs=[];
const garments=rig=>[...rig.skinnedBody.near,...rig.skinnedBody.medium].filter(m=>m.metadata?.studentGarment);
function snapshot(mesh){
 const m=mesh.material;
 assert.ok(m instanceof PBRMaterial,'app and fixture must use one physical Babylon class identity');
 return{metadata:mesh.metadata,enabled:mesh.isEnabled(),sideOrientation:mesh.sideOrientation,numBoneInfluencers:mesh.numBoneInfluencers,isPickable:mesh.isPickable,useVertexColors:mesh.useVertexColors,hasVertexAlpha:mesh.hasVertexAlpha,
 geometry:hash(Object.fromEntries(mesh.getVerticesDataKinds().map(k=>[k,Array.from(mesh.getVerticesData(k))]))),indices:hash(Array.from(mesh.getIndices())),
 bounds:{min:mesh.getBoundingInfo().boundingBox.minimum.asArray(),max:mesh.getBoundingInfo().boundingBox.maximum.asArray()},
 material:{name:m.name,metadata:m.metadata,albedo:m.albedoColor.asArray(),metallic:m.metallic,roughness:m.roughness,ambientTextureStrength:m.ambientTextureStrength,useAmbientInGrayScale:m.useAmbientInGrayScale,environmentIntensity:m.environmentIntensity,alpha:m.alpha,transparencyMode:m.transparencyMode,blockDirtyMechanism:m.blockDirtyMechanism,
 sheen:{isEnabled:m.sheen.isEnabled,intensity:m.sheen.intensity,roughness:m.sheen.roughness},textures:m.getActiveTextures().map(t=>({name:t.name,gammaSpace:t.gammaSpace,hasAlpha:t.hasAlpha,level:t.level,samplingMode:t.samplingMode,invertY:t.invertY,noMipmap:t.noMipmap,wrapU:t.wrapU,wrapV:t.wrapV}))}};
}
try{
 for(let i=0;i<6;i++){
  const config=applyAvatarPreset(i,DEFAULT_AVATAR),rig=createAvatarRig(scene,config,pool,'probe '+i,{studentGarments:false});rigs.push(rig);
  const skeleton=rig.skinnedBody.skeleton,heads=rig.head.getChildMeshes(),eye=rig.eyeHeight;
  visits=0;const result=installStudentGarments(scene,rig,config),count=visits;
  assert.equal(rig.skinnedBody.skeleton,skeleton);assert.deepEqual(rig.head.getChildMeshes(),heads);assert.equal(rig.eyeHeight,eye);
  const gs=garments(rig);assert.equal(gs.length,4);
  for(const part of ['upper','trousers']){const pair=gs.filter(m=>m.metadata.garmentPart===part);assert.equal(pair[0].material,pair[1].material);}
  rows.push({preset:i,result,visits:count,meshes:gs.map(snapshot)});
 }
 const config=applyAvatarPreset(0,DEFAULT_AVATAR),first=rigs[0],firstGarments=garments(first);
 const shared=createAvatarRig(scene,config,pool,'shared',{studentGarments:false});
 visits=0;installStudentGarments(scene,shared,config);const hitVisits=visits,sharedGarments=garments(shared);
 for(let i=0;i<4;i++){assert.equal(firstGarments[i].material,sharedGarments[i].material);assert.equal(firstGarments[i].geometry,sharedGarments[i].geometry);}
 const kept=sharedGarments.map(m=>m.material),maps=kept[0].getActiveTextures();
 const disposed=new Map();for(const m of new Set(kept)){disposed.set(m,0);m.onDisposeObservable.add(()=>disposed.set(m,disposed.get(m)+1));}
 first.root.dispose();assert.ok(kept.every(m=>scene.materials.includes(m)));assert.ok([...disposed.values()].every(n=>n===0));
 shared.root.dispose();assert.ok([...disposed.values()].every(n=>n===1));assert.ok(kept.every(m=>!scene.materials.includes(m)));assert.ok(maps.every(t=>scene.textures.includes(t)));
 const renewed=createAvatarRig(scene,config,pool,'renewed',{studentGarments:false});installStudentGarments(scene,renewed,config);
 const renewedGs=garments(renewed);assert.ok(renewedGs.every(m=>!kept.includes(m.material)));assert.equal(renewedGs[0].material.bumpTexture,maps.find(t=>t.name.endsWith('normal.png')));renewed.root.dispose();
 for(const rig of rigs.slice(1))rig.root.dispose();
 assert.equal(scene.materials.filter(m=>m.name.startsWith('CC0 student garment')).length,0);
 assert.ok(foreignMeshes.every(m=>m.material===foreign&&!m.isDisposed()));
 const report={variant:process.env.GARMENT_VARIANT||'P',rows,cacheHitVisits:hitVisits,lifecycle:{sharedMaterial:true,sharedGeometry:true,lastReleaseExactlyOnce:true,familyMapsRetained:true,renewedMaterial:true,foreignUntouched:true}};
 fs.writeFileSync(process.env.GARMENT_REPORT,JSON.stringify(report,null,2));
 if(process.env.GARMENT_REQUIRE_BATCH==='1')assert.ok(rows.every(r=>r.visits<=16*4),'initial garment configuration must avoid repeated foreign traversal');
}finally{for(const rig of rigs)if(!rig.root.isDisposed())rig.root.dispose();pool.dispose();scene.dispose();engine.dispose();}
