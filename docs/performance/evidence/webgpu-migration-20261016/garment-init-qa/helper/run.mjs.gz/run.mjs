import fs from 'node:fs';import path from 'node:path';import{spawnSync}from'node:child_process';import{fileURLToPath,pathToFileURL}from'node:url';import assert from'node:assert/strict';
const own=path.dirname(fileURLToPath(import.meta.url)),clean=path.resolve(own,'../webgpu-shadow-share-native-qa-20261019/clean'),loader=path.join(own,'loader.mjs'),jobs=[];
function run(label,variant,args,extra={}){
 const env={...process.env,GARMENT_VARIANT:variant,GARMENT_REPORT:path.join(own,label+'.json'),...extra},startedUTC=new Date().toISOString();
 const r=spawnSync(process.execPath,['--import',pathToFileURL(loader).href,...args],{cwd:clean,env,encoding:'utf8'});
 fs.writeFileSync(path.join(own,label+'.log'),(r.stdout||'')+(r.stderr||''));
 jobs.push({label,variant,args,startedUTC,endedUTC:new Date().toISOString(),exitCode:r.status,error:r.error?.message||null});
 fs.writeFileSync(path.join(own,'jobs.json'),JSON.stringify(jobs,null,2));return r;
}
const script=path.join(own,'proof.mjs');
assert.equal(run('red','A',[script],{GARMENT_REQUIRE_BATCH:'1'}).status,1,'old source must fail traversal bound');
assert.match(fs.readFileSync(path.join(own,'red.log'),'utf8'),/initial garment configuration must avoid repeated foreign traversal/,'RED must be intended assertion, not loader failure');
assert.equal(run('green','P',[script],{GARMENT_REQUIRE_BATCH:'1'}).status,0,'candidate must pass');
const a=JSON.parse(fs.readFileSync(path.join(own,'red.json'))),p=JSON.parse(fs.readFileSync(path.join(own,'green.json')));
assert.deepEqual(a.rows.map(({visits,...rest})=>rest),p.rows.map(({visits,...rest})=>rest),'final materials/geometry must match');assert.deepEqual(a.lifecycle,p.lifecycle);assert.equal(a.cacheHitVisits,p.cacheHitVisits);
assert.ok(p.rows.every((r,i)=>r.visits<a.rows[i].visits));
for(const variant of ['A','P'])assert.equal(run('existing-'+variant,variant,['--test','--test-name-pattern','opt-in clothing|production creates',path.join(own,'existing.test.mjs')]).status,0);
const result={jobs,parity:'exact final values, textures, metadata and geometry across six presets; shared/repeated/lastrelease assertions pass',counts:a.rows.map((r,i)=>({preset:r.preset,before:r.visits,after:p.rows[i].visits})),cacheHitVisits:p.cacheHitVisits,scope:'Actual Babylon CPU traversal and lifecycle only; no GPU/visual/FPS proof'};
fs.writeFileSync(path.join(own,'results.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
