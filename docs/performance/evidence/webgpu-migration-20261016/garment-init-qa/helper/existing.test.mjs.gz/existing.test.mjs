import {moduleAt,appAt} from './loader.mjs';
// Import builder registrations before the renderer's cyclic geometry/material graph.
// Fixture setup only; the borrowed runtime and existing tests remain byte-exact.
await moduleAt('Meshes/meshBuilder.js');
await appAt('tests/student-garments.test.ts');
