import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
const root=import.meta.dirname,run=join(root,'runs/c1'),cpu=JSON.parse(readFileSync(join(run,'cpu-profile.json'))),summary=JSON.parse(readFileSync(join(run,'cpu-summary.json'))),hitches=JSON.parse(readFileSync(join(run,'hitch-analysis.json')));
assert.equal(cpu.textureUVTrace.status,'captured');assert.equal(cpu.textureUVProbeErrors,0);assert.equal(cpu.textureUVTrace.errors,0);assert.equal(cpu.textureUVTrace.overflow,0);assert.equal(cpu.textureUVTrace.events.length,0);
const chain=s=>{const out=[];let id=s.stackId;while(id!==undefined){const stack=cpu.trace.stacks[id];out.push(summary.frames[stack.frameId]);id=stack.parentId;}return out;};
const interesting=new Set(['_markAllSubMeshesAsDirty','_markMeshesAsLightDirty','_resyncMeshes','_createTargetRenderTexture','_releaseRenderPassId','_initializeShadowMap','_createRenderPassId']);
const observations=cpu.trace.samples.map(s=>({atMs:s.timestamp,frames:chain(s)})).filter(s=>s.frames.some(f=>interesting.has(f.name)));
const result={source:summary.source,session:JSON.parse(readFileSync(join(run,'summary.json'))).session,capture:summary.capture,textureUVTrace:cpu.textureUVTrace,textureUVProbeErrors:cpu.textureUVProbeErrors,hitches:hitches.hitches.map(h=>({seq:h.seq,frameMs:h.frameMs,previousSynchronousFrame:h.previousSynchronousFrame})),observations,
  decision:'No UV identity notification occurred in this captured first drive, despite6>=100ms intervals. The UV-first/later question is not exercised, not answered universally. Do not pursue UV guard or infer sparse-wrapper statistics from unavailable inventory.',
  next:'Revisit previously deferred Medium/High vehicle preparation after accepted exact shadow sharing: actual trace observes light resync/shadow target/pass recreation on entry, and Game current vehicle stages are Low-only. Compare broader existing-stage preparation against lifecycle/feature parity before implementation.',
  limits:'Stack presence establishes paths, not durations/counts from irregular samples. Different passengers/thermal/start state and profiler overhead; no FPS A/B. Inventory unavailable because no UV event supplied a scene, not zero scene wrappers.'};
writeFileSync(join(run,'cause-analysis.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({uvEvents:0,uvErrors:0,samples:cpu.trace.samples.length,interestingObservations:observations.length,exampleChains:observations.slice(0,5).map(s=>({atMs:s.atMs,frames:s.frames.map(f=>({name:f.name,source:f.source,line:f.lineOriginal}))}))},null,2));
