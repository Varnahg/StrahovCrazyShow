import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync,readdirSync} from 'node:fs';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=import.meta.dirname,cwd=join(root,'snapshot'),hash=b=>createHash('sha256').update(b).digest('hex');
const manifest=JSON.parse(readFileSync(join(cwd,'source-manifest.json')));assert.equal(hash(JSON.stringify(manifest.files)),manifest.snapshotId);
function verify(){for(const[p,sha]of Object.entries(manifest.files))assert.equal(hash(readFileSync(join(cwd,p))),sha,p);}
const phases=[['targeted',['--import','tsx','--import','./qa-uv-dirty/register.mjs','--test','tests/qa-uv-integration.test.ts','tests/qa-cpu-profile.test.ts','tests/game-light-switch-profile.test.ts','tests/mesh-draw-profile.test.ts']],['types',['node_modules/typescript/bin/tsc','--noEmit']],['build',['node_modules/vite/bin/vite.js','build','--configLoader','native','--sourcemap','hidden']]];
const results=[];verify();
for(const[phase,args]of phases){
 const log=join(root,'v2-'+phase+'.log');assert.ok(!existsSync(log),'preserve '+log);const start=new Date().toISOString();
 const r=spawnSync(process.execPath,args,{cwd,env:{...process.env,VITE_SOURCE_SNAPSHOT_ID:manifest.snapshotId,TSX_DISABLE_CACHE:'1',UV_DIRTY_CORE:join(cwd,'node_modules/@babylonjs/core'),UV_DIRTY_MODULE:join(cwd,'qa-uv-dirty/texture.pure.js.txt'),UV_DIRTY_SHA:'edaa133c49ee6886424b2530f51360ca1810b64912349a524d213e3e126fbe7c'},encoding:'utf8',maxBuffer:64*1024*1024});writeFileSync(log,(r.stdout??'')+(r.stderr??''));
 const result={phase,exitCode:r.status,startedAt:start,endedAt:new Date().toISOString(),log,sha256:hash(readFileSync(log))};results.push(result);verify();writeFileSync(join(root,'v2-validation.json'),JSON.stringify({source:manifest.snapshotId,results},null,2)+'\n');console.log(JSON.stringify(result));if(r.status!==0){console.log((r.stdout??'').slice(-3000)+(r.stderr??'').slice(-1500));process.exit(r.status||1);}
}
function entries(dir,prefix=''){return readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?entries(join(dir,e.name),prefix+e.name+'/'):/\.(js|map|html|css|wasm)$/.test(e.name)?[[prefix+e.name,hash(readFileSync(join(dir,e.name)))]]:[]);}
writeFileSync(join(root,'v2-dist-manifest.json'),JSON.stringify(Object.fromEntries(entries(join(cwd,'dist'))),null,2)+'\n');
