import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,existsSync,symlinkSync,realpathSync} from 'node:fs';
import {join,dirname,resolve} from 'node:path';
import {createHash} from 'node:crypto';
const root=import.meta.dirname,base=resolve(root,'../webgpu-medium-cpu-profile-20261019/snapshot'),out=join(root,'snapshot');
const hash=b=>createHash('sha256').update(b).digest('hex'),m=JSON.parse(readFileSync(join(base,'source-manifest.json')));
assert.equal(m.snapshotId,'f80f93c8a3d2cd0c44d48e73639e314bee16d4bdb5d5ece7f7095aa6d73173b6');assert.equal(hash(JSON.stringify(m.files)),m.snapshotId);assert.ok(!existsSync(out));
const payload=readFileSync(resolve(process.argv[2])),after=hash(payload),before='f27fd4a566579ea2cc99c43ae056e48546b3d433aded037ab97c997c6299a976';
assert.match(payload.toString(),/export function qaBeginTextureUVTrace/);assert.match(payload.toString(),/export function qaReadTextureUVTrace/);
mkdirSync(out,{recursive:true});const files={...m.files};
function put(p,b){mkdirSync(dirname(join(out,p)),{recursive:true});writeFileSync(join(out,p),b);files[p]=hash(b);}
for(const[p,sha]of Object.entries(m.files)){const b=readFileSync(join(base,p));assert.equal(hash(b),sha,p);put(p,b);}
for(const p of ['assets','public','docs','node_modules'])symlinkSync(realpathSync(join(base,p)),join(out,p),'junction');
assert.equal(hash(readFileSync(join(out,'node_modules/@babylonjs/core/Materials/Textures/texture.pure.js'))),before);
assert.equal(hash(readFileSync(join(out,'node_modules/@babylonjs/core/Materials/shadowDepthWrapper.js'))),'f8a8c6091af9caa96ba897f28d7d490f3607d7856dee86b3a05321e1477aba29');
put('qa-uv-dirty/texture.pure.js.txt',payload);for(const name of ['loader.mjs','register.mjs'])put('qa-uv-dirty/'+name,readFileSync(join(root,name)));
put('tests/qa-uv-integration.test.ts',readFileSync(join(root,'qa-uv-integration.test.ts')));
const p='client/qa-cpu-profile.ts',original=readFileSync(join(base,p)),crlf=original.includes(Buffer.from('\r\n'));let text=original.toString().replaceAll('\r\n','\n');
const edits=[
['// Temporary copied QA code. No session recorder, transport, or production hook.',`// Temporary copied QA code. No session recorder, transport, or production hook.
import * as textureModule from '@babylonjs/core/Materials/Textures/texture.pure';
const qaTextureProbe = textureModule as unknown as {
  qaBeginTextureUVTrace?: () => unknown;
  qaEndTextureUVTrace?: () => unknown;
  qaReadTextureUVTrace?: () => unknown;
};
let qaTextureProbeErrors = 0;
function callTextureProbe(name: keyof typeof qaTextureProbe) {
  try { return qaTextureProbe[name]?.() ?? { status: 'unavailable' }; }
  catch { qaTextureProbeErrors++; return { status: 'error' }; }
}`],
['  publish(entry: CpuProfileEntry): void;','  publish(entry: CpuProfileEntry): void;\n  captureStarted?(): void;\n  captureStopped?(): void;'],
['        metadata.stoppedAtMs = clock(() => runtime.now());\n        try { profiler.removeEventListener','        metadata.stoppedAtMs = clock(() => runtime.now());\n        try { runtime.captureStopped?.(); } catch { /* QA must not alter profiler outcome. */ }\n        try { profiler.removeEventListener'],
['        metadata.sampleInterval = profiler.sampleInterval;\n        profiler.addEventListener','        metadata.sampleInterval = profiler.sampleInterval;\n        try { runtime.captureStarted?.(); } catch { /* QA must not alter profiler outcome. */ }\n        profiler.addEventListener'],
['function publishToDom(entry: CpuProfileEntry) {\n  if (typeof document',"function publishToDom(entry: CpuProfileEntry) {\n  const textureUVTrace = callTextureProbe('qaReadTextureUVTrace');\n  if (typeof document"],
['  output.pre.textContent = JSON.stringify(entry);','  output.pre.textContent = JSON.stringify({ ...entry, textureUVTrace, textureUVProbeErrors: qaTextureProbeErrors });'],
['  publish: publishToDom,',"  publish: publishToDom,\n  captureStarted: () => { qaTextureProbeErrors = 0; callTextureProbe('qaBeginTextureUVTrace'); },\n  captureStopped: () => { callTextureProbe('qaEndTextureUVTrace'); },"]
];
for(const[a,b]of edits){assert.equal(text.split(a).length,2,'Unique CPU adapter edit');text=text.replace(a,b);}const adapter=Buffer.from(crlf?text.replaceAll('\n','\r\n'):text);put(p,adapter);
for(const[a,b]of [...edits].reverse()){assert.equal(text.split(b).length,2);text=text.replace(b,a);}assert.equal(hash(Buffer.from(crlf?text.replaceAll('\n','\r\n'):text)),hash(original));
put('qa-uv-dirty/cpu-adapter-edits.json',Buffer.from(JSON.stringify(edits,null,2)+'\n'));
const config=readFileSync(join(base,'vite.config.ts'),'utf8');
const preamble=`import { readFileSync, writeFileSync, realpathSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
let uvDirtyHits = 0;
const uvDirtyTarget = realpathSync(createRequire(import.meta.url).resolve('@babylonjs/core/Materials/Textures/texture.pure.js')).replaceAll('\\\\', '/');
const uvDirtyPayload = readFileSync(new URL('./qa-uv-dirty/texture.pure.js.txt', import.meta.url), 'utf8');
const uvDirtyHash = (text: string) => createHash('sha256').update(text).digest('hex');
const uvDirtyPlugin: import('vite').Plugin = {name:'qa-exact-uv-dirty-probe',enforce:'pre',transform(code,id){if(id.split('?')[0].replaceAll('\\\\','/')!==uvDirtyTarget)return; if(uvDirtyHash(code)!=='${before}'||uvDirtyHash(uvDirtyPayload)!=='${after}')throw new Error('UV probe SHA mismatch');uvDirtyHits++;return {code:uvDirtyPayload,map:null};},generateBundle(){if(uvDirtyHits!==1)throw new Error('UV probe overlay must match exactly once: '+uvDirtyHits);writeFileSync(new URL('../build-transform.json',import.meta.url),JSON.stringify({hits:uvDirtyHits,before:'${before}',after:'${after}',target:uvDirtyTarget,scope:'QA probe only; no original notification skipped; borrowed dependencies unchanged.'},null,2)+'\\n');}};
`;
assert.equal(config.split('plugins: [react()]').length,2);put('vite.config.ts',Buffer.from(preamble+config.replace('plugins: [react()]','plugins: [react(), uvDirtyPlugin]')));
assert.equal(files['client/game.ts'],m.files['client/game.ts']);assert.equal(files['client/render-cost.ts'],m.files['client/render-cost.ts']);
const snapshotId=hash(JSON.stringify(files));writeFileSync(join(out,'source-manifest.json'),JSON.stringify({snapshotId,base:m.snapshotId,files},null,2)+'\n');
writeFileSync(join(root,'assembly.json'),JSON.stringify({snapshotId,files:Object.keys(files).length,base:m.snapshotId,before,after,configBefore:hash(config),cpuAdapterBefore:hash(original),cpuAdapterAfter:hash(adapter),cpuAdapterInverse:true,changes:['client/qa-cpu-profile.ts','vite.config.ts','qa-uv-dirty/','tests/qa-uv-integration.test.ts'],scope:'Exact current-native CPUprofile + bounded UV notification probe; no candidate optimization.'},null,2)+'\n');
for(const name of ['start.ps1','stop.ps1','preview.mjs','weather.json','collect.mjs','gpu-state.mjs','validate.mjs']){
  let t=readFileSync(resolve(root,'../webgpu-medium-cpu-profile-20261019',name),'utf8').replaceAll('webgpu-medium-cpu-profile-20261019','webgpu-uv-dirty-profile-20261019').replaceAll('webgpu-01a15102-medium-cpu','webgpu-01a15102-uv-dirty');
  if(name==='validate.mjs')t=t.replace("['targeted',['--import','tsx','--test',", "['targeted',['--import','tsx','--import','./qa-uv-dirty/register.mjs','--test','tests/qa-uv-integration.test.ts',").replace("TSX_DISABLE_CACHE:'1'",`TSX_DISABLE_CACHE:'1',UV_DIRTY_CORE:join(cwd,'node_modules/@babylonjs/core'),UV_DIRTY_MODULE:join(cwd,'qa-uv-dirty/texture.pure.js.txt'),UV_DIRTY_SHA:'${after}'`);
  writeFileSync(join(root,name),t);
}
const protocol=JSON.parse(readFileSync(resolve(root,'../webgpu-medium-cpu-profile-20261019/protocol.json')));protocol.source=snapshotId;protocol.scope='Bounded actual UV dirty trace + existing16ms selfprofile; not FPS A/B acceptance.';writeFileSync(join(root,'protocol.json'),JSON.stringify(protocol,null,2)+'\n');
console.log(JSON.stringify({snapshotId,files:Object.keys(files).length,before,after,cpuAdapterInverse:true}));
