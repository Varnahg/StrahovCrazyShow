import {readFileSync,writeFileSync} from 'node:fs';
import {join,resolve} from 'node:path';
const root=import.meta.dirname,donor=resolve(root,'../webgpu-medium-cpu-profile-20261019');
for(const name of ['analyze.mjs','analyze-hitches.mjs']){
 let code=readFileSync(join(donor,name),'utf8').replaceAll('v2-dist-manifest.json','v3-dist-manifest.json');
 const i=code.lastIndexOf('console.log(');if(i<0)throw new Error('Missing expected final diagnostic output');
 code=code.slice(0,i)+(name==='analyze.mjs'?"console.log(JSON.stringify({capture:result.capture,bundlePairs:Object.keys(result.bundleChecks).length}));\n":"console.log(JSON.stringify({hitches:hitches.map(h=>({seq:h.seq,frameMs:h.frameMs,previousCpu:h.previousSynchronousFrame.cpuMs,leaf:h.leaf.slice(0,4).map(f=>({name:f.name,source:f.source,line:f.functionDefinitionLine,samples:f.samples}))})),textureDirtySamples:textureDirty.length},null,2));\n");
 writeFileSync(join(root,name),code);
}
