import {moduleAt} from './loader.mjs';
export const {NullEngine}=await moduleAt('Engines/nullEngine.js');
export const {Scene}=await moduleAt('scene.js');
export const {Texture}=await moduleAt('Materials/Textures/texture.js');
export const {MeshBuilder}=await moduleAt('Meshes/meshBuilder.js');
export const api=await moduleAt('Materials/Textures/texture.pure.js');
export function fixture(){
 const engine=new NullEngine(),scene=new Scene(engine),original=scene.markAllMaterialsAsDirty.bind(scene),dirty=[];
 scene.markAllMaterialsAsDirty=function(flag,predicate){dirty.push(flag);return original(flag,predicate);};
 const textures=[];return{engine,scene,dirty,texture(){const t=new Texture(null,scene);textures.push(t);return t;},
 dispose(){api.qaAbortTextureUVTrace?.();for(const t of textures)t.dispose();scene.dispose();engine.dispose();}};
}
