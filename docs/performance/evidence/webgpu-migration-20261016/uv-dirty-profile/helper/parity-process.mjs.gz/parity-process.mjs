import assert from 'node:assert/strict';import{writeFileSync}from'node:fs';import{fixture,api,Texture}from'./fixture.mjs';
const f=fixture(),states=[];try{
 api.qaBeginTextureUVTrace?.();const x=f.texture();let prior;
 function step(label,texture=x,uBase=1){const m=texture.getTextureMatrix(uBase);states.push({label,matrix:Array.from(m.asArray()),identity:m.isIdentityAs3x2(),cachedIdentity:texture._cachedIdentity3x2,dirty:f.dirty.length,same:prior===m});prior=m;}
 step('identity');x.uScale=2;step('nonidentity');step('unchanged');x.vScale=3;x.uOffset=.2;step('nonidentity-to-nonidentity');x.uScale=x.vScale=1;x.uOffset=0;step('return identity');step('uBase2',x,2);step('uBase1',x,1);
 x.uAng=.12;x.vAng=-.3;x.wAng=.75;step('rotation');x.homogeneousRotationInUVTransform=true;step('homogeneous');const clone=x.clone();try{step('clone',clone);clone.uScale=4;step('clone later',clone);}finally{clone.dispose();}
 x.optimizeUVAllocation=false;x.uAng=x.vAng=x.wAng=0;x.homogeneousRotationInUVTransform=false;step('disabled optimization');x.optimizeUVAllocation=true;step('toggle cached');x.uOffset=.1;step('later transition');
 const detached=new Texture(null,f.engine);try{detached.uScale=2;step('no scene',detached);}finally{detached.dispose();}
 api.qaEndTextureUVTrace?.();const trace=api.qaReadTextureUVTrace?.();if(trace){assert.equal(trace.errors,0);assert.ok(trace.events.length>0);assert.equal(trace.overflow,0);}
 writeFileSync(process.env.UV_DIRTY_PARITY_REPORT,JSON.stringify({states,dirty:f.dirty,scope:'Actual stock Texture/Scene math, identity and notifications; no shader/material/GPU benchmark.'},null,2)+'\n');
}finally{f.dispose();}
