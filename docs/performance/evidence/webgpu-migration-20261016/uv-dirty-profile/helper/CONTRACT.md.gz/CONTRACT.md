# Copied stock Texture UV notification trace

Pinned preimage `f27fd4a566579ea2cc99c43ae056e48546b3d433aded037ab97c997c6299a976` from current native clean8fb, SDWf8 and MD3cc. Candidate payload `edaa133c49ee6886424b2530f51360ca1810b64912349a524d213e3e126fbe7c`. This is instrumentation of stock behavior, **not** the rejected first-UV notification suppression. No dirty call, texture math, matrix return/cache, predicate or original exception is removed.

## Named exports and caller sequence

- `qaBeginTextureUVTrace()` clears old data/references, starts a new monotonic generation and returns its numeric ID.
- `qaEndTextureUVTrace()` only sets the current capture's active flag false. It performs no serialization, inventory or callback replacement.
- `qaReadTextureUVTrace()` stops/detaches the old capture, computes inventory only now, returns JSON-safe data, and clears old scene/events references in `finally`. Read is intended **after** the benchmark, normally in the existing profiler's Promise publication. A defensive read without end also stops that capture. Subsequent read returns `status:"empty"` and no inventory. It does not erase a new generation created reentrantly during inventory.
- `qaAbortTextureUVTrace()` clears the current active/data/scene references and advances generation. It produces no inventory or export.

Root should begin only after successfully acquiring its existing CPU profiler; stop the UV trace from that profiler's central stop path (including buffer-full, disposal and errors), and read only after its stop Promise settles. No additional recorder/session transport is implemented here.

`loader.mjs` accepts absolute `UV_DIRTY_CORE` and `UV_DIRTY_MODULE`; reroutes only the real physical `Materials/Textures/texture.pure.js` URL. Both preimage and selected payload SHA are verified. Default core is borrowed native clean8fb. `UV_DIRTY_VARIANT=A` bypasses the hook for a private reference child. No installed dependency file changes.

## Records and bounds

At most64 notification reservations per generation, with explicit `overflow` and `errors`. Reaching the bound reads no more clocks. Existing fast cached-matrix returns contain no new probe code or clock reads; first/later calculations add a had-matrix observation before allocation. This observation uses the own data descriptor; unsupported accessors produce `hadCachedMatrix:null` instead of another user getter invocation.

Each emitted record has `textureId`, `textureName` (at most200characters), truncation flag, `uBase`/type, primitive own UV fields, `hadCachedMatrix`, `previousIdentity`, `identity`, `startedAtMs`, `endedAtMs`, `durationMs`, `complete` and `threw`. No Texture, matrix, callback or material reference appears in records/export. UV accessors/unsupported values are not invoked/coerced by metadata capture and are represented as null with missing-field count. Actual original Texture reads still execute normally.

Only the actual `scene.markAllMaterialsAsDirty(1,predicate)` call is bracketed. Probe clocks/metadata/finally are best-effort; the original dirty call's return/throw remains original. Times are synchronous CPU wall intervals with diagnostic overhead; nested notifications overlap and must not be added as independent CPU time. Failed clock reads give null timings and errors, not invented zero duration. A read during an in-flight notification can export an explicitly incomplete row. A generation change makes a stale finally inert.

At most one persistent Scene reference is retained for postcapture inventory. Other-scene notifications have `inventoryScene:false` and `otherSceneNotifications`; inventory does not claim to cover them. End retains that one scene until read/abort/new begin; callers must consume/abort the capture. In-flight calls can temporarily retain their old local state while returning, but begin/read/abort clear its scene field. There is no GPU resource cache.

## Inventory scope

Inventory reads `scene.meshes`, each mesh's `subMeshes` and each submesh's **own** `_drawWrappers` array. It reports mesh/submesh/array counts, summed declared array lengths, own present index slots, non-null object wrappers in enumerable own index slots, maximum declared length, holes (`length - own index slots`), maximum holes, accessor slots and non-object slots. It enumerates present own names rather than looping through all declared holes. These are structural pass-slot counts, **not** draws, active meshes, Effects, GPU memory or live-resource byte counts. Main-wrapper overrides outside that array are not included. The inventory is postcapture state, not a history of every benchmark frame.

An unknown/throwing inventory gives `inventory:null`, `inventoryError:true` and increments errors while releasing the old scene. No material/shader fixture, full suite, compiler/GPU image or frame-rate claim follows from this helper.

## Proof

Actual pinned Texture/Scene on NullEngine:12 targeted tests plus original/probe15-state matrix/cache/dirty parity (7actual notifications). Cases cover disabled/fastpath clocks, first/later identity, uBase, clone, homogeneous rotation, optimize toggle, detached no-scene behavior, original throw, QA clock failure,64limit, sparse array inventory, repeated lifecycle, reentrant begin/inventory and cleanup failure. They do not identify which notification or CPU fraction occurs in the production game; root owns that capture.
