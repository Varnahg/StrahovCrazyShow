import assert from 'node:assert/strict';import{readFileSync,realpathSync}from'node:fs';import{resolve,join}from'node:path';import{registerHooks}from'node:module';import{pathToFileURL,fileURLToPath}from'node:url';import{createHash}from'node:crypto';
export const core=realpathSync(resolve(process.env.UV_DIRTY_CORE||fileURLToPath(new URL('../webgpu-shadow-share-native-qa-20261019/clean/node_modules/@babylonjs/core',import.meta.url))));
const target=pathToFileURL(realpathSync(join(core,'Materials/Textures/texture.pure.js'))).href;
const selected=resolve(process.env.UV_DIRTY_MODULE||fileURLToPath(new URL('./candidate/Textures/texture.pure.js',import.meta.url)));
const hash=b=>createHash('sha256').update(b).digest('hex');
assert.equal(hash(readFileSync(fileURLToPath(target))),'f27fd4a566579ea2cc99c43ae056e48546b3d433aded037ab97c997c6299a976');
assert.equal(hash(readFileSync(selected)),'edaa133c49ee6886424b2530f51360ca1810b64912349a524d213e3e126fbe7c');
if(process.env.UV_DIRTY_VARIANT!=='A')registerHooks({load(url,context,next){if(url!==target)return next(url,context);return{format:'module',source:readFileSync(selected,'utf8'),shortCircuit:true};}});
export const moduleAt=path=>import(pathToFileURL(join(core,path)).href);
