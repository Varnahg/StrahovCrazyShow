import test from 'node:test';import assert from 'node:assert/strict';import {fixture,api,Texture,MeshBuilder} from './fixture.mjs';
function clock(run,now){const prior=Object.getOwnPropertyDescriptor(globalThis,'performance');Object.defineProperty(globalThis,'performance',{configurable:true,value:{now}});try{return run();}finally{if(prior)Object.defineProperty(globalThis,'performance',prior);else delete globalThis.performance;}}

test('disabled default preserves actual first notification and never reads clock; matrix cache fastpath remains uninstrumented',t=>{
 const f=fixture();t.after(f.dispose);const x=f.texture();x.uScale=2;let clocks=0;
 clock(()=>{const matrix=x.getTextureMatrix();assert.equal(matrix.isIdentityAs3x2(),false);assert.equal(x.getTextureMatrix(),matrix);},()=>{clocks++;throw Error('clock must remain unused');});
 assert.equal(clocks,0);assert.deepEqual(f.dirty,[1]);assert.equal(api.qaReadTextureUVTrace().status,'empty');
});
test('actual first/later dirty notifications preserve matrix/return and record bounded primitive metadata with exactly two clocks',t=>{
 const f=fixture();t.after(f.dispose);const x=f.texture();x.name='x'.repeat(210);x.uScale=2;let time=10,clocks=0;api.qaBeginTextureUVTrace();
 clock(()=>{const m=x.getTextureMatrix();assert.equal(x.getTextureMatrix(),m);assert.equal(clocks,2);x.uScale=1;assert.equal(x.getTextureMatrix().isIdentityAs3x2(),true);assert.equal(clocks,4);},()=>{clocks++;return time+=2;});
 api.qaEndTextureUVTrace();const out=api.qaReadTextureUVTrace();assert.equal(out.events.length,2);assert.equal(out.events[0].hadCachedMatrix,false);assert.equal(out.events[1].hadCachedMatrix,true);
 assert.deepEqual(out.events.map(e=>[e.previousIdentity,e.identity]),[[true,false],[false,true]]);assert.equal(out.events[0].textureId,x.uniqueId);assert.equal(out.events[0].textureName.length,200);assert.equal(out.events[0].textureNameTruncated,true);assert.equal(out.events[0].uv.uScale,2);assert.equal(out.events[0].durationMs,2);
 assert.ok(out.events.every(e=>e.complete&&e.threw===false));assert.equal(out.errors,0);assert.equal(out.inventory.available,true);assert.equal(api.qaReadTextureUVTrace().status,'empty');assert.doesNotThrow(()=>JSON.stringify(out));assert.deepEqual(f.dirty,[1,1]);
});
test('end only disables sampling; read computes sparse pass array inventory after end and releases capture',t=>{
 const f=fixture();t.after(f.dispose);const x=f.texture();const mesh=MeshBuilder.CreateBox('inventory',{},f.scene),sub=mesh.subMeshes[0];sub._getDrawWrapper(0,true);sub._getDrawWrapper(16,true);sub._drawWrappers[5]=undefined;
 api.qaBeginTextureUVTrace();x.uScale=2;x.getTextureMatrix();api.qaEndTextureUVTrace();x.uScale=1;x.getTextureMatrix();const out=api.qaReadTextureUVTrace();
 assert.equal(out.events.length,1);assert.deepEqual(out.inventory,{available:true,meshes:1,submeshes:1,drawWrapperArrays:1,declaredPassSlotLength:17,ownIndexSlots:3,liveEnumerableWrappers:2,maximumArrayLength:17,holes:14,maximumArrayHoles:14,accessorSlots:0,nonObjectSlots:1});assert.equal(api.qaReadTextureUVTrace().inventory,null);
});
test('original dirty-scan throw identity survives finally and trace records the throwing notification',t=>{
 const f=fixture();t.after(f.dispose);const x=f.texture(),failure={original:true};f.scene.markAllMaterialsAsDirty=()=>{throw failure;};api.qaBeginTextureUVTrace();x.uScale=2;
 assert.throws(()=>x.getTextureMatrix(),e=>e===failure);api.qaEndTextureUVTrace();const out=api.qaReadTextureUVTrace();assert.equal(out.events.length,1);assert.equal(out.events[0].threw,true);assert.equal(out.events[0].complete,true);assert.equal(out.events[0].hadCachedMatrix,false);assert.equal(x._cachedIdentity3x2,false);
});
test('diagnostic clock failures do not suppress stock notification or produce a new throw',t=>{
 const f=fixture();t.after(f.dispose);const x=f.texture();api.qaBeginTextureUVTrace();x.uScale=2;clock(()=>assert.equal(x.getTextureMatrix().isIdentityAs3x2(),false),()=>{throw Error('diagnostic clock');});
 const out=api.qaReadTextureUVTrace();assert.deepEqual(f.dirty,[1]);assert.equal(out.events.length,1);assert.equal(out.events[0].durationMs,null);assert.equal(out.errors,2);
});
test('limit64 plus overflow retains original notifications and has no overflow clock reads',t=>{
 const f=fixture();t.after(f.dispose);const x=f.texture();api.qaBeginTextureUVTrace();let clocks=0;clock(()=>{for(let i=0;i<70;i++){x.uScale=i%2?1:2;x.getTextureMatrix();}},()=>++clocks);
 const out=api.qaReadTextureUVTrace();assert.equal(f.dirty.length,70);assert.equal(out.events.length,64);assert.equal(out.overflow,6);assert.equal(clocks,128);assert.equal(out.events.at(-1).index,64);
});
test('begin reset, abort and repeat generations clear prior data without affecting matrices/dirty calls',t=>{
 const f=fixture();t.after(f.dispose);const x=f.texture();const one=api.qaBeginTextureUVTrace();x.uScale=2;x.getTextureMatrix();const two=api.qaBeginTextureUVTrace();assert.ok(two>one);x.uScale=1;x.getTextureMatrix();const out=api.qaReadTextureUVTrace();assert.equal(out.events.length,1);assert.equal(out.events[0].hadCachedMatrix,true);assert.equal(out.generation,two);
 api.qaBeginTextureUVTrace();x.uScale=2;x.getTextureMatrix();api.qaAbortTextureUVTrace();assert.equal(api.qaReadTextureUVTrace().status,'empty');api.qaBeginTextureUVTrace();x.uScale=1;x.getTextureMatrix();assert.equal(api.qaReadTextureUVTrace().events.length,1);
});
test('reentrant begin during the original scan cannot let the stale outer finally mutate the new generation',t=>{
 const f=fixture();t.after(f.dispose);const outer=f.texture(),inner=f.texture();outer.name='outer';inner.name='inner';let entered=false;const original=f.scene.markAllMaterialsAsDirty;
 f.scene.markAllMaterialsAsDirty=function(...args){if(!entered){entered=true;api.qaBeginTextureUVTrace();inner.uScale=2;inner.getTextureMatrix();}return Reflect.apply(original,this,args);};
 api.qaBeginTextureUVTrace();outer.uScale=2;outer.getTextureMatrix();const out=api.qaReadTextureUVTrace();assert.equal(out.events.length,1);assert.equal(out.events[0].textureName,'inner');assert.equal(out.events[0].complete,true);assert.equal(f.dirty.length,2);
});
test('read releases its old scene even on inventory failure and does not retain returned live objects',t=>{
 const f=fixture();t.after(f.dispose);const x=f.texture();api.qaBeginTextureUVTrace();x.uScale=2;x.getTextureMatrix();api.qaEndTextureUVTrace();const descriptor=Object.getOwnPropertyDescriptor(f.scene,'meshes');Object.defineProperty(f.scene,'meshes',{configurable:true,get(){throw Error('inventory failure');}});
 let out;try{assert.doesNotThrow(()=>{out=api.qaReadTextureUVTrace();});}finally{Object.defineProperty(f.scene,'meshes',descriptor);}assert.equal(out.inventoryError,true);assert.equal(out.inventory,null);assert.equal(api.qaReadTextureUVTrace().status,'empty');assert.doesNotThrow(()=>JSON.stringify(out));
});
test('inventory callback reentrance cannot erase a new capture generation',t=>{
 const f=fixture();t.after(f.dispose);const x=f.texture();api.qaBeginTextureUVTrace();x.uScale=2;x.getTextureMatrix();api.qaEndTextureUVTrace();const original=f.scene.meshes;let once=true;f.scene.meshes=new Proxy(original,{get(target,key,receiver){if(key==='length'&&once){once=false;api.qaBeginTextureUVTrace();}return Reflect.get(target,key,receiver);}});
 let old;try{old=api.qaReadTextureUVTrace();}finally{f.scene.meshes=original;}x.uScale=1;x.getTextureMatrix();const next=api.qaReadTextureUVTrace();assert.ok(next.generation>old.generation);assert.equal(next.events.length,1);assert.equal(next.events[0].identity,true);
});
test('detached no-scene matrices preserve stock early return and emit no dirty notification',t=>{
 const f=fixture();t.after(f.dispose);const x=new Texture(null,f.engine);t.after(()=>x.dispose());api.qaBeginTextureUVTrace();x.uScale=2;assert.equal(x.getTextureMatrix().isIdentityAs3x2(),false);assert.equal(x._cachedIdentity3x2,true);const out=api.qaReadTextureUVTrace();assert.equal(out.events.length,0);assert.equal(out.inventory.available,false);
});
test('two scenes keep at most one inventory scene and explicitly mark other-scene notifications',t=>{
 const a=fixture(),b=fixture();t.after(()=>{b.dispose();a.dispose();});api.qaBeginTextureUVTrace();const x=a.texture(),y=b.texture();x.uScale=2;y.uScale=2;x.getTextureMatrix();y.getTextureMatrix();const out=api.qaReadTextureUVTrace();assert.equal(out.events.length,2);assert.equal(out.otherSceneNotifications,1);assert.deepEqual(out.events.map(e=>e.inventoryScene),[true,false]);assert.equal(out.inventory.available,true);
});
