import { readFileSync, writeFileSync, realpathSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
let uvDirtyHits = 0;
const uvDirtyTarget = realpathSync(createRequire(import.meta.url).resolve('@babylonjs/core/Materials/Textures/texture.pure.js')).replaceAll('\\', '/');
const uvDirtyPayload = readFileSync(new URL('./qa-uv-dirty/texture.pure.js.txt', import.meta.url), 'utf8');
const uvDirtyHash = (text: string) => createHash('sha256').update(text).digest('hex');
const uvDirtyPlugin: import('vite').Plugin = {name:'qa-exact-uv-dirty-probe',enforce:'pre',transform(code,id){if(id.split('?')[0].replaceAll('\\','/')!==uvDirtyTarget)return; if(uvDirtyHash(code)!=='f27fd4a566579ea2cc99c43ae056e48546b3d433aded037ab97c997c6299a976'||uvDirtyHash(uvDirtyPayload)!=='edaa133c49ee6886424b2530f51360ca1810b64912349a524d213e3e126fbe7c')throw new Error('UV probe SHA mismatch');uvDirtyHits++;return {code:uvDirtyPayload,map:null};},generateBundle(){if(uvDirtyHits!==1)throw new Error('UV probe overlay must match exactly once: '+uvDirtyHits);writeFileSync(new URL('../build-transform.json',import.meta.url),JSON.stringify({hits:uvDirtyHits,before:'f27fd4a566579ea2cc99c43ae056e48546b3d433aded037ab97c997c6299a976',after:'edaa133c49ee6886424b2530f51360ca1810b64912349a524d213e3e126fbe7c',target:uvDirtyTarget,scope:'QA probe only; no original notification skipped; borrowed dependencies unchanged.'},null,2)+'\n');}};
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
export default defineConfig({
  plugins: [react(), uvDirtyPlugin],
  optimizeDeps: {
    entries: ["index.html", "client/**/*.ts", "client/**/*.tsx"],
  },
  server: {
    // Reference downloads and audit snapshots contain their own tsconfig/index
    // files. Watching them forces unrelated live-game reloads during research.
    watch: {
      ignored: [
        "**/.cache/**",
        "**/docs/**",
        "**/assets/blender/**",
        // Reference/asset exports are explicitly reloaded after review. They
        // must not repeatedly interrupt an unrelated active multiplayer visit.
        "**/public/models/**",
        "**/assets/reference/**",
        "**/assets/derivative/**",
      ],
    },
    proxy: {
      // Keep the browser's local origin visible to the diagnostic collector.
      "/api": { target: "http://127.0.0.1:2567", changeOrigin: false },
      "/realtime": {
        target: "http://127.0.0.1:2567",
        ws: true,
        rewrite: (path) => path.replace(/^\/realtime/, ""),
      },
    },
  },
  build: {
    chunkSizeWarningLimit: 1100,
    rolldownOptions: {
      output: {
        codeSplitting: {
          groups: [{
            name: "babylon",
            test: /node_modules[\\/]@babylonjs[\\/]/,
            priority: 20,
            entriesAware: false,
            includeDependenciesRecursively: true,
          }],
        },
      },
    },
  },
});
