import test from 'node:test';
import assert from 'node:assert/strict';
import {createCpuSampler,beginQaCpuProfile,type CpuProfiler,type CpuProfileEntry} from '../client/qa-cpu-profile';
import {NullEngine} from '@babylonjs/core/Engines/nullEngine';
import {Scene} from '@babylonjs/core/scene';
import {Texture} from '@babylonjs/core/Materials/Textures/texture.pure';
const flush=async()=>{await Promise.resolve();await Promise.resolve();};

test('capture hooks own buffer-full, listener failure and stale-stop lifecycle without replacing profiler errors',async()=>{
  const calls:string[]=[],entries:CpuProfileEntry[]=[];
  let full=()=>{},resolve!:(trace:unknown)=>void;
  let pending=new Promise<unknown>(yes=>resolve=yes);
  const profiler:CpuProfiler={sampleInterval:16,addEventListener:(_,cb)=>{full=cb;},removeEventListener:()=>{},stop:()=>{calls.push('stop');return pending;}};
  const runtime={create:()=>profiler,now:()=>100,timeOrigin:()=>0,publish:(e:CpuProfileEntry)=>{entries.push(e);calls.push('publish');},captureStarted:()=>{calls.push('start');},captureStopped:()=>{calls.push('end');}};
  const sampler=createCpuSampler(runtime),old=sampler.begin()!;
  assert.equal(sampler.begin(),undefined);full();old('stale');assert.deepEqual(calls,['start','end','stop']);
  resolve({});await flush();assert.deepEqual(calls,['start','end','stop','publish']);
  pending=new Promise<unknown>(yes=>resolve=yes);const current=sampler.begin()!;old('old-again');assert.equal(calls.at(-1),'start');current('dispose');resolve({});await flush();
  runtime.captureStarted=()=>{throw new Error('QA start');};runtime.captureStopped=()=>{throw new Error('QA end');};
  profiler.addEventListener=()=>{throw new Error('listener failure');};profiler.stop=()=>Promise.resolve({});
  assert.doesNotThrow(()=>sampler.begin());await flush();assert.equal(entries.at(-1)?.status,'error');assert.match(entries.at(-1)?.error??'',/listener failure/);
});

test('existing public CPU export contains actual Texture notification and resets it on next capture',async()=>{
  const previousWindow=Object.getOwnPropertyDescriptor(globalThis,'window'),previousDocument=Object.getOwnPropertyDescriptor(globalThis,'document');
  const nodes:{tag:string;id?:string;textContent?:string;style:{cssText:string};append(...children:unknown[]):void}[]=[];
  const element=(tag:string)=>{const node={tag,style:{cssText:''},append(..._children:unknown[]){}};nodes.push(node);return node;};
  class Profiler{sampleInterval=16;constructor(options:unknown){assert.deepEqual(options,{sampleInterval:16,maxBufferSize:2000});}addEventListener(){}removeEventListener(){}stop(){return Promise.resolve({samples:[]});}}
  Object.defineProperty(globalThis,'window',{configurable:true,value:{Profiler}});
  Object.defineProperty(globalThis,'document',{configurable:true,value:{body:element('body'),createElement:element}});
  const engine=new NullEngine(),scene=new Scene(engine),texture=new Texture(null,scene);texture.uScale=2;
  try{
    let dirty=0;scene.markAllMaterialsAsDirty=()=>{dirty++;};
    const stop=beginQaCpuProfile()!;assert.equal(typeof stop,'function');texture.getTextureMatrix();assert.equal(dirty,1);stop('benchmark-end');await flush();
    const pre=nodes.find(n=>n.tag==='pre')!;assert.equal(pre.id,'cpu-profile-result');
    const first=JSON.parse(pre.textContent!);assert.equal(first.status,'captured');assert.equal(first.textureUVTrace.events.length,1);assert.equal(first.textureUVTrace.events[0].hadCachedMatrix,false);
    beginQaCpuProfile()!('dispose');await flush();const second=JSON.parse(pre.textContent!);assert.equal(second.textureUVTrace.events.length,0);assert.deepEqual(second.trace,{samples:[]});
  }finally{
    if(previousWindow)Object.defineProperty(globalThis,'window',previousWindow);else Reflect.deleteProperty(globalThis,'window');
    if(previousDocument)Object.defineProperty(globalThis,'document',previousDocument);else Reflect.deleteProperty(globalThis,'document');
    texture.dispose();scene.dispose();engine.dispose();
  }
});
