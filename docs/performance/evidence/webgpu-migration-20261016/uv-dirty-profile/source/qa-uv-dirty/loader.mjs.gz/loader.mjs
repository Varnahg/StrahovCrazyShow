import {readFileSync,realpathSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
const hash=b=>createHash('sha256').update(b).digest('hex');
const target=pathToFileURL(realpathSync(join(process.env.UV_DIRTY_CORE,'Materials/Textures/texture.pure.js'))).href;
export async function load(url,context,nextLoad){
  if(url!==target)return nextLoad(url,context);
  const original=readFileSync(new URL(url));
  if(hash(original)!=='f27fd4a566579ea2cc99c43ae056e48546b3d433aded037ab97c997c6299a976')throw new Error('UV probe preimage mismatch');
  const payload=readFileSync(process.env.UV_DIRTY_MODULE);
  if(hash(payload)!==process.env.UV_DIRTY_SHA)throw new Error('UV probe payload mismatch');
  return {format:'module',source:payload.toString(),shortCircuit:true};
}
