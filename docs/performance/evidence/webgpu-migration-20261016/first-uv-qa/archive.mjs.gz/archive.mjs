import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,readdirSync,mkdirSync} from 'node:fs';
import {join,resolve,dirname} from 'node:path';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
const root=import.meta.dirname,repo=resolve(root,'../..'),helper=join(repo,'.cache/webgpu-first-uv-helper-20261019');
const out=join(repo,'docs/performance/evidence/webgpu-migration-20261016/first-uv-qa'),hash=b=>createHash('sha256').update(b).digest('hex'),files={};
mkdirSync(out,{recursive:true});
function save(name,bytes){const raw=Buffer.isBuffer(bytes)?bytes:Buffer.from(bytes),zip=!name.endsWith('.png'),dest=name+(zip?'.gz':'');const data=zip?gzipSync(raw):raw;mkdirSync(dirname(join(out,dest)),{recursive:true});writeFileSync(join(out,dest),data);files[dest]={encoding:zip?'gzip':'identity',sha256:hash(data),bytes:data.length,originalSha256:hash(raw),originalBytes:raw.length};}
for(const name of ['assemble.mjs','validate.mjs','archive.mjs','analyze.mjs','assembly.json','validation.json','targeted.log','types.log','build.log','dist-manifest.json','build-transform.json','start.ps1','stop.ps1','preview.mjs','weather.json','collect.mjs','gpu-state.mjs','protocol.json'])save(name,readFileSync(join(root,name)));
const m=JSON.parse(readFileSync(join(root,'snapshot/source-manifest.json')));assert.equal(hash(JSON.stringify(m.files)),m.snapshotId);for(const[p,sha]of Object.entries(m.files))assert.equal(hash(readFileSync(join(root,'snapshot',p))),sha,p);
save('source-manifest.json',readFileSync(join(root,'snapshot/source-manifest.json')));
for(const p of Object.keys(m.files).filter(p=>p==='vite.config.ts'||p.startsWith('qa-first-uv/')))save('source/'+p,readFileSync(join(root,'snapshot',p)));
for(const name of readdirSync(join(root,'runs/c1')))if(name!=='runtime.json')save('run/'+name,readFileSync(join(root,'runs/c1',name)));
const {processes,...provenance}=JSON.parse(readFileSync(join(root,'runs/c1/runtime.json')));save('run/provenance.json',JSON.stringify({...provenance,processes:'Own services stopped after PID/start/path/command verification; operational records remain ignored.'},null,2));
save('unmeasured-session.jsonl',readFileSync(join(root,'snapshot/.cache/game-diagnostics/55e30d90-ca52-418a-8114-30401e124eee.jsonl')));
const helperManifest=readFileSync(join(helper,'manifest.json'));assert.equal(hash(helperManifest),'601cbaa6db2989c14a66631e22c502515652e2f44cbeefad13816ac81726eb9e');const h=JSON.parse(helperManifest);save('helper/manifest.json',helperManifest);
for(const[p,sha]of Object.entries(h.artifacts)){const raw=readFileSync(join(repo,p));assert.equal(hash(raw),sha,p);save('helper/'+p.slice('.cache/webgpu-first-uv-helper-20261019/'.length),raw);}
for(const[p,sha]of Object.entries(h.inputs))assert.equal(hash(readFileSync(p)),sha,p);
for(const name of readdirSync(join(root,'helper-replay')))save('helper-replay/'+name,readFileSync(join(root,'helper-replay',name)));
const proof=JSON.parse(readFileSync(join(root,'helper-replay/proof-results.json')));assert.equal(proof.passed,true);
const result=JSON.parse(readFileSync(join(root,'runs/c1/analysis.json')));assert.equal(result.summary.valid,true);assert.match(result.verdict,/NOT ACCEPTED/);
save('review.json',JSON.stringify({findings:[],scope:'Independent candidate-only review before GPU: exact2hunk math/cache/late transitions/WebGL and one-hit immutable-dependency transform. CPU helper parity subsequently completed/replayed. Does not accept FPS or full visual/lifecycle parity.'},null,2));
writeFileSync(join(out,'artifact-manifest.json'),JSON.stringify({source:m.snapshotId,verdict:result.verdict,helperManifestSha256:hash(helperManifest),files},null,2)+'\n');
console.log(JSON.stringify({source:m.snapshotId,files:Object.keys(files).length,verdict:result.verdict}));
