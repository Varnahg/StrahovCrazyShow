import{moduleAt}from'./loader.mjs';
export const{NullEngine}=await moduleAt('Engines/nullEngine.js');
export const{Scene}=await moduleAt('scene.js');
export const{Texture}=await moduleAt('Materials/Textures/texture.js');
export const{RawTexture}=await moduleAt('Materials/Textures/rawTexture.js');
export const{StandardMaterial}=await moduleAt('Materials/standardMaterial.js');
export const{PBRMaterial}=await moduleAt('Materials/PBR/pbrMaterial.js');
export const{MeshBuilder}=await moduleAt('Meshes/meshBuilder.js');
export const{FreeCamera}=await moduleAt('Cameras/freeCamera.js');
export const{Vector3}=await moduleAt('Maths/math.vector.js');
export function fixture(gpu=true){
 const engine=new NullEngine(),scene=new Scene(engine);const original=scene.markAllMaterialsAsDirty.bind(scene),dirty=[];
 scene.markAllMaterialsAsDirty=function(flag,predicate){dirty.push({flag,predicate});return original(flag,predicate);};
 Object.defineProperty(engine,'isWebGPU',{value:gpu,configurable:true});
 const textures=[];function texture(raw=false){const t=raw?RawTexture.CreateRGBTexture(new Uint8Array([255,255,255]),1,1,scene,false,false,Texture.NEAREST_SAMPLINGMODE):new Texture(null,scene);if(raw)t.getInternalTexture().isReady=true;/* NullEngine has no GPU upload/ready completion; model the supplied one-pixel decoded resource. */textures.push(t);return t;}
 return{engine,scene,dirty,texture,dispose(){for(const t of textures)t.dispose();scene.dispose();engine.dispose();}};
}
