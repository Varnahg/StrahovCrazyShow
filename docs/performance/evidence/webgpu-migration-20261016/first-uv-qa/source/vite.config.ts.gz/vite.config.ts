import { readFileSync, writeFileSync, realpathSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
let firstUvHits = 0;
const firstUvTarget = realpathSync(createRequire(import.meta.url).resolve('@babylonjs/core/Materials/Textures/texture.pure.js')).replaceAll('\\', '/');
const firstUvPayload = readFileSync(new URL('./qa-first-uv/texture.pure.js.txt', import.meta.url), 'utf8');
const firstUvHash = (text: string) => createHash('sha256').update(text).digest('hex');
const firstUvPlugin: import('vite').Plugin = {name:'qa-exact-first-uv',enforce:'pre',transform(code,id){if(id.split('?')[0].replaceAll('\\','/')!==firstUvTarget)return; if(firstUvHash(code)!=='f27fd4a566579ea2cc99c43ae056e48546b3d433aded037ab97c997c6299a976'||firstUvHash(firstUvPayload)!=='f98c6a16047d4b6990351a415b002b3f0cc5886e9c6812aa5fc5cd49dc29ee93')throw new Error('UV payload SHA mismatch');firstUvHits++;return {code:firstUvPayload,map:null};},generateBundle(){if(firstUvHits!==1)throw new Error('UV overlay must match exactly once: '+firstUvHits);writeFileSync(new URL('../build-transform.json',import.meta.url),JSON.stringify({hits:firstUvHits,before:'f27fd4a566579ea2cc99c43ae056e48546b3d433aded037ab97c997c6299a976',after:'f98c6a16047d4b6990351a415b002b3f0cc5886e9c6812aa5fc5cd49dc29ee93',target:firstUvTarget,scope:'Build-only exact module overlay; borrowed dependencies unchanged.'},null,2)+'\n');}};
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
export default defineConfig({
  plugins: [react(), firstUvPlugin],
  optimizeDeps: {
    entries: ["index.html", "client/**/*.ts", "client/**/*.tsx"],
  },
  server: {
    // Reference downloads and audit snapshots contain their own tsconfig/index
    // files. Watching them forces unrelated live-game reloads during research.
    watch: {
      ignored: [
        "**/.cache/**",
        "**/docs/**",
        "**/assets/blender/**",
        // Reference/asset exports are explicitly reloaded after review. They
        // must not repeatedly interrupt an unrelated active multiplayer visit.
        "**/public/models/**",
        "**/assets/reference/**",
        "**/assets/derivative/**",
      ],
    },
    proxy: {
      // Keep the browser's local origin visible to the diagnostic collector.
      "/api": { target: "http://127.0.0.1:2567", changeOrigin: false },
      "/realtime": {
        target: "http://127.0.0.1:2567",
        ws: true,
        rewrite: (path) => path.replace(/^\/realtime/, ""),
      },
    },
  },
  build: {
    chunkSizeWarningLimit: 1100,
    rolldownOptions: {
      output: {
        codeSplitting: {
          groups: [{
            name: "babylon",
            test: /node_modules[\\/]@babylonjs[\\/]/,
            priority: 20,
            entriesAware: false,
            includeDependenciesRecursively: true,
          }],
        },
      },
    },
  },
});
