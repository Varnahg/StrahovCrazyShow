import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync,readdirSync} from 'node:fs';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=import.meta.dirname,cwd=join(root,'snapshot'),hash=b=>createHash('sha256').update(b).digest('hex');
const manifest=JSON.parse(readFileSync(join(cwd,'source-manifest.json')));assert.equal(hash(JSON.stringify(manifest.files)),manifest.snapshotId);
function verify(){for(const[p,sha]of Object.entries(manifest.files))assert.equal(hash(readFileSync(join(cwd,p))),sha,p);}
const phases=[['targeted',['--test','qa-first-uv/first-uv.test.mjs']],['types',['node_modules/typescript/bin/tsc','--noEmit']],['build',['node_modules/vite/bin/vite.js','build','--configLoader','native']]];
const results=[];verify();
for(const[phase,args]of phases){const log=join(root,phase+'.log');assert.ok(!existsSync(log),'Preserve '+log);const startedAt=new Date().toISOString();const r=spawnSync(process.execPath,args,{cwd,env:{...process.env,VITE_SOURCE_SNAPSHOT_ID:manifest.snapshotId,TSX_DISABLE_CACHE:'1',FIRST_UV_CORE:join(cwd,'node_modules/@babylonjs/core'),FIRST_UV_MODULE:join(cwd,'qa-first-uv/texture.pure.js.txt')},encoding:'utf8',maxBuffer:64*1024*1024});writeFileSync(log,(r.stdout??'')+(r.stderr??''));const result={phase,exitCode:r.status,startedAt,endedAt:new Date().toISOString(),log,sha256:hash(readFileSync(log))};results.push(result);verify();writeFileSync(join(root,'validation.json'),JSON.stringify({source:manifest.snapshotId,results},null,2)+'\n');console.log(JSON.stringify(result));if(r.status!==0){console.log((r.stdout??'').slice(-3500)+(r.stderr??'').slice(-1800));process.exit(r.status||1);}}
function entries(dir,prefix=''){return readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?entries(join(dir,e.name),prefix+e.name+'/'):/\.(js|html|css|wasm)$/.test(e.name)?[[prefix+e.name,hash(readFileSync(join(dir,e.name)))]]:[]);}
writeFileSync(join(root,'dist-manifest.json'),JSON.stringify(Object.fromEntries(entries(join(cwd,'dist'))),null,2)+'\n');

const proof=JSON.parse(readFileSync(join(root,'build-transform.json')));assert.equal(proof.hits,1);assert.equal(proof.after,'f98c6a16047d4b6990351a415b002b3f0cc5886e9c6812aa5fc5cd49dc29ee93');assert.equal(hash(readFileSync(join(cwd,'node_modules/@babylonjs/core/Materials/Textures/texture.pure.js'))),'f27fd4a566579ea2cc99c43ae056e48546b3d433aded037ab97c997c6299a976');
