import test from'node:test';import assert from'node:assert/strict';import{fixture,Texture}from'./fixture.mjs';

test('first WebGPU nonidentity computes actual matrix/cache without a dirty scan; later both transitions still notify',t=>{
 const f=fixture();t.after(f.dispose);const tex=f.texture();tex.uScale=2;assert.equal(tex._cachedTextureMatrix,null);f.dirty.length=0;
 const matrix=tex.getTextureMatrix();assert.equal(matrix.isIdentityAs3x2(),false);assert.equal(tex._cachedIdentity3x2,false);assert.equal(f.dirty.length,0);
 assert.equal(tex.getTextureMatrix(),matrix);assert.equal(f.dirty.length,0);tex.uScale=1;assert.equal(tex.getTextureMatrix().isIdentityAs3x2(),true);assert.equal(f.dirty.length,1);
 tex.uOffset=.25;assert.equal(tex.getTextureMatrix().isIdentityAs3x2(),false);assert.equal(f.dirty.length,2);assert.ok(f.dirty.every(e=>e.flag===1&&typeof e.predicate==='function'));
});

test('first identity and WebGL historical first nonidentity notifications remain unchanged',t=>{
 const f=fixture();t.after(f.dispose);const tex=f.texture();f.dirty.length=0;assert.equal(tex.getTextureMatrix().isIdentityAs3x2(),true);assert.equal(f.dirty.length,0);
 const gl=fixture(false);t.after(gl.dispose);const g=gl.texture();g.uScale=2;gl.dirty.length=0;assert.equal(g.getTextureMatrix().isIdentityAs3x2(),false);assert.equal(gl.dirty.length,1);g.uScale=1;g.getTextureMatrix();assert.equal(gl.dirty.length,2);
});

test('uBase and clone each preserve actual texture math and subsequent invalidation',t=>{
 const f=fixture();t.after(f.dispose);const tex=f.texture();f.dirty.length=0;assert.equal(tex.getTextureMatrix(2).isIdentityAs3x2(),false);assert.equal(f.dirty.length,0);
 assert.equal(tex.getTextureMatrix(1).isIdentityAs3x2(),true);assert.equal(f.dirty.length,1);tex.uScale=3;tex.vOffset=.2;tex.getTextureMatrix();const cloned=tex.clone();t.after(()=>cloned.dispose());assert.equal(cloned._cachedTextureMatrix,null);f.dirty.length=0;
 assert.deepEqual(Array.from(cloned.getTextureMatrix().asArray()),Array.from(tex.getTextureMatrix().asArray()));assert.equal(f.dirty.length,0);assert.equal(cloned._cachedIdentity3x2,false);
});

test('optimizeUVAllocation toggles and detached/no-scene matrix behavior preserve stock rules',t=>{
 const f=fixture();t.after(f.dispose);const tex=f.texture();tex.optimizeUVAllocation=false;tex.uScale=2;f.dirty.length=0;tex.getTextureMatrix();assert.equal(f.dirty.length,0);assert.equal(tex._cachedIdentity3x2,false);
 tex.optimizeUVAllocation=true;tex.getTextureMatrix();assert.equal(f.dirty.length,0,'Existing cached fast path does not add toggle invalidation');tex.uScale=1;tex.getTextureMatrix();assert.equal(f.dirty.length,1);
 const detached=new Texture(null,f.engine);t.after(()=>detached.dispose());assert.equal(detached.getScene(),null);detached.uScale=2;assert.equal(detached.getTextureMatrix().isIdentityAs3x2(),false);assert.equal(detached._cachedIdentity3x2,true,'Original no-scene early return leaves private identity flag untouched');
});
