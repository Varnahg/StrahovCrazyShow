import fs from'node:fs';import path from'node:path';import{registerHooks}from'node:module';import{fileURLToPath,pathToFileURL}from'node:url';
export const core=path.resolve(process.env.FIRST_UV_CORE||fileURLToPath(new URL('../webgpu-shadow-share-native-qa-20261019/clean/node_modules/@babylonjs/core',import.meta.url)));
const target=fs.realpathSync(path.join(core,'Materials/Textures/texture.pure.js')).replaceAll('\\','/');
const selected=process.env.FIRST_UV_MODULE||fileURLToPath(new URL('./candidate/Textures/texture.pure.js',import.meta.url));
if(process.env.FIRST_UV_VARIANT!=='A')registerHooks({load(url,context,next){if(url.startsWith('file:')&&fileURLToPath(url).replaceAll('\\','/')===target)return{format:'module',source:fs.readFileSync(selected,'utf8'),shortCircuit:true};return next(url,context);}});
export const moduleAt=relative=>import(pathToFileURL(path.join(core,relative)).href);
