import fs from'node:fs';import path from'node:path';import{fileURLToPath}from'node:url';import{spawnSync}from'node:child_process';import assert from'node:assert/strict';import{createHash}from'node:crypto';
const root=path.dirname(fileURLToPath(import.meta.url)),out=path.resolve(process.argv[2]||root);fs.mkdirSync(out,{recursive:true});
const jobs=[['red',['--test','first-uv.test.mjs'],{FIRST_UV_VARIANT:'A'}],['green',['--test','first-uv.test.mjs'],{FIRST_UV_VARIANT:'B'}],...['0','1'].flatMap(gpu=>['A','B'].map(variant=>['material-'+gpu+'-'+variant,['material-case.mjs'],{CASE_GPU:gpu,FIRST_UV_VARIANT:variant,CASE_OUTPUT:path.join(out,'material-'+gpu+'-'+variant+'.json')}]))];
const results=[];for(const[name,args,env]of jobs){const r=spawnSync(process.execPath,args,{cwd:root,encoding:'utf8',timeout:20000,maxBuffer:1024*1024,env:{...process.env,...env}});fs.writeFileSync(path.join(out,name+'.log'),(r.stdout||'')+(r.stderr||'')+(r.error?'\n'+r.error.stack:''));results.push({name,exitCode:r.status,passed:Number(r.stdout?.match(/(?:ℹ|#) pass (\d+)/)?.[1]||0),failed:Number(r.stdout?.match(/(?:ℹ|#) fail (\d+)/)?.[1]||0),error:r.error?.message});}
const checks=[];try{
 assert.equal(results[0].exitCode,1);assert.equal(results[1].exitCode,0);assert.ok(results.slice(2).every(r=>r.exitCode===0));
 for(const gpu of['0','1']){
  const a=JSON.parse(fs.readFileSync(path.join(out,'material-'+gpu+'-A.json'))),b=JSON.parse(fs.readFileSync(path.join(out,'material-'+gpu+'-B.json')));
  for(const record of[a,b])for(const[hash,text]of Object.entries(record.shaders))assert.equal(createHash('sha256').update(text).digest('hex'),hash);
  const dirtyA=a.stages.map(s=>s.dirty),dirtyB=b.stages.map(s=>s.dirty);
  if(gpu==='1'){assert.equal(dirtyA[0],1);assert.equal(dirtyB[0],0);assert.deepEqual(dirtyA.slice(1),dirtyB.slice(1));a.stages[0].dirty=0;}
  assert.deepEqual(b,a,'Full matrix bytes, defines, descriptors and exact shader source table');checks.push({gpu:gpu==='1',stages:a.stages.length,materialKinds:a.materialKinds,shaderSources:Object.keys(a.shaders).length,dirtyA,dirtyB,fullParityExact:true});
 }
}catch(error){fs.writeFileSync(path.join(out,'parity-failure.log'),error.stack);process.exitCode=1;}
const report={node:process.version,results,checks,passed:checks.length===2&&process.exitCode!==1};fs.writeFileSync(path.join(out,'proof-results.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
