import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
const root=import.meta.dirname,dir=join(root,'runs/c1');
const b=JSON.parse(readFileSync(join(dir,'benchmark.json'))),summary=JSON.parse(readFileSync(join(dir,'summary.json')));
const records=readFileSync(join(dir,'session.jsonl'),'utf8').trim().split(/\r?\n/).map(JSON.parse).flatMap(r=>r.records??[]);
const start=records.find(r=>r.kind==='benchmark-start').atMs,end=start+b.durationSeconds*1000;
const hitches=records.filter(r=>r.kind==='frame-hitch'&&r.data.intervalEndMs>=start&&r.data.intervalEndMs<=end).map(r=>({seq:r.seq,...r.data}));
const contexts=records.filter(r=>r.kind==='frame-window'&&r.data.contextAtMs>=start&&r.data.contextAtMs<=end).map(r=>({atMs:r.data.contextAtMs,...r.data.context}));
const result={source:b.sourceSnapshotId,session:summary.session,benchmark:[start,end],summary,hitches,contexts,
  verdict:'NOT ACCEPTED: production benefit unproven; no native runtime/lockfile integration.',
  observations:['Actual first entry:181.5ms frame,175.6ms preceding synchronous CPU,133ms render.','Largest interval802.9ms:756.9ms preceding synchronous CPU,686.7ms render; not attributed to a particular routine.','No GPU validation/render/asset error.14 benchmark intervals >=100ms;6shader preparations/12modules/7syncpipeline.'],
  limitations:['Exploratory single run; ambient2buses/4passengers/2cars differs from earlier native0/1/0.','GPU88C before/after; clocks1797→1480MHz; no clock lock or thermal causality established.','Setup required lateral walking to avoid collectible priority and a rejected vehicle action; not the exact prior starting camera/position.','New card opened over existing service after original unmeasured card closed at turn end; sessions distinguished by actual benchmark and source.','First-vs-later UV transition not captured. CPU parity does not prove GPU improvement.','Summary valid=true covers integrity/basicconditions only, not comparative acceptance.']};
assert.equal(summary.source,b.sourceSnapshotId);assert.equal(summary.valid,true);assert.equal(summary.over100,14);assert.equal(hitches.filter(r=>r.frameMs>=100).length,12,'Bounded/throttled frame-hitch records are not a complete interval histogram');
writeFileSync(join(dir,'analysis.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({verdict:result.verdict,intervalsOver100:summary.over100,retainedHitchRecordsOver100:hitches.filter(r=>r.frameMs>=100).length,largest:hitches.reduce((a,r)=>r.frameMs>a.frameMs?r:a)}));
