import {AuthoredLightPreparation} from "../client/authored-light-preparation";
import test, {after} from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import {setImmediate as turn,setTimeout as pause} from "node:timers/promises";
import {createHash} from "node:crypto";
import {Script} from "node:vm";
import ts from "typescript";
import {NullEngine} from "@babylonjs/core/Engines/nullEngine";
import {Scene} from "@babylonjs/core/scene";
import {FreeCamera} from "@babylonjs/core/Cameras/freeCamera";
import {Vector3} from "@babylonjs/core/Maths/math.vector";
import {InternalTexture,InternalTextureSource} from "@babylonjs/core/Materials/Textures/internalTexture";
import {StandardMaterial} from "@babylonjs/core/Materials/standardMaterial";
import {TransformNode} from "@babylonjs/core/Meshes/transformNode";
import {DirectionalLight} from "@babylonjs/core/Lights/directionalLight";
import {HemisphericLight} from "@babylonjs/core/Lights/hemisphericLight";
import {PointLight} from "@babylonjs/core/Lights/pointLight";
import {Light} from "@babylonjs/core/Lights/light";
import {MeshBuilder} from "@babylonjs/core/Meshes/meshBuilder";
import {buildArchitectureReality} from "../../../webgpu-hitch-validation-20261017/grass-preparation-v2/client/architecture-reality";
import {createOutdoorArtifacts} from "../../../webgpu-hitch-validation-20261017/grass-preparation-v2/client/outdoor-artifacts";
import {buildOutdoorArtifactPlan} from "../../../webgpu-hitch-validation-20261017/grass-preparation-v2/shared/outdoor-artifacts";
import {BUILDINGS} from "../../../webgpu-hitch-validation-20261017/grass-preparation-v2/shared/world";
import {CinematicAtmosphere} from "../../../webgpu-hitch-validation-20261017/grass-preparation-v2/client/cinematic";
import {GltfLightBudget} from "../../../webgpu-hitch-validation-20261017/grass-preparation-v2/client/gltf-light-budget";
import {StableLightState} from "../../../webgpu-hitch-validation-20261017/grass-preparation-v2/client/stable-light-state";
import {VehicleLighting} from "../../../webgpu-hitch-validation-20261017/grass-preparation-v2/client/vehicle-lighting";
import {PlayerFlashlight} from "../../../webgpu-hitch-validation-20261017/grass-preparation-v2/client/flashlight";
import {prepareLightVariants} from "../../../webgpu-hitch-validation-20261017/grass-preparation-v2/client/light-preparation";
import {prepareRenderQualities} from "../../../webgpu-hitch-validation-20261017/grass-preparation-v2/client/render-quality-preparation";
import {MANUAL_HARDWARE_SCALING} from "../../../webgpu-hitch-validation-20261017/grass-preparation-v2/shared/render-quality";
import {arePreparationEffectsReady} from "../../../webgpu-hitch-validation-20261017/grass-preparation-v2/client/strict-material-preparation";
import {applyArtLighting} from "../../../webgpu-hitch-validation-20261017/grass-preparation-v2/client/art-lighting";
import {selectLightingPreview} from "../../../webgpu-hitch-validation-20261017/grass-preparation-v2/client/lighting-preview";
import {sunState,moonState} from "../../../webgpu-hitch-validation-20261017/grass-preparation-v2/shared/weather";
import {clampOrbitPitch} from "../../../webgpu-hitch-validation-20261017/grass-preparation-v2/client/camera-look";
import "../../../webgpu-hitch-validation-20261017/grass-preparation-v2/client/render-shaders";

const sha=(s:string)=>createHash("sha256").update(s).digest("hex");
const report:any={scope:"Actual source factory/GLSL frontend; synthetic canvas/texture upload only, no pixels/WGSL/GPU claim",cases:[]};
after(()=>fs.writeFileSync(new URL(`report-${process.env.PROOF_RUN}.json`,import.meta.url),JSON.stringify(report,null,2)+"\n",{flag:"wx"}));

class IOEngine extends NullEngine {
  override createCanvas(width:number,height:number):any {
    const gradient={addColorStop(){}};
    const canvas:any={width,height,remove(){}};
    const context=new Proxy({canvas,createLinearGradient:()=>gradient,createRadialGradient:()=>gradient,measureText:(text:string)=>({width:text.length*8})} as any,{get:(target,key)=>key in target?target[key]:()=>{},set:(target,key,value)=>{target[key]=value;return true;}});
    canvas.getContext=()=>context;return canvas;
  }
  override updateDynamicTexture(texture:InternalTexture,..._args:any[]) { texture.isReady=true; }
  override createRawCubeTexture(...args:Parameters<NullEngine["createRawCubeTexture"]>) {
    const texture=new InternalTexture(this,InternalTextureSource.CubeRaw);
    texture.isCube=texture.isReady=true;texture.width=texture.height=texture.baseWidth=texture.baseHeight=args[1];
    texture.generateMipMaps=args[4]??false;texture.samplingMode=args[6]??3;return texture;
  }
  override updateRawCubeTexture(..._args:any[]) {}
}

function factories(t:import("node:test").TestContext) {
  const engine=new IOEngine({renderWidth:256,renderHeight:256,textureSize:1,deterministicLockstep:false,lockstepMaxSteps:4}),scene=new Scene(engine);scene.useRightHandedSystem=true;
  const budget=new GltfLightBudget(scene);
  const cleanups:(()=>void)[]=[];
  const previous=Object.getOwnPropertyDescriptor(globalThis,"document");
  let architecture:ReturnType<typeof buildArchitectureReality>;
  try { Object.defineProperty(globalThis,"document",{value:{},configurable:true});architecture=buildArchitectureReality({scene,buildings:BUILDINGS.filter(b=>b.id==="53929057")}); }
  finally {if(previous)Object.defineProperty(globalThis,"document",previous);else Reflect.deleteProperty(globalThis,"document");}
  assert.equal(architecture.metrics.buildings,1);
  const plan=buildOutdoorArtifactPlan(),id="node/4002100657";
  const outdoor=createOutdoorArtifacts(scene,{...plan,artifacts:plan.artifacts.filter(x=>x.id===id),parts:plan.parts.filter(x=>x.artifactId===id&&x.material==="outdoor-dark-metal"),colliders:plan.colliders.filter(x=>x.artifactId===id)});
  assert.ok(outdoor.meshes.length>0);
  const names=["reality glass 0 0","reality glass 0 1","outdoor-artifacts:outdoor-dark-metal"];
  const target=scene.meshes.filter(m=>names.includes(m.material?.name??""));assert.ok(names.every(n=>target.some(m=>m.material?.name===n)));
  const low=new Vector3(Infinity,Infinity,Infinity),high=new Vector3(-Infinity,-Infinity,-Infinity);
  for(const m of target){m.computeWorldMatrix(true);const b=m.getBoundingInfo().boundingBox;low.minimizeInPlace(b.minimumWorld);high.maximizeInPlace(b.maximumWorld);}
  const camera=new FreeCamera("actual camera pass",new Vector3((low.x+high.x)/2,(low.y+high.y)/2,low.z-20),scene);camera.fov=2.3;camera.maxZ=1000;camera.setTarget(low.add(high).scale(.5));scene.activeCamera=camera;
  // The factory owns a complete one-building pack. Exclude unrelated authored
  // materials from this bounded test, without altering any target geometry.
  for(const mesh of scene.meshes)if(!target.includes(mesh))mesh.setEnabled(false);
  t.after(()=>{try{for(const cleanup of cleanups.reverse())cleanup();}finally{outdoor.dispose();architecture.dispose();budget.dispose();scene.dispose();engine.dispose();}assert.equal(scene.meshes.length,0);assert.equal(scene.materials.length,0);});
  return {engine,scene,camera,architecture,outdoor,target,names,low,high,budget,cleanups};
}

test("actual authored factories retain browser texture metadata in bounded IO adapter",t=>{
  const f=factories(t);
  report.cases.push({kind:"factory",bounds:[f.low.asArray(),f.high.asArray()],targets:f.target.map(m=>({name:m.name,material:m.material?.name,enabled:m.isEnabled(),vertices:m.getTotalVertices(),indices:m.getTotalIndices(),bounds:m.getBoundingInfo().boundingBox.centerWorld.asArray()})),materials:f.names.map(n=>{const m:any=f.scene.materials.find(x=>x.name===n)!;return{name:n,max:m.maxSimultaneousLights,diffuse:m.diffuseTexture?.getClassName(),diffuseReady:m.diffuseTexture?.isReady(),emissive:m.emissiveTexture?.getClassName(),emissiveReady:m.emissiveTexture?.isReady(),emissiveIllumination:m.useEmissiveAsIllumination};})});
  const lit:any=f.scene.materials.find(x=>x.name==="reality glass 0 1");assert.ok(lit.diffuseTexture?.isReady());assert.ok(lit.emissiveTexture?.isReady());assert.equal(lit.useEmissiveAsIllumination,true);
});

const gameSource=fs.readFileSync(new URL("../client/game.ts",import.meta.url),"utf8");
const tree=ts.createSourceFile("game.ts",gameSource,ts.ScriptTarget.Latest,true),declaration=tree.statements.find((n):n is ts.ClassDeclaration=>ts.isClassDeclaration(n)&&n.name?.text==="Game")!;
const selected=["prepareLighting","prepareLightingVariants","isMeshReadyForCamera","updateRenderEnvironment","applyRenderQuality","updateCameraFollow","alignVehicleCamera","footFirstPerson","updatePreloadVisuals"];
const methods=declaration.members.filter(n=>n.name&&selected.includes(n.name.getText(tree)));assert.equal(methods.length,selected.length);
report.methods=methods.map(n=>({name:n.name!.getText(tree),sha256:sha(n.getText(tree))}));
const code=ts.transpileModule(`class ProofGame {${methods.map(n=>n.getText(tree)).join("\n")}}`,{compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText;
const make=new Script(`(env)=>{const {AuthoredLightPreparation,PlayerFlashlight,Vector3,MeshBuilder,prepareLightVariants,prepareRenderQualities,MANUAL_HARDWARE_SCALING,arePreparationEffectsReady,selectLightingPreview,applyArtLighting,clampOrbitPitch,performance,window,document}=env;${code};return ProofGame;}`).runInThisContext();
const anchor=Date.parse("2026-10-18T12:45:00Z"),select=(mode:Parameters<typeof selectLightingPreview>[0])=>selectLightingPreview(mode,anchor);

for(const initialQuality of ["low","medium"]) test(`cold opposite view with only two vehicle leases, initial ${initialQuality}`,async t=>{
  const preparedView=false;
  const f=factories(t),{engine,scene,camera,budget}=f;
  const row:any={preparedView,initialQuality,stages:[],replays:[],status:"started"};report.cases.push(row);
  const sun=new DirectionalLight("celestial",Vector3.Down(),scene),ambient=new HemisphericLight("sky",Vector3.Up(),scene);
  const cinematic=new CinematicAtmosphere(scene,camera,sun),stable=new StableLightState(scene),beam=new VehicleLighting(scene),torch=new PlayerFlashlight(scene);
  const pos=Object.freeze({x:(f.low.x+f.high.x)/2,y:(f.low.y+f.high.y)/2-.6,z:f.low.z-20});
  const actor={position:pos,yaw:0,vehicle:false},car=new TransformNode("actual driving visual",scene),parked=new TransformNode("actual parked visual",scene);car.position.copyFromFloats(pos.x,pos.y-.8,pos.z);car.setEnabled(false);
  const root=new TransformNode("local rig",scene),elbow=new TransformNode("actual right elbow",scene);root.position.copyFromFloats(pos.x,pos.y-.8,pos.z);elbow.parent=root;elbow.position.y=1.3;elbow.rotation.x=-Math.PI/2;
  const rig={root,rightElbow:elbow,eyeHeight:1.63,bodyHeight:1.8,measurements:{legSpacing:.105},target:{id:"local",vehicle:false}};
  const lights=[0,1].map(i=>{const light=new PointLight(`mapped POINT ${i}`,new Vector3(pos.x+i,pos.y+3,pos.z+3),scene);light.falloffType=Light.FALLOFF_STANDARD;light.range=22;return light;});
  const skyMaterial=new StandardMaterial("sky IO only",scene);skyMaterial.disableLighting=true;skyMaterial.disableDepthWrite=true;skyMaterial.backFaceCulling=false;
  let callback:(()=>void)|undefined,stage="",programs=0;
  const original=engine.createShaderProgram;engine.createShaderProgram=function(...args){programs++;return Reflect.apply(original,this,args);};
  const routing={isWebGPU:true,get currentRenderPassId(){return engine.currentRenderPassId;},set currentRenderPassId(v){engine.currentRenderPassId=v;},
    runRenderLoop(next:()=>void){assert.equal(callback,undefined);callback=next;},stopRenderLoop(next:()=>void){if(callback===next)callback=undefined;},
    getHardwareScalingLevel:()=>engine.getHardwareScalingLevel(),setHardwareScalingLevel:(scale:number)=>engine.setHardwareScalingLevel(scale)};
  const Game=make({AuthoredLightPreparation,PlayerFlashlight,Vector3,MeshBuilder,prepareLightVariants,prepareRenderQualities,MANUAL_HARDWARE_SCALING,
    arePreparationEffectsReady:()=>arePreparationEffectsReady(engine),selectLightingPreview:select,applyArtLighting,clampOrbitPitch,performance,
    window:{setTimeout,clearTimeout},document:{hidden:false,addEventListener(){},removeEventListener(){},pointerLockElement:null}});
  const requested=Object.freeze({quality:initialQuality,revision:7,hardwareScaling:1});
  const game:any=Object.assign(new Game(),{engine:routing,scene,camera,sun,ambient,lights,lamps:new StandardMaterial("lamp fixture",scene),clouds:[],
    car,parkedCar:parked,vehicleLighting:beam,flashlight:torch,cinematic,stableLights:stable,gltfLightBudget:budget,
    actor,localId:"local",avatars:new Map([["local",rig]]),quality:initialQuality,adaptive:{state:requested},profile:Object.freeze({preset:0}),weather:Object.freeze({cloud:.99,rain:0,wind:0}),
    timeOverride:select("night").instant,flashlightOn:false,disposed:false,rendererFailed:false,firstPerson:false,yaw:preparedView?0:Math.PI,pitch:.28,distance:8,cameraArm:20,vehicleCameraSnap:true,
    sim:{cameraDistance:(from:Vector3,to:Vector3)=>Vector3.Distance(from,to)},
    renderHealth:{snapshot:()=>({errorCount:0,pendingPreparationOperations:0,phase:"preparing"})},compilationProfile:{setStage(value:string){stage=value;}},
    skyWeather:{atmosphere:{material:skyMaterial,update(){},dispose(){}},update:({instant}:{instant:number})=>({sun:sunState(instant),moon:moonState(instant),wind:{x:0,z:0}})},
    updateWorldPresentation(position:typeof pos){assert.equal(position,pos);f.architecture.update(position,game.quality);f.outdoor.update(position.x,position.z,game.quality);for(const mesh of scene.meshes)if(mesh.metadata?.sourcePack!==undefined&&!f.target.includes(mesh))mesh.setEnabled(false);},
    localAvatarPresentation:{update:()=>({visible:true,cameraLight:false,resetAnimation:false})},updateAvatarPresentation(){},
  });
  const drawn=new Set<number>(),contexts=new Map<object,number>(),stageMap=new Map<string,any>(),capturedEffects:any[]=[];
  const stageReferences=new Map<string,Map<string,{effect:any;context:any;defines:string}>>();
  const actualEffect=(name:string)=>f.target.find(m=>m.material?.name===name&&drawn.has(m.uniqueId))?.subMeshes[0]?._getDrawWrapper(camera.renderPassId)?.effect;
  for(const mesh of f.target)mesh.onAfterRenderObservable.add(()=>{if(engine.currentRenderPassId===camera.renderPassId)drawn.add(mesh.uniqueId);});
  const capture=(label:string)=>({label,programs,yaw:game.yaw,quality:game.quality,lights:scene.lights.filter(l=>l.isEnabled()).map(l=>({type:l.getTypeID(),name:l.name,shadow:l.shadowEnabled})),
    imageProcessing:{enabled:scene.imageProcessingConfiguration.isEnabled,post:scene.imageProcessingConfiguration.applyByPostProcess},
    families:f.names.map(name=>{const material:any=scene.materials.find(m=>m.name===name)!;const mesh=f.target.find(m=>m.material===material&&drawn.has(m.uniqueId));const effect=mesh?.subMeshes[0]?._getDrawWrapper(camera.renderPassId)?.effect;
      const context=effect?.getPipelineContext();if(context&&!contexts.has(context))contexts.set(context,contexts.size+1);if(effect&&!capturedEffects.includes(effect))capturedEffects.push(effect);
      return {name,drawn:!!mesh,mesh:mesh?.name,cap:material.maxSimultaneousLights,effectId:effect?.uniqueId,contextId:context?contexts.get(context):null,ready:effect?.isReady(),disposed:effect?.isDisposed,
        defines:effect?.defines,definesSha256:effect?sha(effect.defines):null,attributes:effect?.getAttributesNames(),reflection:!!material.reflectionTexture,reflectionFresnel:!!material.reflectionFresnelParameters,
        diffuse:!!material.diffuseTexture,emissive:!!material.emissiveTexture,
        sphericalDefineValue:(mesh?.subMeshes[0]?._getDrawWrapper(camera.renderPassId)?.defines as any)?.USESPHERICALFROMREFLECTIONMAP,
        sphericalKeyKnown:(mesh?.subMeshes[0]?._getDrawWrapper(camera.renderPassId)?.defines as any)?._keys?.includes("USESPHERICALFROMREFLECTIONMAP")};})});
  const draw=()=>{budget.prepareFrame();stable.update();drawn.clear();engine.beginFrame();scene.render();engine.endFrame();const key=game.quality+"/"+stage;stageMap.set(key,capture(stage));stageReferences.set(key,new Map(f.names.flatMap(name=>{const effect=actualEffect(name);return effect?[[name,{effect,context:effect.getPipelineContext(),defines:effect.defines}] as const]:[]})));};
  const deferred=async()=>{await pause(0);await turn();engine.beginFrame();engine.endFrame();await turn();};
  f.cleanups.push(()=>{game.cancelLightPreparation?.();torch.dispose();beam.dispose();stable.dispose();cinematic.dispose();assert.equal(callback,undefined);contexts.clear();stageReferences.clear();capturedEffects.length=0;});
  game.updateWorldPresentation(pos);game.updateCameraFollow(new Vector3(pos.x,pos.y,pos.z),rig.eyeHeight,1);
  game.updatePreloadVisuals();
  row.preloadImageProcessing={enabled:scene.imageProcessingConfiguration.isEnabled,post:scene.imageProcessingConfiguration.applyByPostProcess};
  const initialCamera={position:camera.position.clone(),rotation:camera.rotation.clone(),fov:camera.fov,minZ:camera.minZ,maxZ:camera.maxZ,pitch:game.pitch};
  const startYaw=game.yaw;const preparation=game.prepareLighting(draw);let complete=false;void preparation.then(()=>{complete=true;},()=>{complete=true;});
  const deadline=performance.now()+35000;
  while(!complete&&performance.now()<deadline){callback?.();await turn();}
  assert.ok(complete,"bounded whole preparation finished");row.preparation=await preparation;row.stages=[...stageMap.values()];
  assert.equal(row.preparation.status,"complete");assert.equal(row.preparation.stages.length,41);assert.deepEqual(row.preparation.qualities.map((x:any)=>x.quality),initialQuality==="low"?["medium","high","low"]:["low","high","medium"]);
  assert.equal(row.stages.length,41);assert.ok(row.stages.every((s:any)=>s.families.every((family:any)=>family.cap===4)));
  assert.ok(row.stages.every((s:any)=>s.families.every((family:any)=>s.quality==="low"&&s.label.startsWith("vehicle-")?(family.drawn&&family.ready):!family.drawn)));
  assert.ok(f.target.every(mesh=>!mesh.alwaysSelectAsActiveMesh),"all scoped flags restored before gameplay");
  assert.equal(game.yaw,startYaw);assert.equal(actor.vehicle,false);assert.equal(car.isEnabled(),false);assert.equal(parked.isEnabled(),true);assert.equal(game.adaptive.state,requested);
  assert.ok(Vector3.Distance(camera.position,initialCamera.position)<1e-9);assert.ok(Vector3.Distance(camera.rotation,initialCamera.rotation)<1e-9);
  assert.equal(camera.fov,initialCamera.fov);assert.equal(camera.minZ,initialCamera.minZ);assert.equal(camera.maxZ,initialCamera.maxZ);assert.equal(game.pitch,initialCamera.pitch);
  row.restored={cameraPosition:camera.position.asArray(),cameraRotation:camera.rotation.asArray(),yaw:game.yaw,pitch:game.pitch,quality:game.quality,car:car.isEnabled(),parked:parked.isEnabled(),actorVehicle:actor.vehicle};
  await deferred();row.afterDeferred=capturedEffects.map(effect=>({id:effect.uniqueId,disposed:effect.isDisposed}));
  assert.ok(capturedEffects.every(effect=>!effect.isDisposed));
  const vehicleReferences=[stageReferences.get("low/vehicle-0")!,stageReferences.get("low/vehicle-1")!];
  game.applyRenderQuality("low",MANUAL_HARDWARE_SCALING.low);
  actor.vehicle=true;car.setEnabled(true);parked.setEnabled(false);game.alignVehicleCamera();game.updateCameraFollow(new Vector3(pos.x,pos.y,pos.z),rig.eyeHeight,1);
  const replayReferences=new Map<number,Map<string,{effect:any;context:any;defines:string}>>();
  for(const [index,count] of [1,0,1,0].entries()) {
    game.updateRenderEnvironment(pos,rig,false,0,0,game.timeOverride,false);
    lights.forEach((light,i)=>{light.setEnabled(i<count);light.intensity=i<count?.7:0;});
    const before=programs;const started=performance.now();
    do {draw();await turn();} while(!f.names.every(name=>f.target.some(m=>m.material?.name===name&&drawn.has(m.uniqueId)))&&performance.now()-started<2500);
    const snapshot=capture("car-"+count);row.replays.push({...snapshot,newPrograms:programs-before});
    assert.ok(snapshot.families.every(family=>family.drawn&&family.ready),"all authored families actually draw");
    for(const family of snapshot.families){assert.match(family.defines!,/^#define MAXLIGHTCOUNT 4$/m);assert.doesNotMatch(family.defines!,/^#define SHADOW/m);}
    assert.equal(programs-before,0,"two vehicle stages must prevent every target replay compilation");
    for(const name of f.names){const effect=actualEffect(name)!;const prior=vehicleReferences[count].get(name);if(prior){assert.equal(effect,prior.effect);assert.equal(effect.getPipelineContext(),prior.context);assert.equal(effect.defines,prior.defines);}}
    replayReferences.set(count,new Map(f.names.map(name=>{const effect=actualEffect(name)!;return[name,{effect,context:effect.getPipelineContext(),defines:effect.defines}];})));
  }
  row.status="complete";
});
