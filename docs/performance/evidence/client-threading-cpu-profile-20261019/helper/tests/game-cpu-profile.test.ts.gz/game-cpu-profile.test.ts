import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import vm from "node:vm";
import ts from "typescript";
import { createCpuSampler, type CpuProfileEntry } from "../client/qa-cpu-profile";

// Execute actual copied Game methods/blocks, replacing scene and browser IO.
// This verifies ownership and sequencing, never browser/GPU performance.
const source = readFileSync(new URL("../client/game.ts", import.meta.url), "utf8");
const tree = ts.createSourceFile("game.ts", source, ts.ScriptTarget.Latest, true);
const declaration = tree.statements.find((node): node is ts.ClassDeclaration =>
  ts.isClassDeclaration(node) && node.name?.text === "Game")!;
function method(name: string) {
  const result = declaration.members.find((node): node is ts.MethodDeclaration =>
    ts.isMethodDeclaration(node) && node.name.getText(tree) === name);
  assert.ok(result, name);
  return result;
}
const frame = method("frame");
const completions: ts.IfStatement[] = [];
function findCompletion(node: ts.Node) {
  if (ts.isIfStatement(node) && node.expression.getText(tree) === "performance.now() - b.start >= 10000")
    completions.push(node);
  ts.forEachChild(node, findCompletion);
}
findCompletion(frame);
assert.equal(completions.length, 1);
const completion = completions[0].thenStatement.getText(tree)
  .replaceAll("import.meta.env.VITE_SOURCE_SNAPSHOT_ID", '"fixture-snapshot"');
const statements = frame.body!.statements;
const clockIndex = statements.findIndex(node => node.getText(tree).startsWith("const frameStarted ="));
assert.ok(clockIndex > 0);
const framePrefix = statements.slice(0, clockIndex).map(node => node.getText(tree)).join("\n");
const frameText = frame.getText(tree);
const drawStart = frameText.indexOf("    this.benchmark?.profile.beginFrame();");
const drawEnd = frameText.indexOf("    const renderEnded = performance.now();", drawStart);
assert.ok(drawStart >= 0 && drawEnd > drawStart);
const drawBlock = frameText.slice(drawStart, drawEnd);
const methodText = ["startBenchmark", "takeBenchmarkCpuStop", "handleRendererFailure", "dispose"]
  .map(name => method(name).getText(tree)).join("\n");
const compile = (code: string, globals: Record<string, unknown>) => vm.runInNewContext(
  ts.transpileModule(code, { compilerOptions: { target: ts.ScriptTarget.ES2022 } }).outputText,
  globals,
);

function fixture(options: { hostname?: string; search?: string; begin?: () => ((reason: string) => void) | undefined } = {}) {
  let now = 0, recording = true;
  const order: string[] = [], captures: { stops: string[] }[] = [];
  const noop = () => {}, disposable = () => ({ dispose: noop });
  class Profile {
    beginFrame() {}
    endFrame() { return {}; }
    dispose() { order.push("profile-dispose"); }
  }
  const globals = {
    URLSearchParams, structuredClone, innerWidth: 2040, innerHeight: 986,
    beginQaCpuProfile: options.begin ?? (() => {
      const capture = { stops: [] as string[] };
      captures.push(capture);
      order.push("cpu-start");
      return (reason: string) => { capture.stops.push(reason); order.push("cpu-stop"); };
    }),
    performance: { now: () => now },
    window: { location: { hostname: options.hostname ?? "127.0.0.1", search: options.search ?? "?profileCpu=1" }, removeEventListener: noop },
    document: { removeEventListener: noop, pointerLockElement: null, exitPointerLock: noop },
    BenchmarkRenderProfile: Profile, BENCHMARK_RENDER_CPU_SCOPE: {},
    sessionDiagnostics: { get isRecording() { return recording; }, event: noop },
    snapshotBenchmarkDiagnostics: (value: unknown) => value,
    getRendererInfo: () => ({}), PARKING_SLOTS: [],
    captureModelReview: () => { order.push("metrics"); return {}; },
    captureRenderCostInventory: () => ({}),
  };
  const Subject = compile(`class Subject { ${methodText} }; Subject`, globals);
  const position = { x: 0, y: 0, z: 0 };
  const game: any = Object.assign(new Subject(), {
    ready: true, disposed: false, rendererFailed: false,
    engine: { isWebGPU: true, getRenderWidth: () => 2040, getRenderHeight: () => 986, stopRenderLoop: noop, dispose: noop },
    scene: { getActiveIndices: () => 3, render: noop, dispose: noop },
    camera: { globalPosition: position, fov: 1, minZ: 0.1, maxZ: 100, getViewMatrix: () => ({ m: [] }), getProjectionMatrix: () => ({ m: [] }) },
    compilationProfile: { snapshot: () => ({}) },
    renderHealth: { rendererId: 1, snapshot: () => ({ valid: true, generation: 1 }), dispose: noop },
    startupAbort: new AbortController(), avatars: new Map(), actor: { position, vehicle: false },
    yaw: 0, pitch: 0, quality: "medium", adaptive: { state: { quality: "medium" } },
    renderErrorCount: 0, assetLoadErrorCount: 0, canvas: { removeEventListener: noop },
    disposeStartupAssets: noop, resetDiagnosticContext: noop, blur: noop, notice: noop,
    stableLights: { ...disposable(), update: noop }, gltfLightBudget: { ...disposable(), prepareFrame: noop },
    enabledMeshCandidates: disposable(), labels: disposable(), contactShadows: disposable(),
    instrumentation: { ...disposable(), drawCallsCounter: { current: 0 } },
    engineInstrumentation: disposable(), skyWeather: disposable(), avatarPool: disposable(),
  });
  const beginFrame = compile(`(function() { ${framePrefix} })`, globals);
  const draw = compile(`(function() { ${drawBlock} })`, globals);
  const complete = compile(`(function() { const b = this.benchmark, pos = this.actor.position, mainPassTiming = { ms: null, scope: "main-render-pass-only" }; ${completion} })`, globals);
  return {
    game, captures, order,
    record(value: boolean) { recording = value; },
    beginFrame: () => beginFrame.call(game),
    draw: () => draw.call(game),
    finish() { now = 10000; game.benchmark.frames = [16]; complete.call(game); },
  };
}

test("actual Game requires explicit unique profileCpu=1, loopback, recording and WebGPU", () => {
  for (const search of ["", "?profileCpu", "?profileCpu=0", "?profileCpu=true", "?profileCpu=1&profileCpu=1", "?profileCpu=1&profileCpu=0", "?profileCPU=1"]) {
    const x = fixture({ search });
    assert.equal(x.game.startBenchmark(), true);
    assert.equal(x.captures.length, 0, search);
  }
  for (const hostname of ["example.test", "127.0.0.1.example.test", "localhost.example.test"]) {
    const x = fixture({ hostname }); x.game.startBenchmark(); assert.equal(x.captures.length, 0, hostname);
  }
  for (const hostname of ["localhost", "LOCALHOST", "127.0.0.1", "[::1]", "::1"]) {
    const x = fixture({ hostname }); x.game.startBenchmark(); assert.equal(x.captures.length, 1, hostname); x.game.dispose();
  }
  const x = fixture();
  x.record(false); x.game.startBenchmark();
  x.record(true); x.game.engine.isWebGPU = false; x.game.startBenchmark();
  assert.equal(x.captures.length, 0);
  x.game.engine.isWebGPU = true;
  for (const key of ["disposed", "rendererFailed"]) {
    x.game[key] = true; assert.equal(x.game.startBenchmark(), false); x.game[key] = false;
  }
  x.game.ready = false; assert.equal(x.game.startBenchmark(), false); assert.equal(x.captures.length, 0);
});

test("actual completion stops after all metrics and before callback; callback new benchmark owns its closure", () => {
  const x = fixture(); x.game.startBenchmark(); const firstState = x.game.benchmark;
  x.game.onBenchmark = (value: any) => {
    x.order.push("callback");
    assert.equal(value.frames, 1);
    assert.deepEqual(x.captures[0].stops, ["benchmark-end"]);
    assert.equal(x.game.benchmark, undefined);
    x.game.startBenchmark();
  };
  x.finish();
  assert.ok(x.order.indexOf("metrics") < x.order.indexOf("cpu-stop"));
  assert.ok(x.order.indexOf("cpu-stop") < x.order.indexOf("callback"));
  assert.equal(x.captures.length, 2);
  assert.equal(x.game.takeBenchmarkCpuStop(firstState), undefined);
  assert.deepEqual(x.captures[1].stops, []);
  x.game.dispose(); assert.deepEqual(x.captures[1].stops, ["dispose"]);
});

test("actual restart transfers old owner once and stale state cannot stop new capture", () => {
  const x = fixture(); x.game.startBenchmark(); const firstState = x.game.benchmark;
  x.game.startBenchmark();
  assert.deepEqual(x.captures[0].stops, ["restart"]);
  assert.equal(x.game.takeBenchmarkCpuStop(firstState), undefined);
  assert.deepEqual(x.captures[1].stops, []);
  const owner = x.game.takeBenchmarkCpuStop(x.game.benchmark);
  assert.equal(typeof owner, "function"); assert.equal(x.game.takeBenchmarkCpuStop(x.game.benchmark), undefined);
  owner("manual-transfer"); x.game.dispose(); assert.deepEqual(x.captures[1].stops, ["manual-transfer"]);
});

test("actual start metric failure preserves original error and stops partial owner", () => {
  const x = fixture(), error = new Error("original start metric failure");
  x.game.renderHealth.snapshot = () => { throw error; };
  assert.throws(() => x.game.startBenchmark(), e => e === error);
  assert.deepEqual(x.captures[0].stops, ["benchmark-start-error"]);
  x.game.handleRendererFailure("cleanup"); assert.equal(x.captures[0].stops.length, 1);
});

for (const stage of ["getActiveIndices", "profileDispose", "healthSnapshot", "weatherClone"] as const)
  test(`actual completion ${stage} failure still stops detached owner once and preserves original error`, () => {
    const x = fixture(), error = new Error("original completion failure"); x.game.startBenchmark();
    let callbacks = 0; x.game.onBenchmark = () => { callbacks++; };
    if (stage === "getActiveIndices") x.game.scene.getActiveIndices = () => { throw error; };
    if (stage === "profileDispose") x.game.benchmark.profile.dispose = () => { throw error; };
    if (stage === "healthSnapshot") x.game.renderHealth.snapshot = () => { throw error; };
    if (stage === "weatherClone") x.game.weather = { get temperature() { throw error; } };
    assert.throws(() => x.finish(), e => e === error);
    assert.equal(x.game.benchmark, undefined);
    assert.deepEqual(x.captures[0].stops, ["benchmark-completion-error"]);
    assert.equal(callbacks, 0);
    x.game.handleRendererFailure("cleanup"); x.game.dispose(); assert.equal(x.captures[0].stops.length, 1);
  });

test("callback failure occurs after CPU stop and cannot stop a new benchmark", () => {
  const x = fixture(), error = new Error("callback failure"); x.game.startBenchmark();
  x.game.onBenchmark = () => { x.game.startBenchmark(); throw error; };
  assert.throws(() => x.finish(), e => e === error);
  assert.deepEqual(x.captures[0].stops, ["benchmark-end"]);
  assert.deepEqual(x.captures[1].stops, []);
  x.game.dispose(); assert.deepEqual(x.captures[1].stops, ["dispose"]);
});

test("actual frame prefix stops once when recording ends and does not silently restart", () => {
  const x = fixture(); x.game.startBenchmark(); x.beginFrame(); assert.deepEqual(x.captures[0].stops, []);
  x.record(false); x.beginFrame(); x.beginFrame();
  assert.deepEqual(x.captures[0].stops, ["recording-ended"]);
  x.record(true); x.beginFrame(); assert.equal(x.captures.length, 1);
  x.finish(); assert.equal(x.captures[0].stops.length, 1);
});

test("actual draw error closes CPU owner while preserving renderer exception", () => {
  const x = fixture(), error = new Error("original render error"); x.game.startBenchmark();
  x.game.scene.render = () => { throw error; };
  assert.throws(() => x.draw(), e => e === error);
  assert.deepEqual(x.captures[0].stops, ["render-error"]);
  x.game.handleRendererFailure("cleanup"); x.game.dispose(); assert.equal(x.captures[0].stops.length, 1);
});

test("actual renderer failure stops detached capture even when later cleanup fails", () => {
  const x = fixture(); x.game.startBenchmark(); const state = x.game.benchmark;
  x.game.startupAbort = { abort() { throw new Error("cleanup"); } };
  assert.doesNotThrow(() => x.game.handleRendererFailure("fault"));
  assert.equal(x.game.benchmark, undefined); assert.equal(x.game.takeBenchmarkCpuStop(state), undefined);
  assert.deepEqual(x.captures[0].stops, ["renderer-failure"]);
  x.game.handleRendererFailure("repeat"); assert.equal(x.captures[0].stops.length, 1);
});

test("actual dispose stops before fallible cleanup and repeat dispose is harmless", () => {
  const x = fixture(), error = new Error("abort failure"); x.game.startBenchmark();
  x.game.startupAbort = { abort() { throw error; } };
  assert.throws(() => x.game.dispose(), e => e === error);
  assert.deepEqual(x.captures[0].stops, ["dispose"]);
  assert.doesNotThrow(() => x.game.dispose()); assert.equal(x.captures[0].stops.length, 1);
});

test("real sampler stays busy through asynchronous stop and publishes after actual completion callback", async () => {
  let resolve!: (trace: unknown) => void, created = 0, stopped = 0;
  const pending = new Promise<unknown>(yes => { resolve = yes; }), exports: CpuProfileEntry[] = [];
  const sampler = createCpuSampler({
    create() { created++; return { sampleInterval: 16, stop() { stopped++; return pending; }, addEventListener() {}, removeEventListener() {} }; },
    now: () => 100, timeOrigin: () => 1_700_000_000_000,
    publish: entry => { exports.push(entry); },
  });
  const x = fixture({ begin: sampler.begin }); x.game.startBenchmark();
  x.game.onBenchmark = () => { assert.equal(exports.length, 0); x.game.startBenchmark(); };
  x.finish(); assert.equal(created, 1); assert.equal(stopped, 1); assert.equal(x.game.benchmark.cpuStop, undefined);
  resolve({ samples: [] }); await Promise.resolve(); await Promise.resolve();
  assert.equal(exports.length, 1); assert.equal(exports[0].reason, "benchmark-end");
  x.game.startBenchmark(); assert.equal(created, 2); x.game.dispose(); assert.equal(stopped, 2);
  await Promise.resolve(); await Promise.resolve(); assert.equal(exports.length, 2);
});
