import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {NullEngine} from '@babylonjs/core/Engines/nullEngine.js';
import {Scene} from '@babylonjs/core/scene.js';
import {FreeCamera} from '@babylonjs/core/Cameras/freeCamera.js';
import {Vector3} from '@babylonjs/core/Maths/math.vector.js';
import {MeshBuilder} from '@babylonjs/core/Meshes/meshBuilder.js';
import {StandardMaterial} from '@babylonjs/core/Materials/standardMaterial.js';
import {ObjectRenderer} from '@babylonjs/core/Rendering/objectRenderer.js';
import {PBRMaterial} from '@babylonjs/core/Materials/PBR/pbrMaterial.js';
import {PBRBaseMaterial} from '@babylonjs/core/Materials/PBR/pbrBaseMaterial.js';
import {HemisphericLight} from '@babylonjs/core/Lights/hemisphericLight.js';
import {ThinEngine} from '@babylonjs/core/Engines/thinEngine.pure.js';
import {WebGPUEngine} from '@babylonjs/core/Engines/webgpuEngine.pure.js';
import {EffectCallProfile,EFFECT_IDS} from './entry-effect-cost-core.mjs';
import ts from 'typescript';
import {webcrypto} from 'node:crypto';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import * as probe from './startup-stage-effects.mjs';
import {transformStartupEffectSource as transformStartupSource,STARTUP_ROUTINE_TARGETS,parseBuildOptions,buildDigest,browserBuildIdentity,helperIdentity,sha256} from './common.mjs';
import {prepareLightVariants} from '../../../../../client/light-preparation.ts';
import {validateReceipt} from './receipt.mjs';
import {verifyBuildContract} from './harness.mjs';

const source=await readFile(new URL('../../../../../client/light-preparation.ts',import.meta.url),'utf8');
const gameSource=await readFile(new URL('../../../../../client/game.ts',import.meta.url),'utf8');
function transformed(){let js=ts.transpileModule(transformStartupSource(source,'light',STARTUP_ROUTINE_TARGETS[0]),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022}}).outputText;
  js=js.replace(/^import .* from "virtual:webgpu-completion-startup-effects";\r?\n/m,'').replace('export function prepareLightVariants','function prepareLightVariants');
  return new Function(...Object.keys(probe),js+'\nreturn prepareLightVariants;')(...Object.values(probe));}
const actual=transformed();
const flush=async()=>{for(let i=0;i<12;i++)await Promise.resolve();};
function fixture(target='first-medium-vehicle-0'){
  const engine=new NullEngine(),scene=new Scene(engine);new FreeCamera('CPU source fixture',new Vector3(0,0,-8),scene);
  const mesh=MeshBuilder.CreateBox('CPU fixture box',{},scene);mesh.material=new StandardMaterial('CPU fixture material',scene);
  const health={rendererId:1,generation:1,errorCount:0,phase:'preparing'},startupAbort=new AbortController();
  const game={engine,scene,renderHealth:health,startupAbort,quality:'medium',ready:false,disposed:false};
  let cpuClock=0;const owner=probe.createStartupStageEffects(game,{target,profileNow:()=>cpuClock+=.01});
  return{game,engine,scene,mesh,owner,dispose(){owner?.dispose();scene.dispose();engine.dispose();}};
}
async function run(f,operation=actual,{throwRender,renderReturn,timeoutMs=30000,quality='medium'}={}){
  f.game.quality=quality;let now=1000,nowReads=0,tick,disposal,done=false,result,renders=0;
  const options={apply(){},restore(){},meshes:()=>[],beforeChecks(){},check:()=>true,effectsReady:()=>true,
    render(){renders++;if(throwRender)throw throwRender.value;f.scene.render();return renderReturn;},
    run(callback){tick=callback;},stop(callback){assert.equal(callback,tick);},onDispose(callback){disposal=callback;return()=>{disposal=undefined;};},isDisposed:()=>false,
    revision:()=>[],now:()=>{nowReads++;return now;},setTimer:()=>1,clearTimer(){},timeoutMs,includeVehicleVariants:true,includeDayPointVariants:true};
  assert.equal(probe.registerStartupOptions(f.game,options),options);
  const promise=operation(options);assert.ok(promise instanceof Promise);promise.then(value=>{result=value;done=true;});
  for(let i=0;i<1000&&!done;i++){now+=10;tick();await flush();}
  assert.ok(done,'finite original light state machine completed');assert.equal(disposal,undefined);
  return{result,options,renders,nowReads,promise};
}
test('defaultoff has no owner/source transform, proxy reads, hooks or new options identity',()=>{
  const hostile=new Proxy({},{get(){throw Error('defaultoff read');},getOwnPropertyDescriptor(){throw Error('defaultoff descriptor');}});
  assert.equal(probe.createStartupStageEffects(hostile),undefined);assert.equal(transformStartupSource(source,'light'),source);assert.equal(transformStartupSource(gameSource,'game'),gameSource);
  const options={};assert.equal(probe.registerStartupOptions(hostile,options),options);
});
test('new closed flag is mutually exclusive in both CLI orders, canonical metadata and receipt identity',()=>{
  const target=STARTUP_ROUTINE_TARGETS[0];
  for(const args of[['--startup-routines',target,'--startup-effect-routines',target],['--startup-effect-routines',target,'--startup-routines',target]])assert.throws(()=>parseBuildOptions(args),/mutually exclusive/);
  const seed={sourceSnapshotId:'s',helperSha256:'h',label:'l',loading:'original',transforms:{startupRoutines:{target},startupEffectRoutines:{target}},clock:null,weather:null,startupLatency:false,shaderAttribution:false,routineCost:false,bufferLifecycle:false,lifecycleControls:false,dependencies:{}};
  assert.throws(()=>buildDigest(seed),/mutually exclusive/);
  assert.throws(()=>validateReceipt({schemaVersion:1,buildId:'b',sourceSnapshotId:'s',helperSha256:'h',attemptId:'8e9e7e15-6011-438d-96a2-53be43f17792',kind:'startup',mode:'diagnostic',lifecycleControls:false},
    {buildId:'b',sourceSnapshotId:'s',helperSha256:'h',lifecycleControls:false,startupRoutines:target,startupEffectRoutines:target}),/mutually exclusive/);
});
test('V20 old runtime modules stay exact and ten-target core is the immutable V19 donor',async()=>{
  for(const name of['startup-stage-routines.mjs','routine-cost-core.mjs','routine-cost.mjs','entry-routine-cost.mjs','entry-render-cost.mjs'])assert.deepEqual(await readFile(new URL(name,import.meta.url)),await readFile(new URL('../v20/'+name,import.meta.url)));
  assert.deepEqual(await readFile(new URL('./entry-effect-cost-core.mjs',import.meta.url)),await readFile(new URL('../../../entry-effect-cost/helper/v19/entry-effect-cost-core.mjs',import.meta.url)));
});
test('one ten-target stack subtracts PBR prepare/engine children and the direct Standard-to-engine child',()=>{
  for(const parent of[4,5]){let now=0;const targets=EFFECT_IDS.map(id=>{const target={run(){}};return{id,target,key:'run',expected:target.run};});
    targets[9].target.run=()=>{now+=3;return {};};targets[9].expected=targets[9].target.run;
    targets[8].target.run=()=>{now++;targets[9].target.run();now++;return null;};targets[8].expected=targets[8].target.run;
    targets[parent].target.run=()=>{now++;targets[parent===4?8:9].target.run();now++;return true;};targets[parent].expected=targets[parent].target.run;
    const core=new EffectCallProfile(targets,{now:()=>now,phase:()=> 'main'});core.beginFrame(0);assert.equal(targets[parent].target.run(),true);const frame=core.endFrame();core.dispose();
    const row=index=>frame.rows.find(r=>r.id===EFFECT_IDS[index]&&r.phase==='main');assert.equal(row(parent).selfSelectedMs,2);assert.equal(row(9).inclusiveMs,3);assert.equal(row(9).selfSelectedMs,3);
    if(parent===4){assert.equal(row(8).inclusiveMs,5);assert.equal(row(8).selfSelectedMs,2);assert.equal(row(8).nullReturns,1);}else assert.equal(row(8).calls,0);
    assert.equal(frame.errors,0);
  }
});
for(const MaterialClass of[PBRMaterial,StandardMaterial])test('actual native '+MaterialClass.name+' dirty/cache reuse, six-frame stage and inherited engine API',async()=>{
  const f=fixture();try{f.scene.texturesEnabled=false;f.mesh.material.dispose();const material=new MaterialClass('native startup receiver',f.scene);f.mesh.material=material;
    const light=new HemisphericLight('native startup key',Vector3.Up(),f.scene);
    for(let i=0;i<25;i++){f.scene.render();await new Promise(setImmediate);if(material.isReadyForSubMesh(f.mesh,f.mesh.subMeshes[0],false))break;}
    assert.equal(material.isReadyForSubMesh(f.mesh,f.mesh.subMeshes[0],false),true);const previous=f.mesh.subMeshes[0].effect;
    light.setEnabled(false);light.setEnabled(true);const options={};probe.registerStartupOptions(f.game,options);probe.startupPassStarted(options,1);probe.startupStageStarted(options,0,'vehicle-0',2);
    for(let i=0;i<6;i++){const token=probe.startupRenderBegin(options,3+i*2);assert.ok(token);f.scene.render();probe.startupRenderEnd(token,4+i*2,true);await new Promise(setImmediate);}
    probe.startupStageSaved(options,0,20,false);probe.startupPassFinished(options,21,'complete');f.owner.dispose('startup-resolved');const p=f.owner.snapshot();probe.validateStartupStageEffects(p,STARTUP_ROUTINE_TARGETS[0]);
    const rows=p.capture.frames.flatMap(frame=>frame.rows),calls=id=>rows.filter(row=>row.id===id).reduce((n,row)=>n+row.calls,0);
    assert.equal(p.complete,true);assert.equal(p.capture.frames.length,6);assert.equal(p.engineOrigin,'thinengine-inherited');assert.equal(p.installedRoutineHooks,10);assert.ok(calls(EFFECT_IDS[9])>0);
    assert.equal(f.mesh.subMeshes[0].effect,previous);assert.equal(f.engine.createEffect,ThinEngine.prototype.createEffect);assert.equal(Object.hasOwn(f.engine,'createEffect'),false);assert.equal(Object.hasOwn(f.scene,'render'),false);
    if(MaterialClass===PBRMaterial){assert.ok(calls(EFFECT_IDS[8])>0);assert.ok(rows.filter(row=>row.id===EFFECT_IDS[8]).some(row=>row.nullReturns>0));}else{assert.equal(calls(EFFECT_IDS[4]),0);assert.equal(calls(EFFECT_IDS[8]),0);assert.ok(calls(EFFECT_IDS[5])>0);}
  }finally{f.dispose();}
});
test('actual WebGPU own prototype origin installs only on its concrete engine and retires without device work',()=>{
  const f=fixture(),native=f.engine,host=Object.create(WebGPUEngine.prototype);f.scene._engine=host;f.game.engine=host;f.owner.dispose();
  const owner=probe.createStartupStageEffects(f.game,{target:STARTUP_ROUTINE_TARGETS[0]});try{const options={};probe.registerStartupOptions(f.game,options);probe.startupPassStarted(options,1);probe.startupStageStarted(options,0,'vehicle-0',2);assert.ok(probe.startupRenderBegin(options,3));
    assert.ok(Object.hasOwn(host,'createEffect'));owner.dispose('owner-stopped');const p=owner.snapshot();assert.equal(p.engineOrigin,'webgpu-own');assert.equal(p.complete,false);assert.equal(p.remainingRoutineHooks,0);assert.equal(Object.hasOwn(host,'createEffect'),false);probe.validateStartupStageEffects(p,STARTUP_ROUTINE_TARGETS[0]);
  }finally{owner.dispose();f.scene._engine=native;f.game.engine=native;f.dispose();}
});
test('foreign engine descriptor is preserved and prevents instrumentation before prototype writes',()=>{
  const f=fixture(),native=PBRBaseMaterial.prototype._prepareEffect,foreign=()=>{};try{f.engine.createEffect=foreign;const options={};probe.registerStartupOptions(f.game,options);probe.startupPassStarted(options,1);probe.startupStageStarted(options,0,'vehicle-0',2);
    assert.equal(probe.startupRenderBegin(options,3),null);assert.equal(PBRBaseMaterial.prototype._prepareEffect,native);assert.equal(f.engine.createEffect,foreign);f.owner.dispose();const p=f.owner.snapshot();assert.ok(p.errors>0);assert.equal(p.remainingRoutineHooks,0);probe.validateStartupStageEffects(p,STARTUP_ROUTINE_TARGETS[0]);
  }finally{delete f.engine.createEffect;f.dispose();}
});
test('native engine descriptor drift during selected stage stops capture and never clobbers the replacement',()=>{
  const f=fixture(),foreign=function(){return Reflect.apply(ThinEngine.prototype.createEffect,this,arguments);};try{const options={};probe.registerStartupOptions(f.game,options);probe.startupPassStarted(options,1);probe.startupStageStarted(options,0,'vehicle-0',2);
    const token=probe.startupRenderBegin(options,3);f.scene.render();probe.startupRenderEnd(token,4,true);f.engine.createEffect=foreign;assert.equal(probe.startupRenderBegin(options,5),null);assert.equal(f.engine.createEffect,foreign);
    probe.startupStageSaved(options,0,6,false);probe.startupPassFinished(options,7,'complete');f.owner.dispose('startup-resolved');const p=f.owner.snapshot();assert.equal(p.complete,false);assert.ok(p.restoreConflicts>0);probe.validateStartupStageEffects(p,STARTUP_ROUTINE_TARGETS[0]);
  }finally{delete f.engine.createEffect;f.dispose();}
});
test('invalid native frame ID remains explicit partial without adding or repairing native work',()=>{
  const f=fixture();try{const options={};probe.registerStartupOptions(f.game,options);probe.startupPassStarted(options,1);probe.startupStageStarted(options,0,'vehicle-0',2);const token=probe.startupRenderBegin(options,3);
    f.scene.onAfterRenderObservable.addOnce(()=>{f.scene._frameId=NaN;});f.scene.render();probe.startupRenderEnd(token,4,true);f.owner.dispose();const p=f.owner.snapshot();assert.equal(p.capture.frames[0].nativeFrameIdAfter,null);assert.equal(p.complete,false);probe.validateStartupStageEffects(p,STARTUP_ROUTINE_TARGETS[0]);
  }finally{f.dispose();}
});
test('new schema rejects origin/target/null/row/call tamper and inherited serialization accessors',async()=>{
  const f=fixture();try{await run(f);f.owner.dispose('startup-resolved');const p=f.owner.snapshot();for(const change of[q=>q.engineOrigin=null,q=>q.targets.pop(),q=>q.installedRoutineHooks=0,q=>q.capture.frames[0].rows[0].nullReturns=-1,q=>q.capture.frames[0].rows[0].nullReturns=100001,q=>{for(const row of q.capture.frames[0].rows)row.calls=100000;},q=>q.effectScope.engine='cache hit',q=>q.targets[8]='arbitrary']){const q=structuredClone(p);change(q);assert.throws(()=>probe.validateStartupStageEffects(q,STARTUP_ROUTINE_TARGETS[0]));}
    let reads=0;const inherited=Object.create({get toJSON(){reads++;throw Error('inherited serialization getter');}},Object.getOwnPropertyDescriptors(p));assert.throws(()=>probe.validateStartupStageEffects(inherited,STARTUP_ROUTINE_TARGETS[0]));assert.equal(reads,0);
  }finally{f.dispose();}
});
test('disposed owner and retained engine/prototype wrappers release Game, Scene and engine',async()=>{
  assert.equal(typeof global.gc,'function','targeted command must enable the explicit GC check');
  let retained;
  function allocate(){const f=fixture(),options={};probe.registerStartupOptions(f.game,options);probe.startupPassStarted(options,1);probe.startupStageStarted(options,0,'vehicle-0',2);const token=probe.startupRenderBegin(options,3);
    retained={owner:f.owner,engineWrapper:f.engine.createEffect,prototypeWrapper:PBRBaseMaterial.prototype._prepareEffect,token,game:new WeakRef(f.game),scene:new WeakRef(f.scene),engine:new WeakRef(f.engine)};
    f.dispose();return retained;}
  allocate();await new Promise(setImmediate);
  for(let i=0;i<24;i++){global.gc();await new Promise(resolve=>setTimeout(resolve,0));}
  assert.equal(retained.game.deref()===undefined,true,'retired Game collected');assert.equal(retained.scene.deref()===undefined,true,'retired Scene collected');assert.equal(retained.engine.deref()===undefined,true,'retired engine collected');assert.equal(retained.owner.snapshot().remainingRoutineHooks,0);
  probe.startupRenderEnd(retained.token,4,true);assert.equal(retained.token.state,null);
});
test('borrowed core depth/call/clock caps preserve every original call and original falsy throws',()=>{
  const make=()=>EFFECT_IDS.map(id=>{const target={run(){}};return{id,target,key:'run',expected:target.run};});
  const deep=make();let originals=0;deep[8].target.run=function(depth){originals++;if(depth)this.run(depth-1);return 7;};deep[8].expected=deep[8].target.run;
  const core=new EffectCallProfile(deep,{now:()=>0});core.beginFrame(0);assert.equal(deep[8].target.run(40),7);const f=core.endFrame();core.dispose();assert.equal(originals,41);assert.ok(f.depthSkipped>0);
  const many=make();originals=0;many[5].target.run=()=>++originals;many[5].expected=many[5].target.run;const capped=new EffectCallProfile(many,{now:()=>0});capped.beginFrame(0);
  for(let i=0;i<100001;i++)many[5].target.run();const g=capped.endFrame();capped.dispose();assert.equal(originals,100001);assert.equal(g.callsSkipped,1);
  for(const thrown of[undefined,null,false,0,'']){const ts=make();let calls=0;ts[8].target.run=()=>{calls++;throw thrown;};ts[8].expected=ts[8].target.run;const p=new EffectCallProfile(ts,{now(){throw 0;}});p.beginFrame(0);assert.throws(()=>ts[8].target.run(),error=>error===thrown);const h=p.endFrame();p.dispose();assert.equal(calls,1);assert.ok(h.errors>0);}
});
test('phase and renderer registration overflow remain explicit partial and detach every subscription',()=>{
  const f=fixture(),renderers=[];try{for(let i=0;i<65;i++)renderers.push(new ObjectRenderer('bounded CPU renderer'+i,f.scene));const options={};probe.registerStartupOptions(f.game,options);probe.startupPassStarted(options,1);probe.startupStageStarted(options,0,'vehicle-0',2);
    const token=probe.startupRenderBegin(options,3);assert.ok(token);for(let i=0;i<129;i++)f.scene.onBeforeDrawPhaseObservable.notifyObservers(f.scene);
    f.scene.render();probe.startupRenderEnd(token,4,true);f.owner.dispose();const p=f.owner.snapshot();assert.equal(p.complete,false);assert.ok(p.errors>0);assert.equal(p.remainingRoutineHooks,0);
    for(const renderer of renderers)assert.equal(renderer.onInitRenderingObservable.observers.filter(observer=>!observer._willBeUnregistered).length,0);probe.validateStartupStageEffects(p,STARTUP_ROUTINE_TARGETS[0]);
  }finally{for(const renderer of renderers)renderer.dispose();f.dispose();}
});
test('actual harness transform function seals separate off/old8/new10 source bytes without layering',async()=>{
  const text=await readFile(new URL('./harness.mjs',import.meta.url),'utf8'),tree=ts.createSourceFile('harness.mjs',text,ts.ScriptTarget.Latest,true),fn=tree.statements.find(node=>ts.isFunctionDeclaration(node)&&node.name?.text==='transformedInputs');
  const common=await import('./common.mjs'),fnSource=fn.getText(tree);
  const transform=new Function('transformUI','transformLoading','transformStartupSource','transformStartupEffectSource','sha256',fnSource+';return transformedInputs;')(common.transformUI,common.transformLoading,common.transformStartupSource,common.transformStartupEffectSource,sha256);
  const ui=await readFile(new URL('../../../../../client/ui.tsx',import.meta.url),'utf8'),css=await readFile(new URL('../../../../../client/style.css',import.meta.url),'utf8');
  for(const[oldTarget,newTarget]of[[null,null],[STARTUP_ROUTINE_TARGETS[0],null],[null,STARTUP_ROUTINE_TARGETS[0]]]){const out=transform(ui,css,'original',gameSource,source,oldTarget,newTarget);
    assert.equal(out.transforms.startupRoutines.target,oldTarget);assert.equal(out.transforms.startupEffectRoutines.target,newTarget);
    const expected=oldTarget?'startup-routines':newTarget?'startup-effects':null;for(const[kind,result,original]of[['game',out.game,gameSource],['light',out.light,source]]){
      if(expected){assert.equal(result.split('virtual:webgpu-completion-'+expected).length,2);assert.equal(result.includes('virtual:webgpu-completion-'+(oldTarget?'startup-effects':'startup-routines')),false);}else assert.equal(result,original);
      assert.equal(sha256(result),out.transforms[newTarget?'startupEffectRoutines':'startupRoutines'][kind].after);
    }
  }
  assert.match(text,/'@babylonjs\/core\/Engines\/thinEngine\.pure\.js'/);assert.match(text,/if\(id==='virtual:webgpu-completion-startup-effects'\)/);
});
test('late engine installation failure rolls back all nine prior targets and preserves the original falsy error',()=>{
  const f=fixture(),nativeEngine=f.engine,nativePrepare=PBRBaseMaterial.prototype._prepareEffect,nativeScene=f.scene.getActiveMeshCandidates;f.owner.dispose();
  const proxy=new Proxy(nativeEngine,{defineProperty(_target,key){if(key==='createEffect')throw false;throw Error('unexpected mutation');}});f.game.engine=proxy;f.scene._engine=proxy;
  const owner=probe.createStartupStageEffects(f.game,{target:STARTUP_ROUTINE_TARGETS[0]});try{const options={};probe.registerStartupOptions(f.game,options);probe.startupPassStarted(options,1);probe.startupStageStarted(options,0,'vehicle-0',2);
    assert.equal(probe.startupRenderBegin(options,3),null);assert.equal(PBRBaseMaterial.prototype._prepareEffect,nativePrepare);assert.equal(f.scene.getActiveMeshCandidates,nativeScene);assert.equal(Object.hasOwn(nativeEngine,'createEffect'),false);
    owner.dispose();const p=owner.snapshot();assert.equal(p.remainingRoutineHooks,0);assert.equal(p.installedRoutineHooks,0);assert.ok(p.errors>0);probe.validateStartupStageEffects(p,STARTUP_ROUTINE_TARGETS[0]);
  }finally{owner.dispose();f.game.engine=nativeEngine;f.scene._engine=nativeEngine;f.dispose();}
});
test('between-render passthrough performs no diagnostic clock reads; retired wrappers only call the original',()=>{
  const f=fixture();f.owner.dispose();let reads=0;const owner=probe.createStartupStageEffects(f.game,{target:STARTUP_ROUTINE_TARGETS[0],profileNow:()=>++reads});
  try{const options={};probe.registerStartupOptions(f.game,options);probe.startupPassStarted(options,1);probe.startupStageStarted(options,0,'vehicle-0',2);const token=probe.startupRenderBegin(options,3);f.scene.render();probe.startupRenderEnd(token,4,true);
    const measured=reads;f.scene.render();assert.equal(reads,measured);const stale=f.engine.createEffect;owner.dispose();const before=reads;
    const effect={_refCount:1,isReady:()=>true},host={_compiledEffects:{'v+f@':effect},_getGlobalDefines:()=>''};assert.equal(Reflect.apply(stale,host,[{vertex:'v',fragment:'f'},{attributes:[],defines:''},host]),effect);assert.equal(effect._refCount,2);assert.equal(reads,before);
  }finally{owner.dispose();f.dispose();}
});
test('actual Game/light exact transforms parse, preserve original call points and reject reinjection/drift',()=>{
  for(const kind of['game','light']){const raw=kind==='game'?gameSource:source,out=transformStartupSource(raw,kind,STARTUP_ROUTINE_TARGETS[0]);
    assert.equal(ts.createSourceFile(kind+'.ts',out,ts.ScriptTarget.Latest,true).parseDiagnostics.length,0);assert.throws(()=>transformStartupSource(out,kind,STARTUP_ROUTINE_TARGETS[0]));}
  assert.throws(()=>transformStartupSource(source.replace('stageStarted = options.now();','stageStarted = Date.now();'),'light',STARTUP_ROUTINE_TARGETS[0]));
  assert.throws(()=>transformStartupSource(gameSource.replace('return prepareLightVariants({','return foreignVariants({'),'game',STARTUP_ROUTINE_TARGETS[0]));
  assert.equal((transformStartupSource(source,'light',STARTUP_ROUTINE_TARGETS[0]).match(/new Promise\(/g)||[]).length,(source.match(/new Promise\(/g)||[]).length);
});
test('canonical closed target lives in sealed transforms and explicit parser cannot be query/unknown/duplicate',()=>{
  assert.deepEqual(STARTUP_ROUTINE_TARGETS,probe.STARTUP_TARGETS);
  assert.equal(parseBuildOptions([]).startupEffectRoutines,null);
  for(const target of STARTUP_ROUTINE_TARGETS)assert.equal(parseBuildOptions(['--startup-effect-routines',target]).startupEffectRoutines,target);
  for(const args of[['--startup-effect-routines'],['--startup-effect-routines','unknown'],['--startup-effect-routines',STARTUP_ROUTINE_TARGETS[0],'--startup-effect-routines',STARTUP_ROUTINE_TARGETS[0]]])assert.throws(()=>parseBuildOptions(args));
  const seed={sourceSnapshotId:'source',helperSha256:'helper',label:'label',loading:'original',transforms:{startupEffectRoutines:{target:null}},clock:null,weather:null,startupLatency:false,shaderAttribution:false,routineCost:false,bufferLifecycle:false,lifecycleControls:false,dependencies:{}};
  const changed={...seed,transforms:{startupEffectRoutines:{target:STARTUP_ROUTINE_TARGETS[0]}}};assert.notEqual(buildDigest(seed),buildDigest(changed));assert.equal(browserBuildIdentity(changed).startupEffectRoutines,STARTUP_ROUTINE_TARGETS[0]);
  assert.throws(()=>buildDigest({...seed,transforms:{startupEffectRoutines:{target:'arbitrary'}}}));assert.throws(()=>buildDigest({...seed,transforms:{startupEffectRoutines:{}}}));
  const id={...changed,sourceSnapshotId:'s',startupEffectRoutines:STARTUP_ROUTINE_TARGETS[0]};verifyBuildContract(id,{snapshotId:'s'});
  const missing={...id};delete missing.startupEffectRoutines;assert.throws(()=>verifyBuildContract(missing,{snapshotId:'s'}));assert.throws(()=>verifyBuildContract({...id,startupEffectRoutines:STARTUP_ROUTINE_TARGETS[1]},{snapshotId:'s'}));
});
test('actual original state machine + native GLSL Scene give exact boundaries and fewer-than8 valid routine frames',async()=>{
  const f=fixture();try{assert.equal(f.engine.isWebGPU,false,'Null GLSL is not hardware/WebGPU evidence');const {result}=await run(f);f.owner.dispose('startup-resolved');
    const raw=f.owner.snapshot();assert.equal(raw.complete,true);assert.equal(raw.capture.complete,true);assert.equal(raw.stages.length,19);assert.equal(raw.capture.frames.length,3);assert.equal(raw.remainingRoutineHooks,0);
    assert.equal(raw.passes[0].quality,'medium');for(const r of raw.stages)assert.equal(r.endedAtMs-r.startedAtMs,result.stages[r.index].elapsedMs);
    assert.ok(raw.capture.frames.every(r=>r.nativeFrameIdAfter===r.frameId+1&&r.rows.length===40));assert.ok(raw.capture.frames.some(f=>f.rows.some(r=>r.id==='Scene._activeMesh'&&r.calls>0)));
    probe.validateStartupStageEffects(raw,STARTUP_ROUTINE_TARGETS[0]);assert.equal(Object.hasOwn(f.scene,'render'),false);
  }finally{f.dispose();}
});
test('both day targets use actual original stages and exact first quality occurrence',async()=>{
  for(const[target,quality]of[['first-low-day-1-on','low'],['first-high-day-1-on','high']]){const f=fixture(target);try{await run(f,actual,{quality});f.owner.dispose('startup-resolved');const p=f.owner.snapshot();assert.equal(p.complete,true);assert.equal(p.capture.stageIndex,17);assert.equal(p.stages[17].name,'day-1-on');assert.equal(p.capture.frames.length,3);probe.validateStartupStageEffects(p,target);}finally{f.dispose();}}
});
test('instrumentation preserves original now/callback counts, Promise-return callbacks and falsy render errors',async()=>{
  for(const value of[false,0,'',undefined]){const a=fixture(null),b=fixture();try{const before=await run(a,prepareLightVariants,{throwRender:{value}}),after=await run(b,actual,{throwRender:{value}});assert.deepEqual(after.result,before.result);assert.equal(after.nowReads,before.nowReads);assert.equal(after.renders,before.renders);b.owner.dispose('startup-rejected');assert.equal(b.owner.snapshot().complete,false);}finally{a.dispose();b.dispose();}}
  const a=fixture(null),b=fixture();try{const never=new Promise(()=>{});Object.defineProperty(never,'then',{get(){throw Error('original callback Promise must not be inspected');}});const original=await run(a,prepareLightVariants,{renderReturn:never}),observed=await run(b,actual,{renderReturn:never});assert.equal(original.nowReads,observed.nowReads);assert.equal(original.renders,observed.renders);assert.deepEqual(original.result,observed.result);}finally{a.dispose();b.dispose();}
});
test('unreached/partial targets and repeated Medium keep truthful pass indices/status without new budgets',async()=>{
  const f=fixture('first-high-day-1-on');try{await run(f);f.game.quality='high';const {result}=await run(f,actual,{quality:'high',timeoutMs:100});assert.equal(result.status,'timeout');f.owner.dispose('startup-rejected');const p=f.owner.snapshot();assert.equal(p.complete,false);assert.equal(p.capture.reached,false);assert.equal(p.passes.length,2);probe.validateStartupStageEffects(p,'first-high-day-1-on');}finally{f.dispose();}
  const b=fixture();try{await run(b);const frameIds=b.owner.snapshot().capture.frames.map(f=>f.frameId);await run(b);b.owner.dispose('startup-resolved');const p=b.owner.snapshot();assert.equal(p.passes.length,2);assert.deepEqual(p.capture.frames.map(f=>f.frameId),frameIds);assert.equal(p.capture.passIndex,0);probe.validateStartupStageEffects(p,STARTUP_ROUTINE_TARGETS[0]);}finally{b.dispose();}
});
test('foreign scenes pass through selected prototype hooks and abort/rejoin retire late options',()=>{
  const f=fixture(),other=fixture(null);try{const options={};probe.registerStartupOptions(f.game,options);probe.startupPassStarted(options,1);probe.startupStageStarted(options,0,'vehicle-0',2);const token=probe.startupRenderBegin(options,3);other.scene.render();f.scene.render();probe.startupRenderEnd(token,4,true);
    f.game.startupAbort.abort();const old=f.owner.snapshot();assert.equal(old.active,false);assert.equal(old.remainingRoutineHooks,0);probe.startupStageSaved(options,0,8,false);assert.deepEqual(f.owner.snapshot(),old);
    const fresh=probe.createStartupStageEffects(f.game,{target:STARTUP_ROUTINE_TARGETS[0]});assert.equal(fresh.snapshot().active,false,'aborted identity cannot restart');fresh.dispose();
  }finally{f.dispose();other.dispose();}
});
test('frame cap and foreign descriptor restoration are explicit without consuming original operations',()=>{
  const f=fixture();try{const options={};probe.registerStartupOptions(f.game,options);probe.startupPassStarted(options,1);probe.startupStageStarted(options,0,'vehicle-0',2);
    for(let i=0;i<9;i++){const t=probe.startupRenderBegin(options,3+i*2);f.scene.render();if(t)probe.startupRenderEnd(t,4+i*2,true);}
    probe.startupStageSaved(options,0,30,false);probe.startupPassFinished(options,31,'complete');f.owner.dispose('startup-resolved');const p=f.owner.snapshot();assert.equal(p.capture.frames.length,8);assert.equal(p.capture.capped,true);assert.equal(p.complete,false);probe.validateStartupStageEffects(p,STARTUP_ROUTINE_TARGETS[0]);
  }finally{f.dispose();}
  const b=fixture();let foreign;try{const options={};probe.registerStartupOptions(b.game,options);probe.startupPassStarted(options,1);probe.startupStageStarted(options,0,'vehicle-0',2);const t=probe.startupRenderBegin(options,3);
    const own=Object.getOwnPropertyDescriptor(b.scene,'getActiveMeshCandidates');foreign=function(){return {data:[],length:0};};Object.defineProperty(b.scene,'getActiveMeshCandidates',{...own,value:foreign});b.scene.render();probe.startupRenderEnd(t,4,true);b.owner.dispose();assert.equal(b.scene.getActiveMeshCandidates,foreign);assert.ok(b.owner.snapshot().restoreConflicts>0);
  }finally{b.dispose();}
});
test('strict startup-only receipt/schema guards reject false complete, clocks, getter rows, identity and cap tamper',async()=>{
  const f=fixture();try{await run(f);f.owner.dispose('startup-resolved');const raw=f.owner.snapshot();const clone=()=>structuredClone(raw);
    for(const mutate of[p=>p.capture.frames[0].endedAtMs=null,p=>p.capture.frames[0].nativeFrameIdAfter++,p=>p.stages[0].endedAtMs=null,p=>p.target='arbitrary',p=>p.limits.bytes++,p=>p.passes[0].quality='high',p=>p.capture.frames.reverse(),p=>p.capture.frames[1]=structuredClone(p.capture.frames[0]),p=>p.stages[1].name='vehicle-0']){const p=clone();mutate(p);assert.throws(()=>probe.validateStartupStageEffects(p,STARTUP_ROUTINE_TARGETS[0]));}
    const getter=clone();Object.defineProperty(getter.capture.frames[0].rows[0],'calls',{get(){throw Error('getter invoked');},enumerable:true});assert.throws(()=>probe.validateStartupStageEffects(getter,STARTUP_ROUTINE_TARGETS[0]),e=>!/getter invoked/.test(e.message));
    const identity={buildId:'b',sourceSnapshotId:'s',helperSha256:'h',lifecycleControls:false,startupEffectRoutines:STARTUP_ROUTINE_TARGETS[0]};const receipt={...identity,schemaVersion:1,attemptId:'8e9e7e15-6011-438d-96a2-53be43f17792',kind:'startup',outcome:'resolved',mode:'diagnostic',atMs:100,timeOrigin:1000,observerErrors:[],samples:[],terminal:{},startupStageEffects:raw};validateReceipt(receipt,identity);assert.throws(()=>validateReceipt({...receipt,kind:'state'},identity));assert.throws(()=>validateReceipt({...receipt,startupEffectRoutines:null},identity));assert.ok(Buffer.byteLength(JSON.stringify(receipt))<2*1024*1024);assert.ok(Buffer.byteLength(JSON.stringify(raw))<probe.STARTUP_LIMITS.bytes);
  }finally{f.dispose();}
});
test('current pack contains41 exact inputs and keeps old routine/core byteidentical',async()=>{
  const path=new URL('.',import.meta.url),id=await helperIdentity(path.pathname.slice(1));assert.equal(Object.keys(id.files).length,41);
  for(const file of['routine-cost.mjs','routine-cost-core.mjs'])assert.deepEqual(await readFile(new URL(file,import.meta.url)),await readFile(new URL('../../../startup-stage-export/helper/v17/'+file,import.meta.url)));
});
test('16pass/304stage cap keeps bounded truthful prefix and never substitutes original options',()=>{
  const f=fixture();try{let at=0;
    for(let p=0;p<17;p++){const o={};assert.equal(probe.registerStartupOptions(f.game,o),o);probe.startupPassStarted(o,++at);
      for(let i=0;i<19;i++){const name=['vehicle-0','vehicle-1','vehicle-2','vehicle-keyed-0','vehicle-keyed-1','vehicle-keyed-2','current-off','current-on','night-0-off','night-0-on','night-1-off','night-1-on','night-2-off','night-2-on','day-0-off','day-0-on','day-1-off','day-1-on','restore'][i];probe.startupStageStarted(o,i,name,++at);probe.startupStageSaved(o,i,++at,false);}
      probe.startupPassFinished(o,++at,'complete');}
    f.owner.dispose('startup-resolved');const p=f.owner.snapshot();assert.equal(p.passCount,17);assert.equal(p.passes.length,16);assert.equal(p.stages.length,304);assert.equal(p.overflow,true);assert.equal(p.complete,false);probe.validateStartupStageEffects(p,STARTUP_ROUTINE_TARGETS[0]);assert.ok(Buffer.byteLength(JSON.stringify(p))<probe.STARTUP_LIMITS.bytes);
  }finally{f.dispose();}
});
test('sameScene recursion and options reentry preserve original native work but cannot become complete',()=>{
  const f=fixture();try{const o={};probe.registerStartupOptions(f.game,o);probe.startupPassStarted(o,1);probe.startupStageStarted(o,0,'vehicle-0',2);const t=probe.startupRenderBegin(o,3);
    const reentrant={};assert.equal(probe.registerStartupOptions(f.game,reentrant),reentrant);let entered=false;const obs=f.scene.onBeforeRenderObservable.add(()=>{if(!entered){entered=true;f.scene.render();}});f.scene.render();f.scene.onBeforeRenderObservable.remove(obs);probe.startupRenderEnd(t,4,true);
    probe.startupStageSaved(o,0,5,false);probe.startupPassFinished(o,6,'complete');f.owner.dispose('startup-resolved');const p=f.owner.snapshot();assert.equal(entered,true);assert.equal(p.capture.frames[0].nativeFrameIdAfter,p.capture.frames[0].frameId+2);assert.equal(p.complete,false);assert.ok(p.errors>0);probe.validateStartupStageEffects(p,STARTUP_ROUTINE_TARGETS[0]);
  }finally{f.dispose();}
});
test('owner retirement during native render and fresh sameGame generation reject late source callbacks',()=>{
  const f=fixture();try{const o={};probe.registerStartupOptions(f.game,o);probe.startupPassStarted(o,1);probe.startupStageStarted(o,0,'vehicle-0',2);const t=probe.startupRenderBegin(o,3);f.owner.dispose();
    const old=f.owner.snapshot();f.game.renderHealth.generation++;f.game.startupAbort=new AbortController();const fresh=probe.createStartupStageEffects(f.game,{target:STARTUP_ROUTINE_TARGETS[0]});
    probe.startupRenderEnd(t,4,true);probe.startupStageSaved(o,0,5,false);assert.deepEqual(f.owner.snapshot(),old);assert.equal(fresh.snapshot().active,true);fresh.dispose();assert.equal(fresh.snapshot().remainingRoutineHooks,0);
  }finally{f.dispose();}
});
test('descriptor preflight failure is atomic, getters stay uncalled and later calls do not retry instrumentation',()=>{
  const f=fixture();const before=Object.getOwnPropertyDescriptor(f.scene,'getActiveMeshCandidates');let reads=0;const primary=false;
  try{Object.defineProperty(f.scene,'getActiveMeshCandidates',{configurable:true,get(){reads++;throw primary;}});const o={};probe.registerStartupOptions(f.game,o);probe.startupPassStarted(o,1);probe.startupStageStarted(o,0,'vehicle-0',2);
    assert.equal(probe.startupRenderBegin(o,3),null);assert.equal(reads,0);const errors=f.owner.snapshot().errors;assert.equal(probe.startupRenderBegin(o,4),null);assert.equal(f.owner.snapshot().errors,errors);assert.throws(()=>f.scene.render(),e=>e===primary);
    f.owner.dispose();const p=f.owner.snapshot();assert.equal(p.remainingRoutineHooks,0);assert.ok(p.errors>0);probe.validateStartupStageEffects(p,STARTUP_ROUTINE_TARGETS[0]);
  }finally{if(before)Object.defineProperty(f.scene,'getActiveMeshCandidates',before);else delete f.scene.getActiveMeshCandidates;f.dispose();}
});
test('cross-pass clock rollback retires only diagnostic state and retains a valid partial prefix',()=>{
  const f=fixture();try{const a={},b={};probe.registerStartupOptions(f.game,a);probe.startupPassStarted(a,10);probe.startupStageStarted(a,0,'vehicle-0',11);probe.startupStageSaved(a,0,12,false);probe.startupPassFinished(a,13,'complete');
    assert.equal(probe.registerStartupOptions(f.game,b),b);probe.startupPassStarted(b,9);const p=f.owner.snapshot();assert.equal(p.reason,'observer-error');assert.equal(p.active,false);assert.equal(p.passes[1].startedAtMs,null);assert.equal(p.complete,false);assert.equal(f.game.disposed,false);assert.equal(f.game.ready,false);probe.validateStartupStageEffects(p,STARTUP_ROUTINE_TARGETS[0]);
  }finally{f.dispose();}
});
async function overlayFixtureV19(clockSpecification=null){
  // Reuse the complete pre-existing DOM/transport fixture body; only inject
  // the new diagnostic binding/flag. Never import its test registration.
  const file=await readFile(new URL('./preparation-summary.test.mjs',import.meta.url),'utf8'),ast=ts.createSourceFile('fixture.mjs',file,ts.ScriptTarget.Latest,true);
  let body=ast.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text==='overlayFixture').getText(ast);
  for(const[from,to]of[['observeOperation, observePreparationResult, createAttemptQueue','createStartupStageEffects, observeOperation, observePreparationResult, createAttemptQueue'],['startupLatency: false, bufferLifecycle:','startupEffectRoutines: "first-medium-vehicle-0", startupLatency: false, bufferLifecycle:'],["projectShaderInventory() { throw Error('default-off shader inventory'); }",'projectShaderInventory'],['clock: null };','clock: clockSpecification };']]){assert.equal(body.split(from).length,2);body=body.replace(from,to);}
  const modules=await Promise.all(['startup-observer','attempt-queue','browser-clock','transit-clock','startup-latency','buffer-lifecycle','lifecycle-controls','shader-attribution'].map(name=>import('./'+name+'.mjs')));
  const dependencies={readFile,join,directory:dirname(fileURLToPath(import.meta.url)),webcrypto,sha256,clockSpecification,createStartupStageEffects:probe.createStartupStageEffects,
    observeOperation:modules[0].observeOperation,observePreparationResult:modules[0].observePreparationResult,createAttemptQueue:modules[1].createAttemptQueue,installBrowserClock:modules[2].installBrowserClock,createPlannedBenchmark:modules[3].createPlannedBenchmark,
    observeStartupLatency:modules[4].observeStartupLatency,observeBufferLifecycle:modules[5].observeBufferLifecycle,createLifecycleControls:modules[6].createLifecycleControls,createVisibilityAnchor:modules[6].createVisibilityAnchor,projectShaderInventory:modules[7].projectShaderInventory};
  return new Function(...Object.keys(dependencies),body+';return overlayFixture;')(...Object.values(dependencies))();
}
test('actual overlay exports the startup trace once before UI continuation and original stage summary stays present',async()=>{
  const overlay=await overlayFixtureV19();
  const f=fixture(null);try{Object.assign(f.game,{avatars:new Map(),adaptive:{state:{}},gpu:{},renderErrorCount:0,assetLoadErrorCount:0,compilationProfile:{snapshot:()=>({active:true,metrics:{}})}});
    f.game.renderHealth.snapshot=()=>({phase:f.game.ready?'ready':'preparing',valid:f.game.ready,rendererId:1,generation:1,errorCount:0,pendingOperations:0});
    f.game.prepareLighting=async()=>{const value=await run(f);return{...value.result,qualities:[{quality:'medium',finalPass:true,status:'complete',elapsedMs:value.result.elapsedMs,activeElapsedMs:value.result.activeElapsedMs,pausedMs:0,failureStep:null,stageCount:19}],stages:value.result.stages.map(s=>({...s,passQuality:'medium'}))};};
    const result=await overlay.observeStartup(f.game,{dataset:{}},async()=>{await f.game.prepareLighting();f.game.ready=true;return 42;});overlay.events.push('UI-continuation');assert.equal(result,42);
    const raw=overlay.raw();assert.equal(raw.mode,'diagnostic');assert.equal(raw.startupEffectRoutines,STARTUP_ROUTINE_TARGETS[0]);assert.equal(raw.startupStageEffects.complete,true);assert.equal(raw.preparationStages.capturedCount,19);assert.equal(raw.startupStageEffects.remainingRoutineHooks,0);assert.equal(overlay.intervals.size,0);
    assert.ok(overlay.events.indexOf('terminal-raw')<overlay.events.indexOf('UI-continuation'));assert.ok(raw.samples.every(s=>!Object.hasOwn(s,'startupStageEffects')));
    for(let i=0;i<100&&overlay.requests.length===0;i++)await new Promise(setImmediate);assert.equal(overlay.requests.length,1);
    const without={...raw};delete without.startupStageEffects;assert.throws(()=>validateReceipt(without,raw),'active resolved startup requires its existing profile');
  }finally{f.dispose();}
});
test('actual pre-owner clock refusals retain original rejected raw without fabricating an optional profile',async()=>{
  for(const mode of['guest','expired']){const clock={config:{schemaVersion:1,scenarioEpochUTC:0,armAtUTC:mode==='expired'?0:Date.now()+60000},configId:'clock-fixture',configSha256:'clock-bytes',simulationSourceSha256:'simulation'};
    const overlay=await overlayFixtureV19(clock),f=fixture(null);let starts=0,primary;
    try{Object.assign(f.game,{network:mode!=='guest',camera:f.scene.activeCamera,trafficInstant:()=>0,avatars:new Map(),adaptive:{state:{}},gpu:{},renderErrorCount:0,assetLoadErrorCount:0,compilationProfile:{snapshot:()=>({active:true,metrics:{}})}});
      f.game.renderHealth.snapshot=()=>({phase:'preparing',valid:false,rendererId:1,generation:1,errorCount:0,pendingOperations:0});
      await assert.rejects(overlay.observeStartup(f.game,{dataset:{}},()=>{starts++;}),error=>{primary=error;return mode==='guest'?/guest start refused/.test(error.message):/after static arm deadline/.test(error.message);});
      const raw=overlay.raw();assert.equal(starts,0);assert.equal(raw.outcome,'rejected');assert.equal(raw.error.message,primary.message);assert.equal(Object.hasOwn(raw,'startupStageEffects'),false);assert.deepEqual(raw.observerErrors,[]);validateReceipt(raw,raw);
      assert.throws(()=>validateReceipt({...raw,startupStageEffects:null},raw));assert.throws(()=>validateReceipt({...raw,startupStageEffects:{}},raw));
      for(let i=0;i<100&&overlay.requests.length===0;i++)await new Promise(setImmediate);assert.equal(overlay.requests.length,1);assert.equal(overlay.requests[0].outcome,'rejected');
    }finally{f.dispose();}
  }
});
test('pipeline action closed envelope admits only the already validated startup target, null and active',()=>{
  for(const target of[null,STARTUP_ROUTINE_TARGETS[0]]){const identity={buildId:'b',sourceSnapshotId:'s',helperSha256:'h',lifecycleControls:false,routineCost:true,startupEffectRoutines:target};
    const raw={...identity,schemaVersion:1,attemptId:'8e9e7e15-6011-438d-96a2-53be43f17792',kind:'pipeline-inputs',mode:'diagnostic',atMs:1,timeOrigin:0,observerErrors:[],completed:false,before:{},after:{},pipelineInputs:null,failure:{message:'original refusal'},validationErrors:['refused']};
    assert.equal(validateReceipt(raw,identity),raw);assert.throws(()=>validateReceipt({...raw,arbitraryField:true},identity));assert.throws(()=>validateReceipt({...raw,startupEffectRoutines:target===null?STARTUP_ROUTINE_TARGETS[0]:null},identity));assert.throws(()=>validateReceipt({...raw,startupEffectRoutines:{}},identity));
  }
});
test('second native RTT observer add failure rolls back the first own observer and preserves notifications/render',async()=>{
  const f=fixture(),renderer=new ObjectRenderer('CPU rollback',f.scene),events=[];
  const initBefore=renderer.onInitRenderingObservable.add(()=>events.push('init-original')),finishBefore=renderer.onFinishRenderingObservable.add(()=>events.push('finish-original'));
  const countBefore=renderer.onInitRenderingObservable.observers.length,original=Object.getOwnPropertyDescriptor(renderer.onFinishRenderingObservable,'add');
  try{Object.defineProperty(renderer.onFinishRenderingObservable,'add',{configurable:true,writable:true,value(){throw false;}});
    const options={};probe.registerStartupOptions(f.game,options);probe.startupPassStarted(options,1);probe.startupStageStarted(options,0,'vehicle-0',2);assert.equal(probe.startupRenderBegin(options,3),null);
    assert.equal(renderer.onInitRenderingObservable.observers.filter(o=>!o._willBeUnregistered).length,countBefore,'no active orphan init observer after failed second add');assert.equal(f.owner.snapshot().remainingRoutineHooks,0);
    renderer.onInitRenderingObservable.notifyObservers(renderer);renderer.onFinishRenderingObservable.notifyObservers(renderer);assert.deepEqual(events,['init-original','finish-original']);const before=f.scene._frameId;f.scene.render();assert.equal(f.scene._frameId,before+1);
    await new Promise(resolve=>setTimeout(resolve,0));assert.equal(renderer.onInitRenderingObservable.observers.length,countBefore,'original native deferred removal finished');
  }finally{if(original)Object.defineProperty(renderer.onFinishRenderingObservable,'add',original);else delete renderer.onFinishRenderingObservable.add;initBefore.remove();finishBefore.remove();renderer.dispose();f.dispose();}
});
test('actual transformed Game callsite executes its original options literal and registration, without manual registration',async()=>{
  for(const transformedGame of[true,false]){const f=fixture(),engineFlag=Object.getOwnPropertyDescriptor(f.engine,'isWebGPU');let tick,clock=1000,done=false,result,failure,captured,renders=0,authoredDisposed=0;
    try{f.game.flashlight={};f.game.compilationProfile={setStage(){}};f.game.startupPreparationCoverage=()=>'';
      // Technical routing seam only while the real Game options literal is
      // built. Restore native NullEngine/GLSL before any actual Scene.render.
      Object.defineProperty(f.engine,'isWebGPU',{configurable:true,value:true});
      const render=()=>{assert.equal(f.engine.isWebGPU,false);renders++;f.scene.render();};
      const prepare=options=>{captured=options;assert.equal(options.includeVehicleVariants,true);assert.equal(options.includeDayPointVariants,true);assert.equal(options.render,render);assert.equal(options.revisionKeys.length,14);assert.match(options.apply.toString(),/setStage/);assert.match(options.check.toString(),/isMeshReadyForCamera/);
        if(engineFlag)Object.defineProperty(f.engine,'isWebGPU',engineFlag);else delete f.engine.isWebGPU;assert.equal(f.engine.isWebGPU,false);
        Object.assign(options,{apply(){},restore(){},meshes:()=>[],check:()=>true,effectsReady:()=>true,run:callback=>{tick=callback;},stop:callback=>assert.equal(callback,tick),isVisible:()=>true,onVisibilityChange:()=>()=>{},now:()=>clock,setTimer:()=>1,clearTimer(){}});
        return actual(options);};
      const text=transformedGame?transformStartupSource(gameSource,'game',STARTUP_ROUTINE_TARGETS[0]):gameSource;
      const ast=ts.createSourceFile('game.ts',text,ts.ScriptTarget.Latest,true),klass=ast.statements.find(n=>ts.isClassDeclaration(n)&&n.name?.text==='Game'),method=klass.members.find(n=>n.name?.getText(ast)==='prepareLightingVariants').getText(ast);
      const js=ts.transpileModule('class ActualGameMethod{'+method+'}',{compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText;
      const invoke=new Function('registerStartupOptions','prepareLightVariants','selectLightingPreview','AuthoredLightPreparation',js+';return ActualGameMethod.prototype.prepareLightingVariants;')(probe.registerStartupOptions,prepare,()=>({instant:1}),class{dispose(){authoredDisposed++;}});
      const operation=invoke.call(f.game,render);operation.then(value=>{result=value;done=true;},error=>{failure=error;done=true;});
      for(let i=0;i<1000&&!done;i++){clock+=10;tick();await flush();}if(failure)throw failure;assert.equal(done,true);assert.equal(result.status,'complete');assert.equal(result.stages.length,19);assert.ok(captured);assert.equal(renders,57);assert.equal(authoredDisposed,1);
      f.owner.dispose('startup-resolved');const p=f.owner.snapshot();if(transformedGame){assert.equal(p.complete,true);assert.equal(p.passes.length,1);assert.equal(p.stages.length,19);assert.equal(p.capture.frames.length,3);assert.equal(p.passes[0].quality,'medium');probe.validateStartupStageEffects(p,STARTUP_ROUTINE_TARGETS[0]);}
      else{assert.equal(p.passes.length,0);assert.equal(p.stages.length,0);assert.equal(p.capture.frames.length,0);assert.equal(p.complete,false,'untransformed callsite cannot accidentally receive manual registration');}
    }finally{if(engineFlag)Object.defineProperty(f.engine,'isWebGPU',engineFlag);else delete f.engine.isWebGPU;f.dispose();}
  }
});
