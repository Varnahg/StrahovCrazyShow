import { type _IProcessingOptions } from "./shaderProcessingOptions.js";
import { type WebRequest } from "../../Misc/webRequest.js";
import { type LoadFileError } from "../../Misc/fileTools.js";
import { type IOfflineProvider } from "../../Offline/IOfflineProvider.js";
import { type IFileRequest } from "../../Misc/fileRequest.js";
import { type AbstractEngine } from "../abstractEngine.js";
import { type IShaderProcessor } from "./iShaderProcessor.js";
/** @internal Syntax-only cache budgets; UTF-16 units/counts are not heap bytes. */
export interface ShaderSyntaxCacheOptions {
    enabled?: boolean;
    maxEntries?: number;
    maxTextUnits?: number;
    maxNodes?: number;
    maxOperators?: number;
}
/** @internal Primitive snapshot only; never exposes cached source or AST. */
export interface ShaderSyntaxCacheStats {
    enabled: boolean;
    disposed: boolean;
    generation: number;
    requests: number;
    hits: number;
    misses: number;
    evictions: number;
    oversized: number;
    parseErrors: number;
    entries: number;
    sourceUnits: number;
    nodeStringUnits: number;
    textUnits: number;
    nodes: number;
    operators: number;
    peakEntries: number;
    peakTextUnits: number;
    peakNodes: number;
    peakOperators: number;
    maxEntries: number;
    maxTextUnits: number;
    maxNodes: number;
    maxOperators: number;
}
/** @internal One owner per processor. Off by default; dispose is idempotent.
 * reset clears entries/counters and advances generation, preserving enabled.
 * Disabling clears entries but preserves counters. A disposed lease cannot be
 * re-enabled/reset; its final primitive snapshot remains readable. */
export interface ShaderSyntaxCacheLease {
    setEnabled(enabled: boolean): void;
    reset(): void;
    snapshot(): ShaderSyntaxCacheStats;
    dispose(): void;
}
/** @internal Keeps only immutable syntax for exact post-include prepared text. */
export declare function CreateShaderSyntaxCache(processor: IShaderProcessor, options?: ShaderSyntaxCacheOptions): ShaderSyntaxCacheLease;
/** @internal */
export declare function Initialize(options: _IProcessingOptions): void;
/** @internal */
export declare function Process(sourceCode: string, options: _IProcessingOptions, callback: (migratedCode: string, codeBeforeMigration: string) => void, engine?: AbstractEngine): void;
/** @internal */
export declare function PreProcess(sourceCode: string, options: _IProcessingOptions, callback: (migratedCode: string, codeBeforeMigration: string) => void, engine: AbstractEngine): void;
/** @internal */
export declare function Finalize(vertexCode: string, fragmentCode: string, options: _IProcessingOptions): {
    vertexCode: string;
    fragmentCode: string;
};
/** @internal */
export declare function ProcessIncludes(sourceCode: string, options: _IProcessingOptions, callback: (data: any) => void): void;
/**
 * @deprecated Use direct imports from fileTools.pure instead. Kept for backwards compatibility.
 * @internal
 */
export declare const _FunctionContainer: {
    loadFile: (url: string, onSuccess: (data: string | ArrayBuffer, responseURL?: string) => void, onProgress?: (ev: ProgressEvent) => void, offlineProvider?: IOfflineProvider, useArrayBuffer?: boolean, onError?: (request?: WebRequest, exception?: LoadFileError) => void) => IFileRequest;
};
