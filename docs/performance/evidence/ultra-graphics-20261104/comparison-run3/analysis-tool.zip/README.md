# Ultra offline capture report

This is a small offline helper, not a browser runner or performance experiment. Synthetic test directories and reports are **correctness fixtures, not game evidence**. It reads input artifacts without changing them. It never grants optimization or gameplay approval.

Run from `D:/CodexWorkspaces/StrahovCrazyShow-graphics-20261104` after GPU measurement stops:

```powershell
node --import ./node_modules/tsx/dist/loader.mjs .cache/ultra-report-20261104/report.mjs .cache/ultra-report-20261104/capture-map.jsonl .cache/ultra-report-20261104/report-01.json
```

Omit the final argument for full JSON on stdout. Output files must be new and inside this helper directory; existing results are never overwritten. A successful CLI exit means analysis completed, **not** that coverage, performance or gameplay passed. Inspect `coverage`, `mapIssues`, `comparability` and `ultraVsLowScenery`.

Each JSONL line maps one original capture, with paths absolute or relative to the map file:

```json
{"block":1,"variant":"A","view":"down","serverPath":"D:/.../benchmarks/UUID.json","fullPath":"D:/.../strahov-benchmark-DATE.json"}
```

`capture-map.template.jsonl` lists the predeclared order of all 48 slots. Copy it to the chosen map path and fill paths as captures arrive. `block` is 1–3; `variant` is A–H; `view` is `down` or `scenery`. Missing paths, files, malformed rows, duplicate slots and reused byte-identical artifacts remain explicit. Partial rows still expose any calculable metrics. Do not shift subsequent labels when one upload fails. Server records are the `{receivedAtUTC,sourceSnapshotId,benchmark}` envelope; full files must be the actual full UI download.

The protocol now has **three interleaved blocks in one settled session**, not three independent cold starts. Cold Ultra startup, WebGL2 smoke and movement checks are separate evidence.

## What the report means

- `samples` preserves every listed row, paths/SHA256, actual features, scale, source, pose, raw-record health/compilation and per-sample summaries. Raw artifacts remain authoritative.
- p95/p99/max/hitches come directly from `assessFrameSample` used by the current HUD (`floor(N*p)` index). Median averages the two middle values for even N. The group median is the median of three per-sample medians. Group p95/p99 distributions summarize per-sample percentiles; they do not pool intervals or average percentiles.
- Server/full comparison uses the actual `projectLocalBenchmark` projection, so intentionally removed full-record properties do not cause mismatches. Published p95/p99 must match raw intervals. Recorded benchmark duration and sum of frame intervals are both retained; they are different clocks, and no new tolerance is invented between them.
- Slow but otherwise complete samples remain in groups. Their `frameGate` may fail; failing FPS never makes a sample disappear. Missing/incorrect evidence is excluded from group aggregates and listed separately.
- `drawCallsAtEnd`, triangles, LOD and render-cost inventory are end snapshots. CPU phase values are interval means; nested phases must not be summed as exclusive work.
- `gpuLastSample` is preserved only per sample, never averaged into groups. It is a last asynchronous observation, and WebGPU main-pass timing excludes other passes. Null stays unknown.
- Health, compilation and full start/end weather come **only from the full download**. Server export cannot fill them in.
- Exact pose/view/light/weather and GPU identity comparisons against block A are exposed in `comparability`. No unapproved pose/weather tolerance is invented. Projection-matrix changes are reported separately because render scaling can change rounded backbuffer aspect and LOD; they do not by themselves prove movement.
- `coverage.complete` means 48 unique slots have complete internally consistent artifacts. It does not prove visible foreground intervals, system stability, correct camera targets, gameplay or visuals. Partial/missing/duplicate slots remain listed.
- `ultraVsLowScenery` compares paired A/H samples in each block and the median of three sample medians. The existing >=20% criterion is evaluated only for complete comparable pairs. Any positive p99 change is shown by block; the plan does not quantify "repeatable", so worsening returns `adjudication-required-no-repeatability-threshold-specified`. No arbitrary cutoff or statistical significance is invented. `optimizationAccepted` always remains false pending coordinator adjudication, complete coverage, raw-session/system checks and gameplay acceptance.

Use saved raw `benchmark-start` timestamps with `session-start.timeOrigin` for telemetry alignment; `receivedAtUTC` is upload receipt, not a GPU interval boundary. This helper does not join raw session/system samples and does not replace the existing `scripts/analyze-system-gpu.mjs` and `scripts/gameplay-acceptance.mjs` helpers.

## Visible day/season UI

In the existing settings/benchmark area: label **Náhled osvětlení** offers **Denní náhled · demo**, **Zlatá hodina · demo**, **Modrá hodina · demo**, **Noční náhled · demo**, **Úplňková noc · demo**, and **Skutečný čas na Strahově**. Label **Náhled ročního období** offers **Jaro · DEMO**, **Léto · DEMO**, **Podzim · DEMO**, **Zima · DEMO**, and **Skutečné datum · regionální model**. Day preview is a solved solar instant, not a generic fixed wall-clock hour; season changes re-solve the current light selection for the seasonal date. Choose both before capture and verify the displayed Prague instant and saved `sceneView.lightingInstant`/`treeSeason`, then keep them fixed. Source: `client/ui.tsx`, `client/lighting-preview.ts`, `client/season-preview.ts`.

## Cheap correctness verification

```powershell
node --import ./node_modules/tsx/dist/loader.mjs --test .cache/ultra-report-20261104/report.test.mjs
```

Tests write only small synthetic files below this directory. Do not execute them or the offline report during timed GPU intervals. They do not measure performance and do not start Babylon, browsers, servers or GPU work.
