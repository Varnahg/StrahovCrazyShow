/** Tiny synthetic correctness fixtures only. NOT performance/game evidence. */
import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdir, mkdtemp, writeFile, readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createReport, expectedSettings, frameMetrics, median } from './report.mjs';
import { projectLocalBenchmark } from '../../shared/local-benchmark.ts';

const root = fileURLToPath(new URL('./', import.meta.url));
async function fixture(rows) {
  await mkdir(root, { recursive: true });
  const dir = await mkdtemp(join(root, 'synthetic-'));
  const map = [];
  for (const [i, row] of rows.entries()) {
    const ultra = row.variant === 'H', frames = Array(ultra ? 1000 : 500).fill(ultra ? 12 : 24);
    const settings = expectedSettings(row.variant);
    const full = {
      syntheticFixture: 'CORRECTNESS ONLY', date: new Date(Date.UTC(2026, 0, 1, 0, 0, i)).toISOString(),
      sourceSnapshotId: 'a'.repeat(64), durationSeconds: 12, frames: frames.length, frameIntervalsMs: frames,
      averageFps: 1000 / frames[0], p95FrameMs: frames[0], p99FrameMs: frames[0],
      renderErrorCount: 0, assetLoadErrorCount: 0, avatars: 3,
      viewport: { width: 1280, height: 720 },
      renderResolution: { width: Math.floor(1280 * settings.renderScale), height: Math.floor(720 * settings.renderScale) },
      quality: 'low', rendering: { ...settings, graphicsApplying: false, transitionPhase: null, settingsRevision: i + 1,
        extraNotInHttp: 'full download keeps extra state' },
      gpu: { renderer: 'synthetic', vendor: 'synthetic', classification: 'unknown' },
      sceneView: { position: { x: 1, y: 2, z: 3 }, yaw: 0, pitch: row.view === 'down' ? 1 : 0, lightingInstant: 1000,
        camera: { position: { x: 1, y: 3, z: 3 }, fov: .85, minZ: .08, maxZ: 1100,
          viewMatrix: Array(16).fill(0), projectionMatrix: Array(16).fill(0) } },
      renderHealth: { valid: true, start: { valid: true, generation: 1 }, end: { valid: true, generation: 1 } },
      compilation: { start: { shaderModule: { calls: 10 } }, end: { shaderModule: { calls: 10 } } },
      weatherAtStart: { qa: 'synthetic', rain: 0 }, weatherAtEnd: { qa: 'synthetic', rain: 0 },
      drawCalls: 100, avatarLod: { near: 3, medium: 0, far: 0 },
      frameBreakdownMs: { render: 10 }, engineCpuBreakdownMs: { mainDraw: 8 },
      frameWork: { cpuMs: 11, gpuMs: null, webgpuMainPassMs: 7, webgpuMainPassScope: 'main-render-pass-only' },
    };
    row.modify?.(full);
    const measured = frameMetrics(full.frameIntervalsMs).metrics;
    full.p95FrameMs = measured.p95Ms; full.p99FrameMs = measured.p99Ms;
    full.averageFps = Number(measured.averageFps.toFixed(1));
    const server = { receivedAtUTC: new Date(Date.UTC(2026, 0, 1, 0, 1, i)).toISOString(),
      sourceSnapshotId: full.sourceSnapshotId, benchmark: projectLocalBenchmark(full) };
    const fullPath = `full-${i}.json`, serverPath = `server-${i}.json`;
    await writeFile(join(dir, fullPath), JSON.stringify(full));
    await writeFile(join(dir, serverPath), JSON.stringify(server));
    map.push({ block: row.block, variant: row.variant, view: row.view, serverPath, fullPath });
  }
  const mapPath = join(dir, 'capture-map.jsonl');
  const save = async () => writeFile(mapPath, map.map(x => JSON.stringify(x)).join('\n') + '\n');
  await save(); return { dir, map, mapPath, save };
}

test('HUD exact-rank p95/p99 and standard even/odd median, invalid input preserved', () => {
  const values = Array.from({ length: 100 }, (_, i) => i + 1), r = frameMetrics(values);
  assert.equal(r.metrics.p95Ms, 96); assert.equal(r.metrics.p99Ms, 100);
  assert.equal(r.metrics.maxMs, 100); assert.equal(r.metrics.hitches, 51);
  assert.equal(r.metrics.medianMs, 50.5); assert.equal(median([5, 1, 3]), 3);
  assert.equal(frameMetrics([1, 0]).metrics, null);
  assert.equal(frameMetrics(undefined).metrics, null);
});
test('48 synthetic slots use actual projection, preserve each sample and avoid automatic approval', async () => {
  const rows = [1, 2, 3].flatMap(block => [...'ABCDEFGH'].flatMap(variant => ['down', 'scenery'].map(view => ({ block, variant, view }))));
  const f = await fixture(rows), report = await createReport(f.mapPath);
  assert.equal(report.coverage.complete, true, JSON.stringify(report.coverage.partialOrInvalid));
  assert.equal(report.samples.length, 48); assert.equal(report.groups.length, 16);
  assert.equal(report.ultraVsLowScenery.medianImprovementFraction, .5);
  assert.equal(report.ultraVsLowScenery.medianCriterion, 'met');
  assert.equal(report.ultraVsLowScenery.p99Conclusion, 'no-observed-p99-regression');
  assert.equal(report.ultraVsLowScenery.optimizationAccepted, false);
  assert.equal(report.groups[0].drawCallsAtEnd.median, 100);
  assert.equal(report.groups[0].cpuMeanMsAcrossSamples.frame.render.median, 10);
  assert.equal(report.samples[0].gpuLastSample.value.webgpuMainPassMs, 7);
  assert.equal('gpu' in report.groups[0], false, 'singleton GPU sample is not grouped as a mean');
});
test('partial rows, malformed line, absent full file and all missing slots are explicit', async () => {
  const f = await fixture([{ block: 1, variant: 'A', view: 'down' }]);
  f.map[0].fullPath = 'not-captured.json'; f.map.push({ block: 1, variant: 'B', view: 'down' });
  await f.save(); await writeFile(f.mapPath, (await readFile(f.mapPath, 'utf8')) + '{partial-json\n');
  const r = await createReport(f.mapPath);
  assert.equal(r.coverage.complete, false); assert.equal(r.coverage.missing.length, 46);
  assert.equal(r.coverage.partialOrInvalid.length, 2); assert.equal(r.mapIssues.length, 1);
  assert.ok(r.samples[0].metrics); assert.equal(r.samples[0].fullOnly.renderHealth, null);
  assert.equal(r.ultraVsLowScenery.medianCriterion, 'inconclusive');
});
test('duplicate slots, reused artifacts and mixed source do not count as independent evidence', async () => {
  const f = await fixture([{ block: 1, variant: 'A', view: 'down' }, { block: 2, variant: 'A', view: 'down',
    modify: b => { b.sourceSnapshotId = 'b'.repeat(64); } }]);
  f.map.push({ ...f.map[0] }); await f.save(); const r = await createReport(f.mapPath);
  assert.equal(r.coverage.evidenceCompleteSlots, 0);
  assert.ok(r.samples[0].issues.includes('duplicate-slot'));
  assert.ok(r.samples[0].issues.includes('reused-server-artifact'));
  assert.ok(r.samples[1].issues.includes('mixed-campaign-source'));
});
test('full record disagreement and missing health remain invalid even with apparently fast server metrics', async () => {
  const f = await fixture([{ block: 1, variant: 'A', view: 'scenery' }]);
  const path = join(f.dir, f.map[0].fullPath), b = JSON.parse(await readFile(path));
  b.frameIntervalsMs[0] = 500; b.renderHealth.valid = false; await writeFile(path, JSON.stringify(b));
  const r = await createReport(f.mapPath);
  assert.ok(r.samples[0].issues.includes('server-full-mismatch:frameIntervalsMs'));
  assert.ok(r.samples[0].issues.includes('full-health-missing-or-invalid'));
});
test('p99 worsening is reported per block with no invented repeatability cutoff', async () => {
  const f = await fixture([1, 2, 3].flatMap(block => ['A', 'H'].map(variant => ({ block, variant, view: 'scenery',
    modify: b => { if (variant === 'H' && block === 1) for (let i = 0; i < 20; i++) b.frameIntervalsMs[i] = 70; } }))));
  const r = await createReport(f.mapPath);
  assert.equal(r.ultraVsLowScenery.medianCriterion, 'met');
  assert.deepEqual(r.ultraVsLowScenery.p99WorseBlocks, [1]);
  assert.match(r.ultraVsLowScenery.p99Conclusion, /adjudication-required/);
  assert.equal(r.coverage.complete, false); assert.equal(r.ultraVsLowScenery.optimizationAccepted, false);
});
test('changed weather, wrong settings, source or exact camera differences are not silently accepted', async () => {
  const f = await fixture([{ block: 1, variant: 'A', view: 'scenery' }, { block: 1, variant: 'H', view: 'scenery',
    modify: b => { b.sceneView.camera.position.x += .001; } }, { block: 2, variant: 'C', view: 'down',
    modify: b => { b.rendering.features.shadows = true; b.weatherAtEnd.rain = 1; } }]);
  const r = await createReport(f.mapPath);
  assert.ok(r.ultraVsLowScenery.pairs[0].issues.includes('view-or-lighting-differs-exactly'));
  assert.ok(r.samples[2].issues.includes('settings-mismatch:features'));
  assert.ok(r.samples[2].issues.includes('weather-changed-within-sample'));
});
test('intended render-scale projection change is retained separately from exact pose differences', async () => {
  const f = await fixture([{ block: 1, variant: 'A', view: 'scenery' }, { block: 1, variant: 'H', view: 'scenery',
    modify: b => { b.sceneView.camera.projectionMatrix[0] = .001; } }]);
  const r = await createReport(f.mapPath);
  assert.deepEqual(r.ultraVsLowScenery.pairs[0].issues, []);
  assert.equal(r.ultraVsLowScenery.pairs[0].projectionMatrixChanged, true);
});
