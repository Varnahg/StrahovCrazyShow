/** Offline Ultra capture-map report. No game/browser/telemetry processes. */
import { readFile, stat, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve, dirname, relative, isAbsolute } from 'node:path';
import { fileURLToPath } from 'node:url';
import { assessFrameSample } from '../../shared/gameplay-acceptance.ts';
import { projectLocalBenchmark } from '../../shared/local-benchmark.ts';
import { createRenderPreferences, resolveVisualSettings } from '../../shared/render-quality.ts';

const HERE = dirname(fileURLToPath(import.meta.url));
const VARIANTS = [...'ABCDEFGH'], VIEWS = ['down', 'scenery'];
const expectedKeys = [1, 2, 3].flatMap(block => VARIANTS.flatMap(variant => VIEWS.map(view => `${block}/${variant}/${view}`)));
const finite = value => typeof value === 'number' && Number.isFinite(value);
const canonical = value => JSON.stringify(value, (_, v) => v && typeof v === 'object' && !Array.isArray(v)
  ? Object.fromEntries(Object.entries(v).sort(([a], [b]) => a.localeCompare(b))) : v);
const same = (a, b) => canonical(a) === canonical(b);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
export const median = values => {
  if (!values.length || values.some(v => !finite(v))) return null;
  const sorted = [...values].sort((a, b) => a - b), mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
};
const distribution = values => ({ count: values.length, median: median(values),
  min: values.length ? Math.min(...values) : null, max: values.length ? Math.max(...values) : null });
export function frameMetrics(frames) {
  // Actual HUD acceptance kernel owns p95/p99, max and >=50ms hitch semantics.
  const assessment = assessFrameSample(frames, { targetFps: 60 });
  return { assessment, metrics: assessment.metrics ? { ...assessment.metrics, medianMs: median(frames),
    stalls: Object.fromEntries([50, 100, 250, 1000].map(ms => [ms, frames.filter(v => v >= ms).length])) } : null };
}
export function expectedSettings(variant) {
  const low = resolveVisualSettings(createRenderPreferences('low', 60));
  if (variant === 'A') return low;
  if (variant === 'H') return resolveVisualSettings(createRenderPreferences('ultra', 60));
  const settings = { ...low, mode: 'custom', features: { ...low.features } };
  if (variant === 'B') { settings.renderScale = .5; settings.hardwareScaling = 2; }
  const change = { C: ['shadows', false], D: ['clouds', false], E: ['groundVegetation', false],
    F: ['trees', 'far-only'], G: ['postProcesses', true] }[variant];
  if (change) settings.features[change[0]] = change[1];
  return settings;
}
async function artifact(path, base, issues, label) {
  if (typeof path !== 'string' || !path) { issues.push(`${label}-path-missing`); return null; }
  const absolute = resolve(base, path);
  try {
    const before = await stat(absolute);
    if (before.size > 64 * 1024 * 1024) throw Error('over-64-MiB');
    const bytes = await readFile(absolute), after = await stat(absolute);
    if (before.size !== after.size || before.mtimeMs !== after.mtimeMs) throw Error('changed-during-read');
    return { path: absolute, bytes: bytes.length, sha256: sha(bytes), value: JSON.parse(bytes.toString('utf8')) };
  } catch (e) { issues.push(`${label}-unreadable:${e.code ?? e.message}`); return { path: absolute }; }
}
const provenance = a => a && { path: a.path, bytes: a.bytes ?? null, sha256: a.sha256 ?? null };
function numericRecord(value) {
  return Object.fromEntries(Object.entries(value ?? {}).filter(([, v]) => finite(v)));
}
function viewIdentity(view) {
  return view && { position: view.position, yaw: view.yaw, pitch: view.pitch, lightingInstant: view.lightingInstant,
    camera: view.camera && { position: view.camera.position, fov: view.camera.fov, minZ: view.camera.minZ,
      maxZ: view.camera.maxZ, viewMatrix: view.camera.viewMatrix } };
}
async function sample(row, line, base) {
  const issues = [], key = `${row?.block}/${row?.variant}/${row?.view}`;
  if (!row || !Number.isInteger(row.block) || ![1, 2, 3].includes(row.block) || !VARIANTS.includes(row.variant) || !VIEWS.includes(row.view))
    issues.push('invalid-slot');
  const server = await artifact(row?.serverPath, base, issues, 'server');
  const full = await artifact(row?.fullPath, base, issues, 'full');
  const envelope = server?.value, s = envelope?.benchmark, f = full?.value;
  const b = s ?? f;
  let projectedFull;
  if (f) try { projectedFull = projectLocalBenchmark(f); } catch { issues.push('full-projection-invalid'); }
  if (envelope && (!s || envelope.sourceSnapshotId !== s.sourceSnapshotId)) issues.push('server-envelope-source-mismatch');
  if (server?.value && !Number.isFinite(Date.parse(envelope.receivedAtUTC))) issues.push('server-receipt-missing');
  const result = frameMetrics(b?.frameIntervalsMs);
  if (!result.metrics) issues.push('invalid-frame-intervals');
  if (b && (!Number.isInteger(b.frames) || b.frames !== b.frameIntervalsMs?.length)) issues.push('frame-count-mismatch');
  if (result.metrics && (b?.p95FrameMs !== result.metrics.p95Ms || b?.p99FrameMs !== result.metrics.p99Ms)) issues.push('published-HUD-quantiles-mismatch');
  if (!finite(b?.durationSeconds) || b.durationSeconds < 10) issues.push('short-or-missing-duration');
  if (result.assessment.status === 'inconclusive') issues.push('incomplete-HUD-frame-sample');
  if (!/^[a-f0-9]{64}$/.test(b?.sourceSnapshotId ?? '')) issues.push('source-missing');
  if (b?.renderErrorCount !== 0 || b?.assetLoadErrorCount !== 0) issues.push('render-or-asset-error');
  if (b?.avatars !== 3) issues.push('population-not-three');
  if (!same(b?.viewport, { width: 1280, height: 720 })) issues.push('css-viewport-mismatch');
  if (!b?.sceneView?.camera || ![b.sceneView.yaw, b.sceneView.pitch, b.sceneView.lightingInstant].every(finite)) issues.push('view-identity-missing');
  const expected = expectedSettings(row?.variant), actual = b?.rendering;
  for (const name of ['mode', 'quality', 'targetFps', 'hardwareScaling', 'renderScale', 'features'])
    if (!same(actual?.[name], expected[name])) issues.push(`settings-mismatch:${name}`);
  if (actual?.graphicsApplying !== false || actual?.transitionPhase !== null) issues.push('settings-not-settled');
  if (!finite(b?.renderResolution?.width) || !finite(b?.renderResolution?.height)) issues.push('backbuffer-missing');
  if (!f?.renderHealth || f.renderHealth.valid !== true || f.renderHealth.start?.valid !== true ||
      f.renderHealth.end?.valid !== true || f.renderHealth.start.generation !== f.renderHealth.end.generation) issues.push('full-health-missing-or-invalid');
  if (!f?.compilation?.start || !f?.compilation?.end) issues.push('full-compilation-missing');
  if (!f?.weatherAtStart || !f?.weatherAtEnd) issues.push('full-weather-missing');
  else if (!same(f.weatherAtStart, f.weatherAtEnd)) issues.push('weather-changed-within-sample');
  if (s && projectedFull) for (const name of ['sourceSnapshotId', 'frames', 'frameIntervalsMs', 'rendering', 'sceneView', 'viewport', 'renderResolution', 'avatars'])
    if (!same(s[name], projectedFull[name])) issues.push(`server-full-mismatch:${name}`);
  return { line, key, block: row?.block, variant: row?.variant, view: row?.view, issues,
    artifacts: { server: provenance(server), full: provenance(full) }, receivedAtUTC: envelope?.receivedAtUTC ?? null,
    fullDate: f?.date ?? null, sourceHash: b?.sourceSnapshotId ?? null, metrics: result.metrics,
    recordedDurationSeconds: b?.durationSeconds ?? null,
    durationDifferenceMs: result.metrics && finite(b?.durationSeconds) ? b.durationSeconds * 1000 - result.metrics.durationMs : null,
    frameGate: result.assessment, actualSettings: actual ?? null, viewport: b?.viewport ?? null,
    renderResolution: b?.renderResolution ?? null, sceneView: b?.sceneView ?? null, gpuIdentity: b?.gpu ?? null,
    inventoryEnd: { drawCalls: b?.drawCalls ?? null, triangles: b?.triangles ?? null, triangleCountScope: b?.triangleCountScope ?? null,
      avatarLod: b?.avatarLod ?? null, renderCost: b?.renderCost ?? null, ambient: b?.ambient ?? null },
    cpuMeanMs: { frame: numericRecord(b?.frameBreakdownMs), engine: numericRecord(b?.engineCpuBreakdownMs) },
    gpuLastSample: { value: b?.frameWork ?? null, scope: 'Last available asynchronous sample, NOT an interval average; WebGPU main pass excludes other passes.' },
    fullOnly: { renderHealth: f?.renderHealth ?? null, compilation: f?.compilation ?? null,
      weatherAtStart: f?.weatherAtStart ?? null, weatherAtEnd: f?.weatherAtEnd ?? null } };
}
export async function createReport(mapPath) {
  const absolute = resolve(mapPath), mapBytes = await readFile(absolute), base = dirname(absolute);
  const samples = [], mapIssues = [];
  for (const [i, text] of mapBytes.toString('utf8').split(/\r?\n/).entries()) {
    if (!text.trim()) continue;
    let row;
    try { row = JSON.parse(text); } catch { mapIssues.push({ line: i + 1, reason: 'invalid-map-json' }); continue; }
    samples.push(await sample(row, i + 1, base));
  }
  const byKey = new Map(), artifacts = new Map();
  for (const s of samples) {
    const slots = byKey.get(s.key) ?? []; slots.push(s); byKey.set(s.key, slots);
    for (const kind of ['server', 'full']) {
      const digest = s.artifacts[kind]?.sha256;
      if (!digest) continue;
      const id = `${kind}:${digest}`, previous = artifacts.get(id);
      if (previous) { previous.issues.push(`reused-${kind}-artifact`); s.issues.push(`reused-${kind}-artifact`); }
      else artifacts.set(id, s);
    }
  }
  for (const slots of byKey.values()) if (slots.length > 1) for (const s of slots) s.issues.push('duplicate-slot');
  const sources = [...new Set(samples.map(s => s.sourceHash).filter(Boolean))];
  if (sources.length > 1) for (const s of samples) s.issues.push('mixed-campaign-source');
  for (const s of samples) s.evidenceComplete = s.issues.length === 0;
  const missing = expectedKeys.filter(key => !byKey.has(key));
  const groups = VARIANTS.flatMap(variant => VIEWS.map(view => {
    const rows = samples.filter(s => s.variant === variant && s.view === view);
    const valid = rows.filter(s => s.evidenceComplete);
    const metrics = Object.fromEntries(['medianMs', 'p95Ms', 'p99Ms', 'maxMs', 'averageFps', 'hitches', 'hitchFraction'].map(key =>
      [key, distribution(valid.map(s => s.metrics[key]))]));
    const cpu = {};
    for (const scope of ['frame', 'engine']) cpu[scope] = Object.fromEntries([...new Set(valid.flatMap(s => Object.keys(s.cpuMeanMs[scope])))].map(key =>
      [key, distribution(valid.map(s => s.cpuMeanMs[scope][key]).filter(finite))]));
    return { variant, view, sampleLines: rows.map(s => s.line), completeSamples: valid.length,
      metrics, cpuMeanMsAcrossSamples: cpu, drawCallsAtEnd: distribution(valid.map(s => s.inventoryEnd.drawCalls).filter(finite)),
      lodAndSettingsBySample: rows.map(s => ({ line: s.line, block: s.block, evidenceComplete: s.evidenceComplete,
        avatarLod: s.inventoryEnd.avatarLod, treeLod: s.inventoryEnd.renderCost?.vegetation?.treeDetailCounts ?? null,
        activeTreeMeshesByLod: s.inventoryEnd.renderCost?.inventory?.enabledTreeMeshesByLod ?? null,
        actualSettings: s.actualSettings, renderResolution: s.renderResolution })) };
  }));
  const comparability = expectedKeys.map(key => {
    const [block, variant, view] = key.split('/'), s = byKey.get(key)?.[0], baseline = byKey.get(`${block}/A/${view}`)?.[0];
    if (!s?.evidenceComplete || !baseline?.evidenceComplete) return { key, reference: `${block}/A/${view}`, issues: ['missing-or-invalid-reference'] };
    const issues = [];
    if (!same(viewIdentity(s.sceneView), viewIdentity(baseline.sceneView))) issues.push('view-or-lighting-differs-exactly');
    if (!same(s.fullOnly.weatherAtEnd, baseline.fullOnly.weatherAtEnd)) issues.push('weather-differs-exactly');
    if (!same(s.gpuIdentity, baseline.gpuIdentity)) issues.push('gpu-identity-differs');
    return { key, reference: `${block}/A/${view}`, issues,
      projectionMatrixChanged: !same(s.sceneView?.camera?.projectionMatrix, baseline.sceneView?.camera?.projectionMatrix),
      projectionScope: 'Retained separately: render scale can change rounded backbuffer aspect and LOD; not an invented camera-pose tolerance.' };
  });
  const pairs = [1, 2, 3].map(block => {
    const low = byKey.get(`${block}/A/scenery`)?.[0], ultra = byKey.get(`${block}/H/scenery`)?.[0], issues = [];
    if (!low?.evidenceComplete || !ultra?.evidenceComplete) issues.push('missing-or-invalid-pair');
    if (low && ultra) {
      if (!same(viewIdentity(low.sceneView), viewIdentity(ultra.sceneView))) issues.push('view-or-lighting-differs-exactly');
      if (!same(low.fullOnly.weatherAtEnd, ultra.fullOnly.weatherAtEnd)) issues.push('weather-differs-exactly');
      if (!same(low.gpuIdentity, ultra.gpuIdentity)) issues.push('gpu-identity-differs');
    }
    return { block, lowLine: low?.line ?? null, ultraLine: ultra?.line ?? null, issues,
      medianImprovementFraction: low?.metrics && ultra?.metrics ? 1 - ultra.metrics.medianMs / low.metrics.medianMs : null,
      p99ChangeMs: low?.metrics && ultra?.metrics ? ultra.metrics.p99Ms - low.metrics.p99Ms : null,
      projectionMatrixChanged: low && ultra ? !same(low.sceneView?.camera?.projectionMatrix, ultra.sceneView?.camera?.projectionMatrix) : null };
  });
  const allPairs = pairs.every(p => !p.issues.length);
  const a = groups.find(g => g.variant === 'A' && g.view === 'scenery'), h = groups.find(g => g.variant === 'H' && g.view === 'scenery');
  const improvement = a.completeSamples === 3 && h.completeSamples === 3
    ? 1 - h.metrics.medianMs.median / a.metrics.medianMs.median : null;
  const p99Worse = pairs.filter(p => !p.issues.length && p.p99ChangeMs > 0).map(p => p.block);
  return { schemaVersion: 1, map: { path: absolute, sha256: sha(mapBytes) },
    scope: 'Three interleaved blocks in one settled session; not three independent cold starts. Offline observations, no optimization/gameplay approval.',
    quantiles: 'p95/p99/max/hitches from actual assessFrameSample HUD helper; median averages middle pair for even N. Group distributions summarize per-sample values, never average or pool p99.',
    coverage: { expected: 48, rows: samples.length, listedSlots: expectedKeys.filter(k => byKey.has(k)).length,
      evidenceCompleteSlots: expectedKeys.filter(k => byKey.get(k)?.length === 1 && byKey.get(k)[0].evidenceComplete).length,
      missing, partialOrInvalid: samples.filter(s => !s.evidenceComplete).map(s => ({ line: s.line, key: s.key, issues: s.issues })),
      complete: !mapIssues.length && missing.length === 0 && samples.length === 48 && samples.every(s => s.evidenceComplete) },
    mapIssues, sourceHashes: sources, samples, groups, comparability,
    ultraVsLowScenery: { pairs, medianImprovementFraction: improvement, requiredImprovementFraction: .2,
      medianCriterion: improvement === null || !allPairs ? 'inconclusive' : improvement >= .2 ? 'met' : 'not-met',
      p99WorseBlocks: p99Worse,
      p99Conclusion: !allPairs ? 'inconclusive' : p99Worse.length ? 'adjudication-required-no-repeatability-threshold-specified' : 'no-observed-p99-regression',
      optimizationAccepted: false,
      remainingEvidence: ['Confirm visible stable intervals and unchanged settings from raw session.', 'System telemetry alignment and environmental comparability.',
        'Visual/functional checks and independent movement/network gameplay gate.', 'Adjudicate any p99 worsening without inventing a repeatability threshold.'] } };
}
async function main() {
  const [map, output, ...extra] = process.argv.slice(2);
  if (!map || extra.length) throw Error('Usage: node --import ./node_modules/tsx/dist/loader.mjs .cache/ultra-report-20261104/report.mjs capture-map.jsonl [new-report.json]');
  const report = await createReport(map), text = JSON.stringify(report, null, 2) + '\n';
  if (output) {
    const target = resolve(output), inside = relative(HERE, target);
    if (!inside || inside.startsWith('..') || isAbsolute(inside)) throw Error('Output must be within .cache/ultra-report-20261104');
    await writeFile(target, text, { flag: 'wx' });
    console.log(JSON.stringify({ output: target, coverage: report.coverage, ultraVsLowScenery: report.ultraVsLowScenery }));
  } else process.stdout.write(text);
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) await main();
