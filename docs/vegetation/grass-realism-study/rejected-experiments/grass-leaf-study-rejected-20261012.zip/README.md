# Individual photographic leaves — isolated review candidate

This is a separate experiment following the rejected four-card cluster. Nothing here modifies runtime, source photographs or the authored highest master.

Each of the 42 highest leaves is projected **alone** using its existing original photographic UVs. The local plane passes through the actual source root and tip centres. The transverse direction minimizes squared distance of original vertices to the plane. Original leaf roots, dimensions and orientation remain in the same metre-based macroblock. The atlas uses uniform geometric scaling per cell, not nonuniform stretching. Blender's actual orthographic frame/aspect is asserted before rendering.

The single Cycles CPU bake uses four threads, a 1024×512 atlas, eight samples, no denoising, and three unlit data-transfer passes: albedo+alpha, normal+alpha and roughness+alpha. Original alpha is tested at 0.45. `leaf-bake-report.json` retains source hashes and per-leaf geometry measurements. The actual render passes took roughly 3.3 seconds; completion including after-source hash verification took about 7 seconds. The Blender process is finished.

`prepare-leaves.py` derives two representations from those same photographs:

- **84 triangles / macroblock:** one image plane per leaf.
- **168 triangles / macroblock:** two segments per leaf, bent through the source middle point while keeping root and tip centres fixed. Baked normal vectors are transformed into each actual segment's tangent basis, preserving their intended world direction under PBR lighting.

Maximum source-vertex plane distance is 3.480 mm for flat leaves; maximum residual against the current two-segment fit is 3.375 mm. These global maxima do not imply every leaf has that error. Root/tip centres are exact; basal edges, fold and twist retain separately measured approximation error. The first prototype intentionally tests this simple fit before investing in a more elaborate atlas or fitting pipeline.

## Review

`http://127.0.0.1:4197/` compares both candidates at 160 roots/m² (13,440 or 26,880 triangles) with unchanged highest geometry at the same 160 roots and with current runtime LOD quotas. Camera presets, procedural ground, day/night lights and source material recipe are shared. Final materials are lit PBR, alpha cutoff 0.45, source F0/translucency, metallic zero, AO disabled and **emission zero**. Source geometry uses original provider 1k maps; derived leaf atlases come from original 8k photographic maps.

The rejected cluster remains on 4196 and in its original cache directory. No appearance or client-FPS acceptance is claimed by this preview. Root owns the practical GPU review. Further alpha-union/silhouette measurements follow the first visual comparison.
