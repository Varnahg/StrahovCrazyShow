import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
const directory=import.meta.dirname,root=path.resolve(directory,'../..');
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json','.png':'image/png','.jpg':'image/jpeg'};
http.createServer((request,response)=>{
 if(request.method!=='GET'&&request.method!=='HEAD'){response.writeHead(405);response.end();return;}
 let url;try{url=decodeURIComponent(new URL(request.url,'http://localhost').pathname);}catch{response.writeHead(400);response.end();return;}
 let file;if(url==='/source-pack.json')file=path.join(root,'assets/sources/vegetation/grass_medium_01/derived/grass-uv-aware-render-pack.json');else if(url==='/source-material.json')file=path.join(root,'public/models/vegetation/grass/material.json');else if(url.startsWith('/source-textures/'))file=path.join(root,'public/textures/vegetation/grass',path.basename(url));else if(url.startsWith('/ground/'))file=path.join(root,'public/textures/surfaces',path.basename(url));else file=path.join(directory,url==='/'?'index.html':path.basename(url));
 if(!mime[path.extname(file)]||!fs.existsSync(file)||!fs.statSync(file).isFile()){response.writeHead(404);response.end('Not found');return;}
 response.writeHead(200,{'content-type':mime[path.extname(file)],'cache-control':'no-store'});if(request.method==='HEAD'){response.end();return;}fs.createReadStream(file).pipe(response);
}).listen(4197,'127.0.0.1',()=>console.log('Cache individual leaf study http://127.0.0.1:4197/ · static only'));


