import "../../client/render-shaders";
import "@babylonjs/core/Meshes/thinInstanceMesh";
import {Engine} from "@babylonjs/core/Engines/engine";
import {Scene} from "@babylonjs/core/scene";
import {ArcRotateCamera} from "@babylonjs/core/Cameras/arcRotateCamera";
import {Vector3,Matrix,Quaternion} from "@babylonjs/core/Maths/math.vector";
import {Color3,Color4} from "@babylonjs/core/Maths/math.color";
import {Mesh} from "@babylonjs/core/Meshes/mesh";
import {MeshBuilder} from "@babylonjs/core/Meshes/meshBuilder";
import {VertexData} from "@babylonjs/core/Meshes/mesh.vertexData";
import {PBRMaterial} from "@babylonjs/core/Materials/PBR/pbrMaterial";
import {Material} from "@babylonjs/core/Materials/material";
import {Texture} from "@babylonjs/core/Materials/Textures/texture";
import {HemisphericLight} from "@babylonjs/core/Lights/hemisphericLight";
import {DirectionalLight} from "@babylonjs/core/Lights/directionalLight";
import {configureSourceGrassMaterial} from "../../client/photo-grass-source-material";


const canvas=document.querySelector<HTMLCanvasElement>("#view")!,report=document.querySelector<HTMLElement>("#report")!;
const select=(id:string)=>document.querySelector<HTMLSelectElement>("#"+id)!;
const params=new URLSearchParams(location.search);
for(const id of ["representation","camera","light"]){const value=params.get(id);if(value&&Array.from(select(id).options).some(option=>option.value===value))select(id).value=value;}
const engine=new Engine(canvas,true,{powerPreference:"high-performance",preserveDrawingBuffer:true,stencil:true});
const scene=new Scene(engine);scene.useRightHandedSystem=true;
const camera=new ArcRotateCamera("shared comparison camera",-Math.PI/2,.85,2.5,new Vector3(0,.02,0),scene);camera.minZ=.01;camera.lowerRadiusLimit=.18;camera.upperRadiusLimit=8;camera.wheelPrecision=80;camera.attachControl(canvas,true);
scene.imageProcessingConfiguration.exposure=1;scene.imageProcessingConfiguration.contrast=1;scene.imageProcessingConfiguration.toneMappingEnabled=false;
const key=new DirectionalLight("same key light",new Vector3(.4,-1,.25),scene),ambient=new HemisphericLight("same hemisphere",Vector3.Up(),scene);
const errors:string[]=[];engine.onEffectErrorObservable.add(error=>{errors.push(String(error));console.error(error);});window.addEventListener("error",event=>errors.push(event.message));
const texturePending:Promise<void>[]=[];const textures=new Map<string,Texture>();
function texture(url:string,gamma:boolean){
 const old=textures.get(url);if(old)return old;
 let resolve!:()=>void,reject!:(error:Error)=>void;texturePending.push(new Promise<void>((yes,no)=>{resolve=yes;reject=no;}));
 const result=new Texture(url,scene,false,false,Texture.TRILINEAR_SAMPLINGMODE,resolve,message=>{errors.push(message??url);reject(Error(message??url));});result.gammaSpace=gamma;result.anisotropicFilteringLevel=4;result.wrapU=result.wrapV=Texture.CLAMP_ADDRESSMODE;textures.set(url,result);return result;
}
async function json(url:string){const result=await fetch(url);if(!result.ok)throw Error(url+": HTTP "+result.status);return result.json();}
const [manifest,pack,recipe,pointset]=await Promise.all([json("/leaf-manifest.json"),json("/source-pack.json"),json("/source-material.json"),json("/points.json")]);
const sourceMaps={albedo:texture("/source-textures/grass_medium_01_diff_1k.jpg",true),alpha:texture("/source-textures/grass_medium_01_alpha_1k.png",false),normal:texture("/source-textures/grass_medium_01_nor_gl_1k.jpg",false),arm:texture("/source-textures/grass_medium_01_arm_1k.jpg",false)};
const cardMaps={albedo:texture("/leaves-albedo.png",true),alpha:texture("/leaves-alpha.png",false),normal:texture("/leaves-normal.png",false),arm:texture("/leaves-arm.png",false)};
const bentMaps={...cardMaps,normal:texture("/leaves-normal-bent.png",false)};
const bentMaterial=new PBRMaterial("Bent source photographic leaves — zero emission",scene);configureSourceGrassMaterial(bentMaterial,bentMaps,recipe,"author-material");
const sourceMaterial=new PBRMaterial("unchanged source photographic PBR",scene),cardMaterial=new PBRMaterial("derived projected photographic PBR — zero emission",scene);
configureSourceGrassMaterial(sourceMaterial,sourceMaps,recipe,"author-material");configureSourceGrassMaterial(cardMaterial,cardMaps,recipe,"author-material");
const points=pointset.points as {x:number;z:number;yaw:number}[];
const matrices=new Float32Array(points.length*16);for(const [i,p] of points.entries())Matrix.Compose(Vector3.One(),Quaternion.RotationYawPitchRoll(p.yaw,0,0),new Vector3(p.x,.0025,p.z)).copyToArray(matrices,i*16);
const meshes=new Map<string,Mesh>();
function model(id:string,g:{positions:number[];normals:number[];uvs:number[];indices:number[]},material:PBRMaterial,count:number){
 const mesh=new Mesh(id,scene),data=new VertexData();data.positions=g.positions;data.normals=g.normals;data.uvs=g.uvs;data.indices=g.indices;data.applyToMesh(mesh);mesh.material=material;mesh.sideOrientation=Material.CounterClockWiseSideOrientation;mesh.isPickable=false;mesh.thinInstanceSetBuffer("matrix",matrices,16,true);mesh.thinInstanceCount=count;mesh.thinInstanceRefreshBoundingInfo(true);mesh.setEnabled(false);meshes.set(id,mesh);
}
model("near",pack.levels.near,sourceMaterial,10);model("medium",pack.levels.medium,sourceMaterial,52);model("far",pack.levels.far,sourceMaterial,145);model("highest",pack.levels.highest,sourceMaterial,160);
model("flat",manifest.geometries.flat,cardMaterial,160);model("bent",manifest.geometries.bent,bentMaterial,160);
const groundMaterial=new PBRMaterial("same ambientCG procedural Grass001 ground",scene);groundMaterial.albedoTexture=texture("/ground/Grass001_1K-JPG_Color.jpg",true);groundMaterial.bumpTexture=texture("/ground/Grass001_1K-JPG_NormalGL.jpg",false);groundMaterial.bumpTexture.level=.3;groundMaterial.metallicTexture=texture("/ground/Grass001_1K-JPG_Roughness.jpg",false);groundMaterial.metallic=0;groundMaterial.roughness=1;groundMaterial.useRoughnessFromMetallicTextureAlpha=false;groundMaterial.useRoughnessFromMetallicTextureGreen=true;groundMaterial.useMetallnessFromMetallicTextureBlue=false;groundMaterial.emissiveColor=Color3.Black();groundMaterial.specularIntensity=.27;
const ground=MeshBuilder.CreateGround("same one-metre comparison ground",{width:1,height:1},scene);ground.material=groundMaterial;
const rulerMaterial=new PBRMaterial("neutral 10cm ruler",scene);rulerMaterial.albedoColor=Color3.FromHexString("#cbc7b5").toLinearSpace();rulerMaterial.metallic=0;rulerMaterial.roughness=.8;
const ruler=MeshBuilder.CreateBox("10cm height reference",{width:.003,height:.1,depth:.003},scene);ruler.position.set(.53,.05,0);ruler.material=rulerMaterial;
for(const y of [0,.05,.1]){const tick=MeshBuilder.CreateBox("5cm tick",{width:.025,height:.002,depth:.003},scene);tick.position.set(.53,y,0);tick.material=rulerMaterial;}
function representation(){for(const [id,mesh] of meshes)mesh.setEnabled(id===select("representation").value);}
function lighting(){const night=select("light").value==="night";key.intensity=night?.07:2;key.diffuse=night?new Color3(.65,.73,1):Color3.White();ambient.intensity=night?.035:.7;ambient.diffuse=night?new Color3(.6,.67,.88):new Color3(.83,.89,1);ambient.groundColor=new Color3(.08,.07,.055);scene.clearColor=night?new Color4(.012,.018,.028,1):new Color4(.23,.30,.33,1);}
function viewpoint(){camera.alpha=-Math.PI/2;camera.target.set(0,.02,0);const mode=select("camera").value;camera.beta=mode==="top"?.02:mode==="grazing"?1.43:mode==="close"?1.18:.85;camera.radius=mode==="top"?1.55:mode==="grazing"?1.15:mode==="close"?.75:2.5;}
select("representation").addEventListener("change",representation);select("light").addEventListener("change",lighting);select("camera").addEventListener("change",viewpoint);
document.querySelector<HTMLInputElement>("#ground")!.addEventListener("change",event=>ground.setEnabled((event.target as HTMLInputElement).checked));
document.querySelector<HTMLInputElement>("#normals")!.addEventListener("change",event=>{const enabled=(event.target as HTMLInputElement).checked;sourceMaterial.bumpTexture=enabled?sourceMaps.normal:null;cardMaterial.bumpTexture=enabled?cardMaps.normal:null;bentMaterial.bumpTexture=enabled?bentMaps.normal:null;});
document.querySelector("#rotate")!.addEventListener("click",()=>camera.alpha+=Math.PI/3);document.querySelector("#reset")!.addEventListener("click",viewpoint);
representation();lighting();viewpoint();let mapsReady=false;Promise.all(texturePending).then(()=>mapsReady=true).catch(error=>errors.push(String(error)));
let lastReport=0;engine.runRenderLoop(()=>{scene.render();const now=performance.now();if(now-lastReport<250)return;lastReport=now;const mesh=meshes.get(select("representation").value)!;const ready=mapsReady&&scene.isReady();canvas.dataset.ready=String(ready);canvas.dataset.errorCount=String(errors.length);
 const stats={ready,representation:select("representation").value,light:select("light").value,internal:[engine.getRenderWidth(),engine.getRenderHeight()],CSS:[canvas.clientWidth,canvas.clientHeight],grassDraws:1,instances:mesh.thinInstanceCount,triangles:mesh.getTotalIndices()/3*mesh.thinInstanceCount,camera:{position:camera.position.asArray(),target:camera.target.asArray(),alpha:camera.alpha,beta:camera.beta,radius:camera.radius},emission:cardMaterial.emissiveColor.asArray(),alphaCutoff:cardMaterial.alphaCutOff,atlas:[1024,512],sourceMaster:manifest.masterSha256,sourceGeometry:manifest.runtimeGeometrySha256,errors};report.textContent=JSON.stringify(stats,null,2);
});
window.addEventListener("resize",()=>engine.resize());window.addEventListener("pagehide",()=>{engine.stopRenderLoop();scene.dispose();engine.dispose();},{once:true});

