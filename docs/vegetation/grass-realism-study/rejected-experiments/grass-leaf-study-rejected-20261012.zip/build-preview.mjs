import {createRequire} from 'node:module';
import {resolve} from 'node:path';
const require=createRequire(import.meta.resolve('tsx'));
await require('esbuild').build({entryPoints:[resolve(import.meta.dirname,'preview.ts')],outfile:resolve(import.meta.dirname,'preview.js'),bundle:true,platform:'browser',format:'esm',target:'es2022',sourcemap:false,minify:false});
console.log('Cache-only comparison bundle built. No GPU scene opened.');
