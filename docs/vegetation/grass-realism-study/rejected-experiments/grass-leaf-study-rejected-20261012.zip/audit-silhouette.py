"""Source and actual candidate alpha unions in identical diagnostic cameras."""
from pathlib import Path
import sys,json,math,time,hashlib
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'.cache/street-python'))
import numpy as np
from PIL import Image
pack=json.loads((ROOT/'public/models/vegetation/grass/geometry.json').read_text(encoding='utf8'))
manifest=json.loads((OUT/'leaf-manifest.json').read_text(encoding='utf8'))
source_alpha=np.asarray(Image.open(ROOT/'public/textures/vegetation/grass/grass_medium_01_alpha_1k.png')).astype(float)/65535
candidate_alpha=np.asarray(Image.open(OUT/'leaves-alpha.png').convert('RGBA'))[:,:,0].astype(float)/255
models={'highest':pack['levels']['highest'],'flat':manifest['geometries']['flat'],'bent':manifest['geometries']['bent']}
resolution=512
def sample(image,u,v):
 h,w=image.shape;px=np.clip(u*w-.5,0,w-1);py=np.clip(v*h-.5,0,h-1);x0=np.floor(px).astype(int);y0=np.floor(py).astype(int);fx=px-x0;fy=py-y0;x1=np.minimum(x0+1,w-1);y1=np.minimum(y0+1,h-1)
 return (image[y0,x0]*(1-fx)+image[y0,x1]*fx)*(1-fy)+(image[y1,x0]*(1-fx)+image[y1,x1]*fx)*fy
def raster(g,alpha,right,up,centre,span):
 positions=np.array(g['positions']).reshape(-1,3);uvs=np.array(g['uvs']).reshape(-1,2);triangles=np.array(g['indices']).reshape(-1,3);projected=np.stack((positions@right,positions@up),axis=1);screen=((projected-centre)/span+.5)*resolution-.5;mask=np.zeros((resolution,resolution),dtype=bool)
 for triangle in triangles:
  a,b,c=screen[triangle];minimum=np.maximum(0,np.ceil(np.minimum(np.minimum(a,b),c)).astype(int));maximum=np.minimum(resolution-1,np.floor(np.maximum(np.maximum(a,b),c)).astype(int))
  if np.any(maximum<minimum):continue
  den=(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
  if abs(den)<1e-12:continue
  x,y=np.meshgrid(np.arange(minimum[0],maximum[0]+1),np.arange(minimum[1],maximum[1]+1));v=((x-a[0])*(c[1]-a[1])-(y-a[1])*(c[0]-a[0]))/den;w=((b[0]-a[0])*(y-a[1])-(b[1]-a[1])*(x-a[0]))/den;u=1-v-w
  uv=u[:,:,None]*uvs[triangle[0]]+v[:,:,None]*uvs[triangle[1]]+w[:,:,None]*uvs[triangle[2]];hit=(u>=0)&(v>=0)&(w>=0)&(sample(alpha,uv[:,:,0],uv[:,:,1])>=.45);mask[minimum[1]:maximum[1]+1,minimum[0]:maximum[0]+1]|=hit
 return mask
results=[];started=time.time()
for label,phi,theta in [('eye',math.pi,.85),('close',math.pi,1.18),('rotated-eye',math.pi+math.pi/3,.85),('top',math.pi,.02)]:
 normal=np.array([math.sin(phi)*math.sin(theta),math.cos(theta),math.cos(phi)*math.sin(theta)]);right=np.cross([0,1,0],normal);right/=np.linalg.norm(right);up=np.cross(normal,right)
 allp=np.concatenate([np.array(g['positions']).reshape(-1,3) for g in models.values()]);allxy=np.stack((allp@right,allp@up),axis=1);minimum=allxy.min(axis=0);maximum=allxy.max(axis=0);centre=(minimum+maximum)/2;span=float(max(maximum-minimum)+.004)
 masks={name:raster(g,source_alpha if name=='highest' else candidate_alpha,right,up,centre,span) for name,g in models.items()};source=masks['highest'];rows=[]
 for name,mask in masks.items():
  intersection=source&mask;union=source|mask;area=float(mask.mean()*span*span);triangles=models[name]['triangles']
  rows.append({'representation':name,'triangles':triangles,'trueAlphaUnionSquareMetres':area,'acceptedPixels':int(mask.sum()),'squareMetresUnionPerSubmittedTriangle':area/triangles,'intersectionOverUnionAgainstHighest':float(intersection.sum()/max(1,union.sum())),'falsePositivePixels':int((mask&~source).sum()),'falseNegativePixels':int((source&~mask).sum())})
  Image.fromarray(np.flipud(mask.astype(np.uint8)*255),'L').save(OUT/('alpha-'+label+'-'+name+'.png'))
  if name!='highest':Image.fromarray(np.flipud(np.stack([mask.astype(np.uint8)*255,source.astype(np.uint8)*255,np.zeros_like(mask,dtype=np.uint8)],axis=2)),'RGB').save(OUT/('difference-'+label+'-'+name+'.png'))
 results.append({'camera':label,'projection':'orthographic directional diagnostic, not a recreation of the perspective screenshot','viewNormal':normal.tolist(),'right':right.tolist(),'up':up.tolist(),'physicalWidthHeightMetres':span,'rows':rows})
report={'timestampUTC':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'resolution':[resolution,resolution],'alphaCutoff':.45,'method':'For each shared camera, rasterize every source or derived triangle, interpolate actual texture UV, bilinear sample original16bit or derived8bit alpha, then boolean-OR accepted pixels. One macroblock with the same42 source leaves; no area sums, no artificial lighting.','manifestSha256':hashlib.sha256((OUT/'leaf-manifest.json').read_bytes()).hexdigest(),'cameras':results,'seconds':time.time()-started,'scope':'CPU silhouette/alpha union only. No GPU performance or final appearance acceptance.'}
(OUT/'silhouette-alpha-union.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8');print(json.dumps({'seconds':report['seconds'],'cameras':[{'camera':r['camera'],'rows':r['rows']} for r in results]},indent=2))
