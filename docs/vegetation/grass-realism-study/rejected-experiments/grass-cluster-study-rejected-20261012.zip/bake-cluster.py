"""Cache-only, source-audited photographic lawn impostor study.

No source master or image is saved/edited. Emission is a data-transfer pass,
never the runtime material. Runtime uses albedo, tangent normals and roughness.
"""
import bpy, json, math, hashlib, sys, time
from pathlib import Path
from mathutils import Vector

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
BASE=ROOT/'assets/sources/vegetation/grass_medium_01'
MASTER=BASE/'derived/grass-authored-v2-study.blend'
PACK=ROOT/'public/models/vegetation/grass/geometry.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
immutable=[p for p in BASE.rglob('*') if p.is_file()]
before={str(p.relative_to(ROOT)):sha(p) for p in immutable}
expected=json.loads((BASE/'authored-v2-reopen-audit.json').read_text(encoding='utf8'))
assert sha(MASTER)==expected['blendSha256']
source=json.loads((BASE/'derived/grass-authored-v2-study.json').read_text(encoding='utf8'))
pack=json.loads(PACK.read_text(encoding='utf8'));g=pack['levels']['highest']
assert pack['sourceBlendSha256']==sha(MASTER)
assert pack['sourceGeometrySha256']==sha(BASE/'derived/grass-authored-v2-study.json')
bpy.ops.wm.open_mainfile(filepath=str(MASTER))
objects=[];max_vertex=0.;max_uv=0.;source_positions=[];source_normals=[]
for index,tuft in enumerate(source['tufts']):
 obj=bpy.data.objects[tuft['id']]
 assert tuple(obj.scale)==(1.,1.,1.) and all(abs(v)<1e-9 for v in obj.rotation_euler)
 assert abs(obj.location.x-(index-1)*.14)<1e-7 and abs(obj.location.y)<1e-7 and abs(obj.location.z)<1e-7
 assert len(obj.data.polygons)==tuft['triangles']
 for i,vertex in enumerate(obj.data.vertices):
  p=tuft['positions'][i*3:i*3+3];expected_vertex=(p[0],-p[2],p[1]);max_vertex=max(max_vertex,max(abs(vertex.co[j]-expected_vertex[j]) for j in range(3)))
 for loop in obj.data.loops:
  uv=tuft['uvs'][loop.vertex_index*2:loop.vertex_index*2+2];actual=obj.data.uv_layers.active.data[loop.index].uv
  max_uv=max(max_uv,abs(actual[0]-uv[0]),abs(actual[1]-(1-uv[1])))
 objects.append({'name':obj.name,'location':list(obj.location),'rotation':list(obj.rotation_euler),'scale':list(obj.scale),'triangles':len(obj.data.polygons),'editableLeaves':len(obj.vertex_groups)})
 source_positions.extend(tuft['positions']);source_normals.extend(tuft['normals'])
assert max_vertex<1e-7 and max_uv<1e-7
assert g['triangles']==5376 and len(g['leaves'])==42
max_export_error=0.
for leaf in g['leaves']:
 translation=pack['leafTransforms'][leaf['sourceLeafId']]['translation']
 for i in range(leaf['vertexStart'],leaf['vertexStart']+leaf['vertexCount']):
  source_index=g['sourceVertexIndices'][i]
  for axis in range(3):
   max_export_error=max(max_export_error,abs(g['positions'][i*3+axis]-(source_positions[source_index*3+axis]+translation[axis])))
assert max_export_error<1e-12
materials=[];links=[]
for mat in bpy.data.materials:
 if not mat.use_nodes:continue
 groups=[n for n in mat.node_tree.nodes if n.type=='GROUP']
 materials.append({'name':mat.name,'groups':[{'name':n.name,'inputs':{p.name:p.default_value for p in n.inputs if p.name in ['Translucency','Specular IOR Level','IOR','Hue','Saturation','Value','Dead Amount','Wetness'] and hasattr(p,'default_value') and isinstance(p.default_value,(float,int))}} for n in groups]})
for image in bpy.data.images:
 if image.source!='FILE':continue
 p=Path(bpy.path.abspath(image.filepath));assert p.is_file(),str(p)
 links.append({'name':image.name,'path':str(p.relative_to(ROOT)),'colorspace':image.colorspace_settings.name,'sha256':sha(p)})
audit={'timestampUTC':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'sourceURL':'https://polyhaven.com/a/grass_medium_01','license':'CC0-1.0','sourcePhotoUnchanged':True,'masterSha256':sha(MASTER),'runtimeGeometrySha256':sha(PACK),'actualMasterOpened':True,'objects':objects,'materialGraph':materials,'imageLinks':links,'maximumMasterVertexErrorMetres':max_vertex,'maximumMasterUVError':max_uv,'maximumRedistributedHighestExportErrorMetres':max_export_error,'highestTriangles':g['triangles'],'leaves':len(g['leaves']),'interpretation':'Four orthographic image planes of exactly the source-UV authored highest leaves after the existing documented whole-leaf root redistribution. Not a local Strahov survey.','scope':'cache only; no runtime integration or visual/FPS acceptance'}
(OUT/'source-inspection.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf8')
print('SOURCE_INSPECTION_PASS',json.dumps({'objects':len(objects),'triangles':g['triangles'],'maxVertex':max_vertex,'maxUV':max_uv,'master':sha(MASTER)}),flush=True)
if '--inspect' in sys.argv:sys.exit(0)

# Leave original objects/data untouched, merely hide them for the isolated bake.
for obj in list(bpy.context.scene.objects):obj.hide_render=True
scene=bpy.context.scene
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=8;scene.cycles.use_denoising=False
scene.cycles.use_adaptive_sampling=False;scene.cycles.max_bounces=1;scene.cycles.transparent_max_bounces=64
scene.render.threads_mode='FIXED';scene.render.threads=4
scene.render.resolution_x=240;scene.render.resolution_y=240;scene.render.resolution_percentage=100
scene.render.film_transparent=True;scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGBA';scene.render.image_settings.color_depth='8'
scene.view_settings.view_transform='Standard';scene.view_settings.look='None';scene.view_settings.exposure=0;scene.view_settings.gamma=1
if not scene.world:scene.world=bpy.data.worlds.new('Unlit data transfer world')
scene.world.color=(0.,0.,0.)
mesh=bpy.data.meshes.new('exact redistributed authored-v2 highest cluster')
positions=[(g['positions'][i],-g['positions'][i+2],g['positions'][i+1]) for i in range(0,len(g['positions']),3)]
mesh.from_pydata(positions,[],[g['indices'][i:i+3] for i in range(0,len(g['indices']),3)]);mesh.update()
uv_layer=mesh.uv_layers.new(name='Unmodified original photograph UV')
for loop in mesh.loops:
 i=loop.vertex_index;uv_layer.data[loop.index].uv=(g['uvs'][i*2],1-g['uvs'][i*2+1])
mesh.normals_split_custom_set_from_vertices([(g['normals'][i],-g['normals'][i+2],g['normals'][i+1]) for i in range(0,len(g['normals']),3)])
obj=bpy.data.objects.new('cluster data projection source',mesh);scene.collection.objects.link(obj)

material=bpy.data.materials.new('data transfer only — no illumination');material.use_nodes=True
nodes=material.node_tree.nodes;nodes.clear();tree=material.node_tree
output=nodes.new('ShaderNodeOutputMaterial');mix=nodes.new('ShaderNodeMixShader');transparent=nodes.new('ShaderNodeBsdfTransparent');emission=nodes.new('ShaderNodeEmission')
tree.links.new(mix.outputs[0],output.inputs['Surface']);tree.links.new(transparent.outputs[0],mix.inputs[1]);tree.links.new(emission.outputs[0],mix.inputs[2]);emission.inputs['Strength'].default_value=1
def image_node(filename,colorspace):
 p=BASE/'source-highest/textures'/filename;image=bpy.data.images.load(str(p),check_existing=True);image.colorspace_settings.name=colorspace
 node=nodes.new('ShaderNodeTexImage');node.image=image;node.interpolation='Linear';return node
color=image_node('grass_medium_01_diff_8k.jpg','sRGB')
alpha=image_node('grass_medium_01_alpha_8k.png','Non-Color')
normal=image_node('grass_medium_01_nor_gl_8k.exr','Non-Color')
rough=image_node('grass_medium_01_rough_8k.exr','Non-Color')
cutoff=nodes.new('ShaderNodeMath');cutoff.operation='GREATER_THAN';cutoff.inputs[1].default_value=.45;tree.links.new(alpha.outputs['Color'],cutoff.inputs[0]);tree.links.new(cutoff.outputs[0],mix.inputs[0])
normal_map=nodes.new('ShaderNodeNormalMap');normal_map.space='TANGENT';normal_map.uv_map=uv_layer.name;normal_map.inputs['Strength'].default_value=1;tree.links.new(normal.outputs['Color'],normal_map.inputs['Color'])
mesh.materials.append(material)
camera_data=bpy.data.cameras.new('orthographic source projection');camera_data.type='ORTHO';camera_data.clip_start=.01;camera_data.clip_end=10
camera=bpy.data.objects.new('orthographic source projection',camera_data);scene.collection.objects.link(camera);scene.camera=camera
xs=[p[0] for p in positions];ys=[p[1] for p in positions];zs=[p[2] for p in positions]
centre=Vector(((min(xs)+max(xs))/2,(min(ys)+max(ys))/2,(min(zs)+max(zs))/2))
views=[];started=time.time()
for index,azimuth in enumerate([0,math.pi/3,2*math.pi/3,None]):
 view='top' if azimuth is None else 'side-'+str(index)
 normal_axis=Vector((0,0,1)) if azimuth is None else Vector((math.sin(azimuth),-math.cos(azimuth),0))
 camera.location=centre+normal_axis*.5;camera.rotation_euler=(centre-camera.location).to_track_quat('-Z','Y').to_euler();bpy.context.view_layer.update()
 right=camera.matrix_world.to_3x3()@Vector((1,0,0));up=camera.matrix_world.to_3x3()@Vector((0,1,0))
 projected=[((Vector(p)-centre).dot(right),(Vector(p)-centre).dot(up)) for p in positions]
 span=max(max(abs(p[0]) for p in projected),max(abs(p[1]) for p in projected))*2+.008
 camera_data.ortho_scale=span
 # Face-forward the actual source normal toward this projection; each card is
 # double-sided in runtime, just like the original thin leaves.
 dot=nodes.new('ShaderNodeVectorMath');dot.operation='DOT_PRODUCT';tree.links.new(normal_map.outputs['Normal'],dot.inputs[0]);dot.inputs[1].default_value=normal_axis
 positive=nodes.new('ShaderNodeMath');positive.operation='GREATER_THAN';tree.links.new(dot.outputs['Value'],positive.inputs[0]);positive.inputs[1].default_value=0
 sign=nodes.new('ShaderNodeMath');sign.operation='MULTIPLY_ADD';sign.inputs[1].default_value=2;sign.inputs[2].default_value=-1;tree.links.new(positive.outputs[0],sign.inputs[0])
 faced=nodes.new('ShaderNodeVectorMath');faced.operation='SCALE';tree.links.new(normal_map.outputs['Normal'],faced.inputs[0]);tree.links.new(sign.outputs[0],faced.inputs['Scale'])
 combine=nodes.new('ShaderNodeCombineXYZ')
 for axis,basis in enumerate([right,up,normal_axis]):
  component=nodes.new('ShaderNodeVectorMath');component.operation='DOT_PRODUCT';tree.links.new(faced.outputs['Vector'],component.inputs[0]);component.inputs[1].default_value=basis
  encode=nodes.new('ShaderNodeMath');encode.operation='MULTIPLY_ADD';encode.inputs[1].default_value=.5;encode.inputs[2].default_value=.5;tree.links.new(component.outputs['Value'],encode.inputs[0]);tree.links.new(encode.outputs[0],combine.inputs[axis])
 geometry=nodes.new('ShaderNodeNewGeometry');height_sep=nodes.new('ShaderNodeSeparateXYZ');tree.links.new(geometry.outputs['Position'],height_sep.inputs[0]);height=nodes.new('ShaderNodeMapRange');tree.links.new(height_sep.outputs['Z'],height.inputs['Value']);height.inputs['From Min'].default_value=-.002;height.inputs['From Max'].default_value=.06
 passes={}
 for channel,socket,transform in [('albedo',color.outputs['Color'],'Standard'),('normal',combine.outputs['Vector'],'Raw'),('roughness',rough.outputs['Color'],'Raw'),('height',height.outputs['Result'],'Raw')]:
  tree.links.new(socket,emission.inputs['Color']);scene.view_settings.view_transform=transform
  filename=view+'-'+channel+'.png';scene.render.filepath=str(OUT/filename)
  print('BAKE_START',view,channel,'cpu_threads=4',flush=True);bpy.ops.render.render(write_still=True)
  passes[channel]={'file':filename,'sha256':sha(OUT/filename),'colorTransform':transform}
  print('BAKE_DONE',view,channel,round(time.time()-started,2),flush=True)
 views.append({'id':view,'azimuthRadians':azimuth,'centreBlender':list(centre),'normalBlender':list(normal_axis),'rightBlender':list(right),'upBlender':list(up),'orthographicWidthMetres':span,'orthographicHeightMetres':span,'resolution':[240,240],'passes':passes})
 # Remove orphan pass nodes between views; photographs and core shader remain.
 retained={n.name for n in [output,mix,transparent,emission,color,alpha,normal,rough,cutoff,normal_map]}
 for node in list(nodes):
  if node.name not in retained:nodes.remove(node)

after={str(p.relative_to(ROOT)):sha(p) for p in immutable};assert after==before
report={**audit,'status':'baked-cache-candidate-awaiting-visual-review','sourceFilesBeforeAndAfter':before,'sourceFilesUnchanged':True,'cpuThreads':4,'cyclesDevice':scene.cycles.device,'samples':scene.cycles.samples,'denoising':False,'seconds':time.time()-started,'views':views,'dataPassMethod':'Emission is used only for unlit value projection during offline bake. PNG albedo uses Standard/sRGB with exposure0/gamma1; normal/roughness/height use Raw. All passes alpha-test original photographic alpha at0.45 and preserve alpha coverage. Final cards require PBR, zero emission, source translucency/F0 and scene day/night lighting.','knownApproximation':'Each card preserves one orthographic source view and surface signals; it is not a full volumetric reconstruction. Source data and highest mesh remain retained. Multi-angle silhouettes and alpha union need actual comparison.'}
(OUT/'bake-report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print('BAKE_COMPLETE',json.dumps({'seconds':report['seconds'],'views':len(views),'unchanged':True}),flush=True)
