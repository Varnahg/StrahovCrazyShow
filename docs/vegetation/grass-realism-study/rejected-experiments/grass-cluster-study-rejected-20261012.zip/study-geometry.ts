export type ProjectionView={id:string;centreBlender:number[];rightBlender:number[];upBlender:number[];normalBlender:number[];orthographicWidthMetres:number;orthographicHeightMetres:number;atlasUV:number[]};
/** Blender Z-up to the same Babylon right-handed Y-up source basis. */
const basis=(value:number[])=>[value[0],value[2],-value[1]];
export function cardGeometry(views:ProjectionView[]){
 const positions:number[]=[],normals:number[]=[],uvs:number[]=[],indices:number[]=[];
 for(const view of views){
  const centre=basis(view.centreBlender),right=basis(view.rightBlender),up=basis(view.upBlender),normal=basis(view.normalBlender),offset=positions.length/3;
  const [u0,v0,u1,v1]=view.atlasUV;
  for(const [x,y] of [[-.5,-.5],[.5,-.5],[.5,.5],[-.5,.5]]){
   positions.push(...centre.map((value,axis)=>value+x*right[axis]*view.orthographicWidthMetres+y*up[axis]*view.orthographicHeightMetres));normals.push(...normal);
  }
  uvs.push(u0,v1,u1,v1,u1,v0,u0,v0);indices.push(offset,offset+1,offset+2,offset,offset+2,offset+3);
 }
 return{positions,normals,uvs,indices};
}
