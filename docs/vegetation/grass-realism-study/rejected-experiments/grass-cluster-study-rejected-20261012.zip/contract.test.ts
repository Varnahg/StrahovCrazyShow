import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
import {createHash} from "node:crypto";
import {NullEngine} from "@babylonjs/core/Engines/nullEngine";
import {Scene} from "@babylonjs/core/scene";
import {UniversalCamera} from "@babylonjs/core/Cameras/universalCamera";
import {Camera} from "@babylonjs/core/Cameras/camera";
import {Vector3,Matrix,Quaternion} from "@babylonjs/core/Maths/math.vector";
import {Viewport} from "@babylonjs/core/Maths/math.viewport";
import {PBRMaterial} from "@babylonjs/core/Materials/PBR/pbrMaterial";
import {Texture} from "@babylonjs/core/Materials/Textures/texture";
import {configureSourceGrassMaterial} from "../../client/photo-grass-source-material";
import {cardGeometry} from "./study-geometry";
const directory=new URL("./",import.meta.url),manifest=JSON.parse(readFileSync(new URL("cluster-manifest.json",directory),"utf8"));
const sha=(path:string|URL)=>createHash("sha256").update(readFileSync(path)).digest("hex");
test("cache bake retains source/master hashes and all derived channel hashes",()=>{
 assert.equal(manifest.cyclesDevice,"CPU");assert.equal(manifest.cpuThreads,4);assert.equal(manifest.highestTriangles,5376);assert.equal(manifest.leaves,42);
 for(const [path,hash] of Object.entries(manifest.sourceFilesBeforeAndAfter))assert.equal(sha(path),hash,path);
 for(const channel of Object.values(manifest.channels) as {file:string;sha256:string}[])assert.equal(sha(new URL(channel.file,directory)),channel.sha256);
 for(const view of manifest.views)for(const channel of Object.values(view.passes) as {file:string;sha256:string}[])assert.equal(sha(new URL(channel.file,directory)),channel.sha256);
});
test("each baked card projects its texture corners through the actual RH Babylon camera without mirrors",()=>{
 const engine=new NullEngine({renderWidth:240,renderHeight:240,textureSize:512,deterministicLockstep:false,lockstepMaxSteps:4}),scene=new Scene(engine);scene.useRightHandedSystem=true;
 const basis=(v:number[])=>new Vector3(v[0],v[2],-v[1]);
 try{
  for(const view of manifest.views){
   const centre=basis(view.centreBlender),normal=basis(view.normalBlender),camera=new UniversalCamera(view.id,centre.add(normal.scale(.5)),scene);camera.upVector=basis(view.upBlender);camera.mode=Camera.ORTHOGRAPHIC_CAMERA;camera.orthoLeft=-view.orthographicWidthMetres/2;camera.orthoRight=view.orthographicWidthMetres/2;camera.orthoTop=view.orthographicHeightMetres/2;camera.orthoBottom=-view.orthographicHeightMetres/2;camera.minZ=.01;camera.maxZ=10;camera.rotationQuaternion=Quaternion.FromRotationMatrix(Matrix.LookAtRH(camera.position,centre,camera.upVector).invert());camera.updateUpVectorFromRotation=true;scene.activeCamera=camera;scene.render();
   const geometry=cardGeometry([view]);assert.equal(geometry.indices.length,6);
   const projected=Array.from({length:4},(_,i)=>Vector3.Project(Vector3.FromArray(geometry.positions,i*3),Matrix.Identity(),scene.getTransformMatrix(),new Viewport(0,0,240,240)));
   for(const [i,expected] of [[0,[0,240]],[1,[240,240]],[2,[240,0]],[3,[0,0]]] as const){assert.ok(Math.abs(projected[i].x-expected[0])<.001,view.id+" horizontal projection");assert.ok(Math.abs(projected[i].y-expected[1])<.001,view.id+" vertical projection");}
   const a=Vector3.FromArray(geometry.positions),b=Vector3.FromArray(geometry.positions,3),c=Vector3.FromArray(geometry.positions,6);assert.ok(Vector3.Dot(Vector3.Cross(b.subtract(a),c.subtract(a)).normalize(),normal)>.999999);
   assert.ok(geometry.uvs.every((n:number)=>n>=0&&n<=1));camera.dispose();
  }
  assert.equal(cardGeometry(manifest.views).indices.length/3,8);
 }finally{scene.dispose();engine.dispose();}
});
test("candidate material receives source PBR lighting, alpha test and zero emission",()=>{
 const engine=new NullEngine(),scene=new Scene(engine),material=new PBRMaterial("candidate",scene),maps={albedo:new Texture(null,scene),alpha:new Texture(null,scene),normal:new Texture(null,scene),arm:new Texture(null,scene)};
 try{
  const recipe=JSON.parse(readFileSync("public/models/vegetation/grass/material.json","utf8"));configureSourceGrassMaterial(material,maps,recipe,"author-material");
  assert.equal(material.unlit,false);assert.deepEqual(material.emissiveColor.asArray(),[0,0,0]);assert.equal(material.alphaCutOff,.45);assert.equal(material.transparencyMode,PBRMaterial.PBRMATERIAL_ALPHATEST);assert.equal(material.subSurface.translucencyIntensity,recipe.translucency);assert.equal(material.metallicF0Factor,recipe.babylonMetallicF0Factor);assert.equal(material.useAmbientOcclusionFromMetallicTextureRed,false);assert.equal(material.subSurface.translucencyColorTexture,maps.albedo);assert.equal(material.twoSidedLighting,true);
 }finally{scene.dispose();engine.dispose();}
});

