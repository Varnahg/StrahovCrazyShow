# Four-plane photographic cluster — rejected for near/mid views

This cache experiment preserves the authored highest-v2 source and every original Poly Haven map. The master was actually reopened in Blender 5.2.2; source geometry, transforms, UVs, image paths and original hashes were checked. `source-inspection.json` and `bake-report.json` record the checks.

Four orthographic projections of the exact redistributed 42-leaf / 5376-triangle highest cluster were rendered using Cycles **CPU**, four threads, 240×240, eight samples, no denoising. Albedo is an unlit data transfer with Standard/sRGB; normals, roughness and height use Raw. Runtime PBR has zero emission, alpha test 0.45 and source F0/translucency. The original 8k photographic pixels remain unchanged. Derived RGB padding is extended only where alpha is zero.

The cache server runs at `http://127.0.0.1:4196/`. Its controls compare current source-UV LODs, the four-card candidate, vertical cards only, and highest geometry using the same camera, lights, procedural ground and deterministic root prefix. The highest geometry preview uses unchanged provider 1k maps, while derived atlas data comes from original 8k maps; the preview does not claim full-resolution highest texture equivalence.

## Measured evidence

- `cluster-manifest.json`: four 512² atlas channels; camera bases, dimensions, source hashes, exact alpha-mask union and silhouette comparisons. At the three baked side angles, the candidate adds silhouette area: intersection-over-union 0.760–0.839. Exact top projection IoU is 1.0.
- `bed-alpha-union-audit.json`: actual rasterized/bilinear alpha-test **boolean pixel unions** in a common one-square-metre nadir bed at 1024². Current medium uses 52×222 triangles and covers 3.9906%; the denser candidate uses 160×8 triangles and covers 24.1096%. These are different documented density quotas, not equal-density testing. No triangle-area sums are used.
- `contract-tests.log`: 3/3 checks pass for retained source/channel hashes, real Babylon right-handed camera projection of texture corners, and lit PBR/zero emission/alpha cutoff. TypeScript passed. The initial top-camera check exposed Babylon `setTarget`'s pole epsilon rather than a flipped asset; the audit uses an exact public quaternion camera pose now.

These CPU checks are not GPU/FPS acceptance. Card alpha occupancy is only about 14–20%; transparent fragments still incur GPU cost.

## Actual root GPU outcome

**Rejected for close and mid views.** Root inspected the candidate and highest from identical cameras on Intel UHD 630 at CSS/internal 1280×720. Ready=true and zero errors did not establish visual quality. `root-cards-eye.jpg` shows regular dark islands; `root-cards-close.jpg` shows flattened crossed clusters. Highest (`root-highest-eye.jpg`, `root-highest-close.jpg`) retains more continuous spatial leaves. Turning normals off did not fix shape. `root-cards-night.jpg` verifies no fake emission under the controlled night lights. Original photographic colours were not repainted to hide the defect.

The failed candidate, all input/output maps, audit scripts and images are retained. It has **not** been integrated into runtime or accepted as a near representation. The follow-up individual-leaf prototype is separate in `../grass-leaf-study`.

## Reproduce

From the worktree root, run `bake-cluster.py` with Blender background, `--threads 4 --python-exit-code 1`. Run `prepare.ts` with `pnpm exec tsx`, then `make-atlas.py` and `audit-bed-coverage.py` using the bundled Blender Python plus `.cache/street-python`. Build `preview.ts` via `node .cache/grass-cluster-study/build-preview.mjs`; serve with `node .cache/grass-cluster-study/serve.mjs`. Coordinate CPU/GPU windows before rendering or performance measurement.
