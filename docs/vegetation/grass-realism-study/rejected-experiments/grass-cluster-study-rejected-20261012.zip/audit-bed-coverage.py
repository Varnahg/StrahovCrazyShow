"""Actual alpha-tested pixel unions in the same 1m² orthographic lawn bed."""
from pathlib import Path
import sys,json,math,hashlib,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'.cache/street-python'))
import numpy as np
from PIL import Image
pack=json.loads((ROOT/'public/models/vegetation/grass/geometry.json').read_text(encoding='utf8'))
manifest=json.loads((OUT/'cluster-manifest.json').read_text(encoding='utf8'))
points=json.loads((OUT/'points.json').read_text(encoding='utf8'))['points']
resolution=1024;rows=[];started=time.time()
def sample(image,u,v):
 h,w=image.shape;px=np.clip(u*w-.5,0,w-1);py=np.clip(v*h-.5,0,h-1);x0=np.floor(px).astype(int);y0=np.floor(py).astype(int);fx=px-x0;fy=py-y0;x1=np.minimum(x0+1,w-1);y1=np.minimum(y0+1,h-1)
 return (image[y0,x0]*(1-fx)+image[y0,x1]*fx)*(1-fy)+(image[y1,x0]*(1-fx)+image[y1,x1]*fx)*fy
alpha_path=ROOT/'public/textures/vegetation/grass/grass_medium_01_alpha_1k.png'
alpha_image=Image.open(alpha_path);alpha_raw=np.asarray(alpha_image);assert alpha_raw.max()>255,'Original alpha is 16bit, not clipped 8bit';alpha=alpha_raw.astype(float)/65535
for level,count in [('near',10),('medium',52),('far',145)]:
 g=pack['levels'][level];positions=np.array(g['positions']).reshape(-1,3);uvs=np.array(g['uvs']).reshape(-1,2);triangles=np.array(g['indices']).reshape(-1,3);mask=np.zeros((resolution,resolution),dtype=bool)
 for p in points[:count]:
  c=math.cos(p['yaw']);s=math.sin(p['yaw']);projected=np.stack((positions[:,0]*c+positions[:,2]*s+p['x'],-positions[:,0]*s+positions[:,2]*c+p['z']),axis=1)
  screen=(projected+.5)*resolution-.5
  for triangle in triangles:
   a,b,d=screen[triangle];minimum=np.maximum(0,np.ceil(np.minimum(np.minimum(a,b),d)).astype(int));maximum=np.minimum(resolution-1,np.floor(np.maximum(np.maximum(a,b),d)).astype(int))
   if np.any(maximum<minimum):continue
   den=(b[0]-a[0])*(d[1]-a[1])-(b[1]-a[1])*(d[0]-a[0])
   if abs(den)<1e-12:continue
   gx,gy=np.meshgrid(np.arange(minimum[0],maximum[0]+1),np.arange(minimum[1],maximum[1]+1))
   v=((gx-a[0])*(d[1]-a[1])-(gy-a[1])*(d[0]-a[0]))/den;w=((b[0]-a[0])*(gy-a[1])-(b[1]-a[1])*(gx-a[0]))/den;u=1-v-w
   inside=(u>=0)&(v>=0)&(w>=0);uv=u[:,:,None]*uvs[triangle[0]]+v[:,:,None]*uvs[triangle[1]]+w[:,:,None]*uvs[triangle[2]]
   accepted=inside&(sample(alpha,uv[:,:,0],uv[:,:,1])>=.45);mask[minimum[1]:maximum[1]+1,minimum[0]:maximum[0]+1]|=accepted
 area=float(mask.mean());triangles_total=g['triangles']*count
 rows.append({'representation':level,'instances':count,'triangles':triangles_total,'alphaUnionSquareMetresWithinOneSquareMetre':area,'acceptedPixels':int(mask.sum()),'squareMetresUnionPerSubmittedTriangle':area/triangles_total,'method':'Rasterize every submitted source-UV triangle in the same orthographic top camera, bilinear sample original 16bit alpha normalized by65535, alpha-test0.45 and OR into a single boolean pixel mask. No triangle-area sums.'})
 Image.fromarray(mask.astype(np.uint8)*255,'L').save(OUT/('bed-alpha-'+level+'.png'))
view=next(v for v in manifest['views'] if v['id']=='top');source=np.asarray(Image.open(OUT/view['passes']['albedo']['file']).convert('RGBA'))[:,:,3].astype(float)/255
mask=np.zeros((resolution,resolution),dtype=bool);half=view['orthographicWidthMetres']/2
centre=np.array([view['centreBlender'][0],-view['centreBlender'][1]]);right=np.array([view['rightBlender'][0],-view['rightBlender'][1]]);up=np.array([view['upBlender'][0],-view['upBlender'][1]])
for p in points:
 c=math.cos(p['yaw']);s=math.sin(p['yaw']);rotation=np.array([[c,s],[-s,c]]);cp=rotation@centre+np.array([p['x'],p['z']]);r=rotation@right;u=rotation@up
 corners=np.array([cp+x*r*half+y*u*half for x,y in [(-1,-1),(1,-1),(1,1),(-1,1)]]);minimum=np.maximum(0,np.floor((corners.min(axis=0)+.5)*resolution).astype(int));maximum=np.minimum(resolution-1,np.ceil((corners.max(axis=0)+.5)*resolution).astype(int))
 gx,gy=np.meshgrid((np.arange(minimum[0],maximum[0]+1)+.5)/resolution-.5,(np.arange(minimum[1],maximum[1]+1)+.5)/resolution-.5);delta=np.stack((gx-cp[0],gy-cp[1]),axis=2)
 cu=.5+np.sum(delta*r,axis=2)/(half*2);cv=.5-np.sum(delta*u,axis=2)/(half*2);inside=(cu>=0)&(cu<=1)&(cv>=0)&(cv<=1);accepted=inside&(sample(source,cu,cv)>=.45)
 mask[minimum[1]:maximum[1]+1,minimum[0]:maximum[0]+1]|=accepted
area=float(mask.mean());rows.append({'representation':'four-cards','instances':len(points),'triangles':len(points)*8,'alphaUnionSquareMetresWithinOneSquareMetre':area,'acceptedPixels':int(mask.sum()),'squareMetresUnionPerSubmittedTriangle':area/(len(points)*8),'method':'At exact top view the three vertical planes have zero projected area. Intersect each rotated horizontal card, bilinear sample its source-rendered alpha and OR all160 results in the same1m² pixel mask. This is actual candidate mask union, not highest3D whole-bed GPU rasterization.'})
Image.fromarray(mask.astype(np.uint8)*255,'L').save(OUT/'bed-alpha-cards.png')
result={'status':'measured-cache-candidate-not-accepted','timestampUTC':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'resolution':[resolution,resolution],'footprintSquareMetres':1,'projection':'orthographic nadir, pixel centres sampled, clipped to the same physical one-square-metre bed','alphaCutoff':.45,'originalAlphaMode':alpha_image.mode,'originalAlphaSha256':hashlib.sha256(alpha_path.read_bytes()).hexdigest(),'rows':rows,'allocatedCandidateTextureTexels':4*512*512,'candidateRGBA8WithFullMipEstimateBytes':int(4*512*512*4*4/3),'caveats':['Coverage is pixel-resolution dependent and measures a controlled overhead view, not final ground occlusion at arbitrary camera angle.','Cards have approximately14–20% accepted alpha occupancy per individual baked projection; transparent card fragments still cost GPU work.','Source medium uses52instances and candidate160instances on the same deterministic prefix; this compares the actual current quota with a cheaper denser candidate, not equal density.','No GPU performance or final silhouette acceptance.'],'seconds':time.time()-started}
(OUT/'bed-alpha-union-audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result,indent=2))
