"""Derived cache atlases and measured alpha-mask unions, never source edits."""
from pathlib import Path
import json,sys,hashlib,math
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'.cache/street-python'))
import numpy as np
from PIL import Image
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=json.loads((OUT/'bake-report.json').read_text(encoding='utf8'))
assert report['sourceFilesUnchanged'] and report['cyclesDevice']=='CPU'
size=512;cell=256;gutter=8
atlases={channel:np.zeros((size,size,4),dtype=np.uint8) for channel in ['albedo','normal','arm','alpha']}
views=[]
def dilate(data,valid,radius=8):
 result=data.copy();mask=valid.copy()
 for step in range(radius):
  before=mask.copy()
  for dy,dx in [(0,1),(0,-1),(1,0),(-1,0)]:
   shifted=np.roll(before,(dy,dx),(0,1));values=np.roll(result,(dy,dx),(0,1))
   if dy==1:shifted[0]=False
   if dy==-1:shifted[-1]=False
   if dx==1:shifted[:,0]=False
   if dx==-1:shifted[:,-1]=False
   take=(~mask)&shifted;result[take]=values[take];mask[take]=True
 return result
for i,view in enumerate(report['views']):
 inputs={channel:np.asarray(Image.open(OUT/details['file']).convert('RGBA')).copy() for channel,details in view['passes'].items()}
 alpha=inputs['albedo'][:,:,3]
 assert all(np.array_equal(alpha,image[:,:,3]) for image in inputs.values()),'All data passes must use identical sampled alpha.'
 x=(i%2)*cell+gutter;y=(i//2)*cell+gutter
 valid=alpha>0;opaque=alpha>=230
 albedo=inputs['albedo'];normal=inputs['normal'];rough=inputs['roughness'][:,:,0]
 # Preserve alpha exactly. Only invisible RGB padding is extended to avoid
 # black/zero-normal fringes during ordinary bilinear/mip sampling.
 for channel,image in [('albedo',albedo),('normal',normal)]:
  rgb=dilate(image[:,:,:3],valid);rgba=np.dstack((rgb,alpha));atlases[channel][y:y+240,x:x+240]=rgba
 arm=np.dstack((np.full_like(rough,255),dilate(rough,valid),np.zeros_like(rough),alpha));atlases['arm'][y:y+240,x:x+240]=arm
 alphargb=np.repeat(alpha[:,:,None],3,axis=2);atlases['alpha'][y:y+240,x:x+240]=np.dstack((alphargb,np.full_like(alpha,255)))
 # Populate cell RGB padding without changing coverage. This is a derived
 # atlas filtering operation, not a change to provider image pixels.
 ys=slice((i//2)*cell,(i//2+1)*cell);xs=slice((i%2)*cell,(i%2+1)*cell)
 for channel in ['albedo','normal','arm']:
  patch=atlases[channel][ys,xs];patch[:,:,:3]=dilate(patch[:,:,:3],patch[:,:,3]>0)
 accepted=alpha.astype(np.float64)/255>=.45
 coverage=float(np.mean(accepted));area=coverage*view['orthographicWidthMetres']*view['orthographicHeightMetres']
 views.append({**view,'atlasCell':[i%2,i//2],'atlasUV':[x/size,y/size,(x+240)/size,(y+240)/size],'acceptedTexels':int(accepted.sum()),'totalRenderedTexels':int(accepted.size),'acceptedAlphaFraction':coverage,'sourceProjectedAlphaUnionSquareMetres':area,'squareMetresPerAcceptedTexel':area/max(1,int(accepted.sum())),'albedoOpaqueMedianRGB':np.median(albedo[:,:,:3][opaque],axis=0).tolist(),'normalOpaqueVectorLengthRange':list(map(float,[np.linalg.norm(normal[:,:,:3][opaque].astype(float)/127.5-1,axis=1).min(),np.linalg.norm(normal[:,:,:3][opaque].astype(float)/127.5-1,axis=1).max()]))})
for channel,pixels in atlases.items():Image.fromarray(pixels,'RGBA').save(OUT/('cluster-'+channel+'.png'))

# Actual union of alpha-tested card ray intersections, at exactly the baked
# source views. This does not sum triangle areas and records over-coverage too.
def sample(image,u,v):
 h,w=image.shape;px=np.clip(u*w-.5,0,w-1);py=np.clip(v*h-.5,0,h-1)
 x0=np.floor(px).astype(int);y0=np.floor(py).astype(int);x1=np.minimum(x0+1,w-1);y1=np.minimum(y0+1,h-1);fx=px-x0;fy=py-y0
 return (image[y0,x0]*(1-fx)+image[y0,x1]*fx)*(1-fy)+(image[y1,x0]*(1-fx)+image[y1,x1]*fx)*fy
alpha_sources=[np.asarray(Image.open(OUT/v['passes']['albedo']['file']).convert('RGBA'))[:,:,3].astype(float)/255 for v in views]
union_audits=[]
for reference,source_alpha in zip(views,alpha_sources):
 n=np.array(reference['normalBlender']);r=np.array(reference['rightBlender']);up=np.array(reference['upBlender']);c=np.array(reference['centreBlender']);span=reference['orthographicWidthMetres'];res=240
 gx,gy=np.meshgrid((np.arange(res)+.5)/res-.5,.5-(np.arange(res)+.5)/res)
 origins=c+gx[:,:,None]*span*r+gy[:,:,None]*span*up+n*.5;direction=-n
 accepted=np.zeros((res,res),dtype=bool)
 for card,card_alpha in zip(views,alpha_sources):
  cn=np.array(card['normalBlender']);cr=np.array(card['rightBlender']);cu=np.array(card['upBlender']);cc=np.array(card['centreBlender']);den=direction@cn
  if abs(den)<1e-7:continue
  t=np.sum((cc-origins)*cn,axis=2)/den;hit=origins+t[:,:,None]*direction;relative=hit-cc
  u=.5+np.sum(relative*cr,axis=2)/card['orthographicWidthMetres'];v=.5-np.sum(relative*cu,axis=2)/card['orthographicHeightMetres']
  inside=(u>=0)&(u<=1)&(v>=0)&(v<=1)&(t>=0)
  accepted|=inside&(sample(card_alpha,u,v)>=.45)
 source_mask=source_alpha>=.45;union=accepted|source_mask;intersection=accepted&source_mask
 union_audits.append({'view':reference['id'],'pixels':res*res,'candidateTrueUnionAcceptedPixels':int(accepted.sum()),'candidateProjectedUnionSquareMetres':float(accepted.mean()*span*span),'sourceProjectedUnionSquareMetres':float(source_mask.mean()*span*span),'intersectionOverUnion':float(intersection.sum()/max(1,union.sum())),'falsePositivePixels':int((accepted&~source_mask).sum()),'falseNegativePixels':int((source_mask&~accepted).sum()),'method':'Independent orthographic rays intersect all four planar cards, bilinear sample baked alpha, then boolean OR accepted pixels. Source comparison uses the exact same orthographic camera and source render alpha.'})
 Image.fromarray(np.stack([accepted.astype(np.uint8)*255,source_mask.astype(np.uint8)*255,np.zeros_like(source_mask,dtype=np.uint8)],axis=2),'RGB').save(OUT/('union-'+reference['id']+'.png'))
manifest={**report,'views':views,'atlasResolution':[size,size],'gutterTexels':gutter,'cardTriangles':8,'highestTriangles':5376,'channels':{channel:{'file':'cluster-'+channel+'.png','sha256':sha(OUT/('cluster-'+channel+'.png')),'bytes':(OUT/('cluster-'+channel+'.png')).stat().st_size,'colorSpace':'sRGB' if channel=='albedo' else 'linear'} for channel in atlases},'padding':'Only derived atlas RGB is dilated eight texels; alpha values remain identical to source projection. Original photos are immutable.','unionAudits':union_audits,'runtimeMaterial':'PBR albedo+alpha+normal+roughness, original source F0 and translucency; AO disabled, metallic0, emission0. Normal RGB stores camera-right/up/toward-camera source normals for each plane, face-forwarded as a double-sided thin leaf approximation.','remainingLimits':['Four image planes flatten parallax and repeat parts of the same cluster; union over-coverage is explicitly measured.','Top plane lies at source bounding-box centre height, not reconstructed per-pixel depth. Height pass is retained only as research evidence.','No whole-game or GPU performance acceptance.']}
(OUT/'cluster-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
print(json.dumps({'atlas':[size,size],'views':[{'id':v['id'],'alphaUnion':v['sourceProjectedAlphaUnionSquareMetres'],'coverage':v['acceptedAlphaFraction'],'color':v['albedoOpaqueMedianRGB']} for v in views],'unions':union_audits},indent=2))
