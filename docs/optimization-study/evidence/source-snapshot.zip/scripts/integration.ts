import assert from 'node:assert/strict';
import { Client, type Room } from '@colyseus/sdk';
import { DEFAULT_PROFILE } from '../shared/types';
const endpoint='http://127.0.0.1:2567';
const sleep=(ms:number)=>new Promise(r=>setTimeout(r,ms));
const until=async(check:()=>boolean,label:string)=>{for(let i=0;i<100;i++){if(check())return;await sleep(30);}throw new Error('Timeout: '+label);};
async function issue(name:string,resumeToken?:string){const r=await fetch(endpoint+'/api/session',{method:'POST',body:JSON.stringify({mode:'multiplayer',profile:{...DEFAULT_PROFILE,nickname:name},resumeToken})});assert.equal(r.status,200);return r.json();}
const guest=await fetch(endpoint+'/api/session',{method:'POST',body:JSON.stringify({mode:'guest'})});assert.equal(guest.status,403);
for(const path of ['/api/players','/api/chat','/api/community-events'])assert.equal((await fetch(endpoint+path)).status,403);
const sdk=new Client(endpoint);const sessionA=await issue('Alice'),sessionB=await issue('Bob');
await assert.rejects(()=>sdk.joinById(sessionA.worldId,{}),'no token must be rejected');
const rooms:Room[]=[];
try{
  const a=await sdk.joinById(sessionA.worldId,{token:sessionA.token});rooms.push(a);
  const stateA:any={players:[],messages:[],social:{},events:[],motion:[],notices:[]};
  for(const[k,type]of [['players','presence'],['social','social'],['events','events'],['motion','motion']])a.onMessage(type,(d:any)=>stateA[k]=d);
  a.onMessage('welcome',(d:any)=>Object.assign(stateA,{players:d.players,events:d.events}));a.onMessage('chat',(m:any)=>stateA.messages.push(m));a.onMessage('notice',(n:any)=>stateA.notices.push(n));a.onMessage('activity',()=>{});
  const b=await sdk.joinById(sessionB.worldId,{token:sessionB.token});rooms.push(b);
  const stateB:any={messages:[],social:{},notices:[],players:[]};b.onMessage('welcome',()=>{});b.onMessage('presence',(p:any)=>stateB.players=p);b.onMessage('motion',()=>{});b.onMessage('social',(d:any)=>stateB.social=d);b.onMessage('chat',(m:any)=>stateB.messages.push(m));b.onMessage('notice',(n:any)=>stateB.notices.push(n));b.onMessage('events',()=>{});b.onMessage('activity',()=>{});
  await until(()=>stateA.players.length===2,'presence of both clients');
  a.send('chat',{channel:'global',text:'Ahoj ze Strahova'});await until(()=>stateB.messages.some((m:any)=>m.text==='Ahoj ze Strahova'),'global chat');
  a.send('contact',{to:sessionB.id});await until(()=>stateB.social.requests?.includes(sessionA.id),'contact request');
  b.send('contact',{to:sessionA.id,accept:true});await until(()=>stateA.social.contacts?.includes(sessionB.id),'accepted contact');
  a.send('chat',{channel:'dm:'+sessionB.id,text:'Soukromě'});await until(()=>stateB.messages.some((m:any)=>m.text==='Soukromě'),'private chat');
  b.send('block',{to:sessionA.id,enabled:true});await until(()=>stateA.social.contacts?.length===0,'blocked contact removal');
  a.send('chat',{channel:'dm:'+sessionB.id,text:'Zablokovaná'});await until(()=>stateA.notices.length>0,'blocked DM rejection');assert.ok(!stateB.messages.some((m:any)=>m.text==='Zablokovaná'));
  const before=stateA.motion.find((r:any)=>r[0]===sessionA.id)?.[1];for(let i=0;i<20;i++){a.send('input',{x:1,z:0,yaw:0,jump:false,seq:i});await sleep(34);}await until(()=>stateA.motion.find((r:any)=>r[0]===sessionA.id)?.[1]>before+1,'server movement');
  a.send('saveEvent',{title:'Vlastní setkání',description:'Demo',placeId:'b6',startsAt:Date.now()+60000,endsAt:Date.now()+120000});await until(()=>stateA.events.some((e:any)=>e.title==='Vlastní setkání'),'own event');const own=stateA.events.find((e:any)=>e.title==='Vlastní setkání');b.send('cancelEvent',{id:own.id});await until(()=>stateB.notices.length>0,'ownership rejection');
  await a.leave();rooms.splice(rooms.indexOf(a),1);await sleep(100);const resumed=await issue('ignored',sessionA.token);assert.equal(resumed.id,sessionA.id);const rejoined=await sdk.joinById(resumed.worldId,{token:resumed.token});rooms.push(rejoined);rejoined.onMessage('*',()=>{});await sleep(150);
  const weather=await(await fetch(endpoint+'/api/weather')).json();assert.ok(['live','fallback','unavailable'].includes(weather.status));
  console.log('PASS: singleton world, guest boundary, two clients, movement, global/DM chat, consent, blocking, event ownership, session resume and weather endpoint.');
}finally{for(const r of rooms)await r.leave();}
