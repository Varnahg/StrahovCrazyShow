import { randomBytes, randomUUID } from 'node:crypto';
import { Server, Room, matchMaker, type Client } from '@colyseus/core';
import { WebSocketTransport } from '@colyseus/ws-transport';
import { createServer, type IncomingMessage, type ServerResponse } from 'node:http';
import { Community } from './community';
import { sanitizeInput, sanitizeProfile, cleanText } from '../shared/profile';
import { initPhysics, Simulation } from '../shared/simulation';
import { SPAWN, zoneAt } from '../shared/world';
import { makeDemoEvents, dateKey } from '../shared/events';
import type { Input, Player, Profile } from '../shared/types';
import { getWeather } from './weather';
const sessions=new Map<string,{id:string;profile:Profile;expires:number}>();
const issueRates=new Map<string,number[]>();
let worldId='';
const store=new Community();
await initPhysics();
class StrahovRoom extends Room {
  autoDispose=false;
  sim=new Simulation(); pendingInputs=new Map<string,Input>();connections=new Map<string,Client>();lastInput=new Map<string,number>();day=dateKey(Date.now());
  onCreate(){
    this.onMessage('input',(c,raw)=>{const i=sanitizeInput(raw);if(i&&store.rate(c.auth.id,'input',90,1000)){this.pendingInputs.set(c.auth.id,i);this.lastInput.set(c.auth.id,Date.now());}});
    this.onMessage('profile',(c,p)=>this.safe(c,()=>{const profile=sanitizeProfile(p);Object.assign(store.players.get(c.auth.id)!,profile);sessions.get(c.auth.token)!.profile=profile;this.broadcastPresence();}));
    this.onMessage('chat',(c,data)=>this.safe(c,()=>{const {message,recipients}=store.chat(c.auth.id,data?.channel,data?.text);for(const id of recipients)this.connections.get(id)?.send('chat',message);}));
    this.onMessage('contact',(c,d)=>this.safe(c,()=>{store.contact(c.auth.id,cleanText(d?.to,80),d?.accept===true);this.syncSocial();}));
    this.onMessage('decline',(c,d)=>{store.requests.get(c.auth.id)?.delete(cleanText(d?.to,80));this.syncSocial();});
    this.onMessage('block',(c,d)=>this.safe(c,()=>{store.block(c.auth.id,cleanText(d?.to,80),d?.enabled!==false);this.syncSocial();}));
    this.onMessage('attend',(c,d)=>this.safe(c,()=>{store.attend(c.auth.id,cleanText(d?.eventId,80),d?.enabled===true,d?.company===true);this.syncSocial();}));
    this.onMessage('saveEvent',(c,d)=>this.safe(c,()=>{store.saveEvent(c.auth.id,d);this.broadcast('events',store.events);}));
    this.onMessage('cancelEvent',(c,d)=>this.safe(c,()=>{store.cancelEvent(c.auth.id,cleanText(d?.id,80));this.broadcast('events',store.events);}));
    this.onMessage('emote',(c,d)=>{if(!store.rate(c.auth.id,'emote',5,10000))return;const p=store.players.get(c.auth.id)!;p.emote=['👋','❤️','🎉','👍'].includes(d)?d:'👋';this.broadcast('emote',{id:p.id,emote:p.emote});});
    this.onMessage('vehicle',c=>this.safe(c,()=>{const p=store.players.get(c.auth.id)!,a=this.sim.actors.get(p.id)!;if(p.zone!=='outside')throw new Error('Auto je dostupné pouze venku.');if(!a.vehicle&&Math.hypot(p.x-25,p.z+9)>5)throw new Error('Dojdi k autu u startu.');if(a.vehicle){const pos=a.position;const exit={x:pos.x+Math.cos(a.yaw)*2,y:1,z:pos.z-Math.sin(a.yaw)*2};a.setVehicle(false);a.setPosition(exit);}else{if([...this.sim.actors.values()].some(q=>q.vehicle))throw new Error('Auto právě používá jiný hráč.');a.setPosition({x:25,y:.65,z:-9});a.setVehicle(true);}p.vehicle=a.vehicle;this.broadcastPresence();}));
    this.onMessage('respawn',c=>{const a=this.sim.actors.get(c.auth.id)!;if(a.vehicle)a.setVehicle(false);a.setPosition(SPAWN);this.broadcastPresence();});
    this.onMessage('find',(c,d)=>this.safe(c,()=>{if(store.find(c.auth.id,Number(d)))for(const client of this.clients)client.send('reward','Průzkumník kopce');this.broadcast('activity',store.activity);}));
    this.onMessage('quizStart',(c,d)=>{store.startQuiz(c.auth.id,d);this.broadcast('activity',store.activity);});
    this.onMessage('quizAnswer',(c,d)=>{store.answer(c.auth.id,Number(d));this.broadcast('activity',store.activity);});
    this.setSimulationInterval(()=>{for(const [id,a]of this.sim.actors){const input=Date.now()-(this.lastInput.get(id)||0)<300?(this.pendingInputs.get(id)||{x:0,z:0,yaw:0,jump:false,seq:0}):{x:0,z:0,yaw:0,jump:false,seq:0};a.step(input);const p=store.players.get(id)!;p.ack=input.seq;}this.sim.tick();for(const[id,a]of this.sim.actors){const p=store.players.get(id)!;Object.assign(p,a.position,{yaw:a.yaw,speed:a.speed,vehicle:a.vehicle,zone:zoneAt(a.position)});}if(store.tick()){this.broadcast('activity',store.activity);if(!store.activity.quiz.running)for(const c of this.clients)c.send('reward','Kvízový nadšenec');}},1000/30);
    this.clock.setInterval(()=>this.broadcast('motion',[...store.players.values()].map(p=>[p.id,p.x,p.y,p.z,p.yaw,p.speed,p.ack,p.vehicle?1:0,p.zone])),1000/15);
    this.clock.setInterval(()=>{const key=dateKey(Date.now());if(key!==this.day){this.day=key;store.events=[...makeDemoEvents(),...store.events.filter(e=>e.owner&&e.endsAt>Date.now()-86400000)];this.broadcast('events',store.events);}for(const[token,s]of sessions)if(!this.connections.has(s.id)&&s.expires<Date.now())sessions.delete(token);},30000);
  }
  onAuth(_c:Client,options:any){const token=typeof options?.token==='string'?options.token:'';const s=sessions.get(token);if(!s||s.expires<Date.now()||this.connections.has(s.id))throw new Error('Platná multiplayerová relace je vyžadována.');return {...s,token};}
  onJoin(client:Client){const s=client.auth;this.connections.set(s.id,client);const actor=this.sim.add(s.id,{...SPAWN,x:SPAWN.x+(this.clients.length%5)*1.5});const p:Player={...s.profile,...actor.position,id:s.id,yaw:0,emote:'',vehicle:false,speed:0,ack:0,zone:'outside'};store.players.set(p.id,p);client.send('welcome',{id:p.id,players:[...store.players.values()],events:store.events,activity:store.activity});this.broadcastPresence();this.syncSocial();}
  onLeave(client:Client){const id=client.auth.id;this.connections.delete(id);this.sim.remove(id);store.players.delete(id);this.pendingInputs.delete(id);this.lastInput.delete(id);const s=sessions.get(client.auth.token);if(s)s.expires=Date.now()+30*60000;this.broadcastPresence();this.syncSocial();}
  onDispose(){this.sim.dispose();}
  safe(c:Client,action:()=>void){try{action();}catch(error){c.send('notice',error instanceof Error?error.message:'Akce se nezdařila.');}}
  broadcastPresence(){this.broadcast('presence',[...store.players.values()]);}
  syncSocial(){for(const c of this.clients)c.send('social',store.privateState(c.auth.id));}
}
const http=createServer();
const handleApi=async(req:IncomingMessage,res:ServerResponse)=>{
  res.setHeader('Access-Control-Allow-Origin','*');res.setHeader('Access-Control-Allow-Headers','Content-Type,Authorization');res.setHeader('Cache-Control','no-store');res.setHeader('Content-Type','application/json');
  if(req.method==='OPTIONS'){res.writeHead(204).end();return;}
  if(req.url==='/api/health'){res.end(JSON.stringify({ok:true,worldId,online:store.players.size}));return;}
  if(req.url==='/api/weather'){res.end(JSON.stringify(await getWeather()));return;}
  if(req.url==='/api/demo-events'){res.end(JSON.stringify(store.events.filter(e=>!e.owner)));return;}
  if(req.url==='/api/session'&&req.method==='POST'){
    try{
      const addr=req.socket.remoteAddress||'local',list=(issueRates.get(addr)||[]).filter(t=>Date.now()-t<60000);if(list.length>=60){res.writeHead(429).end(JSON.stringify({error:'Příliš mnoho vstupů. Zkus to za minutu.'}));return;}list.push(Date.now());issueRates.set(addr,list);
      let body='';for await(const chunk of req){body+=chunk;if(body.length>12000)throw new Error('Příliš velký požadavek.');}
      const raw=JSON.parse(body||'{}');if(raw.mode!=='multiplayer'){res.writeHead(403).end(JSON.stringify({error:'Host nemá multiplayerovou relaci.'}));return;}
      const previous=typeof raw.resumeToken==='string'?sessions.get(raw.resumeToken):undefined;
      if(previous&&previous.expires>Date.now()){res.end(JSON.stringify({token:raw.resumeToken,id:previous.id,worldId}));return;}
      const token=randomBytes(32).toString('hex'),id=randomUUID();sessions.set(token,{id,profile:sanitizeProfile(raw.profile),expires:Date.now()+30*60000});res.end(JSON.stringify({token,id,worldId}));return;
    }catch{res.writeHead(400).end(JSON.stringify({error:'Neplatný požadavek.'}));return;}
  }
  if(req.url?.startsWith('/api/')){res.writeHead(403).end(JSON.stringify({error:'Multiplayerová data vyžadují ověřenou dočasnou relaci přes herní spojení.'}));}
};
const server=new Server({transport:new WebSocketTransport({server:http}),greet:false,express:app=>{app.use((req,res,next)=>{if(req.url.startsWith('/api/'))void handleApi(req,res);else next();});}});server.define('strahov',StrahovRoom);
await server.listen(Number(process.env.PORT||2567),'127.0.0.1');
const room=await matchMaker.createRoom('strahov',{});worldId=room.roomId;
console.log(`Strahov multiplayer: http://127.0.0.1:${process.env.PORT||2567} — world ${worldId}`);

