import { parseStation, type Weather } from '../shared/weather';
let cached:Weather={temperature:null,wind:0,windDirection:0,rain:0,cloud:.4,observedAt:null,fetchedAt:0,source:'Počasí zatím nedostupné',cloudSource:'Demonstrační oblačnost',stale:true,status:'unavailable'};
let pending:Promise<Weather>|undefined;
export async function getWeather(){
  if(Date.now()-cached.fetchedAt<5*60000)return cached;
  if(pending)return pending;
  pending=(async()=>{
    const results=await Promise.allSettled([
      fetch('https://weather.sh.cvut.cz/weather/',{signal:AbortSignal.timeout(7000)}).then(async r=>{if(!r.ok)throw new Error(String(r.status));return parseStation(new TextDecoder('windows-1250').decode(await r.arrayBuffer()));}),
      fetch('https://api.open-meteo.com/v1/forecast?latitude=50.08065&longitude=14.39175&current=temperature_2m,precipitation,cloud_cover,wind_speed_10m,wind_direction_10m&wind_speed_unit=ms&timeformat=unixtime',{signal:AbortSignal.timeout(7000)}).then(async r=>{if(!r.ok)throw new Error(String(r.status));return (await r.json()).current;})
    ]);
    const station=results[0].status==='fulfilled'?results[0].value:null,model=results[1].status==='fulfilled'?results[1].value:null;
    if(station&&!station.stale){cached=station;if(model){cached.cloud=model.cloud_cover/100;cached.cloudSource='Open-Meteo · modelová oblačnost';cached.windDirection=model.wind_direction_10m;}}
    else if(model)cached={temperature:model.temperature_2m,wind:model.wind_speed_10m,windDirection:model.wind_direction_10m,rain:model.precipitation,cloud:model.cloud_cover/100,observedAt:model.time*1000,fetchedAt:Date.now(),source:'Open-Meteo · model (stanice nedostupná nebo zastaralá)',cloudSource:'Open-Meteo · modelová oblačnost',status:'fallback',stale:Date.now()-model.time*1000>3600000};
    else if(station)cached=station;
    else cached={...cached,fetchedAt:Date.now(),stale:true,status:cached.observedAt?'fallback':'unavailable'};
    return cached;
  })();
  try{return await pending;}finally{pending=undefined;}
}
