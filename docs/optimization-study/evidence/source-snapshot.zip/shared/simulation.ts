import RAPIER from '@dimforge/rapier3d-compat';
import { B6_BOXES, BUILDINGS, BOUNDS, SPAWN, GROUND_RECTS } from './world';
import type { Vec3, Input } from './types';
let initialized:Promise<void>|undefined;
export const initPhysics=()=>initialized??=RAPIER.init();
export class Simulation {
  world:RAPIER.World;
  actors=new Map<string,Actor>();
  constructor(){
    this.world=new RAPIER.World({x:0,y:-18,z:0});this.world.timestep=1/30;
    // Ground outside B6, allowing a basement beneath its footprint.
    for(const {x,z,w,d} of GROUND_RECTS){
      const minX=Math.max(x-w/2,BOUNDS.minX-5),maxX=Math.min(x+w/2,BOUNDS.maxX+5),minZ=Math.max(z-d/2,BOUNDS.minZ-5),maxZ=Math.min(z+d/2,BOUNDS.maxZ+5);
      for(let tx=minX;tx<maxX;tx+=20)for(let tz=minZ;tz<maxZ;tz+=20){const tw=Math.min(20,maxX-tx),td=Math.min(20,maxZ-tz);this.solid(tx+tw/2,-.5,tz+td/2,tw+.025,1,td+.025);}
    }
    for(const b of BUILDINGS){
      if(b.name.endsWith('blok 6'))continue;
      for(let i=1;i<b.points.length;i++){
        const [x,z]=b.points[i-1],[nx,nz]=b.points[i];const length=Math.hypot(nx-x,nz-z);if(length<.2)continue;
        this.solid((x+nx)/2,b.height/2,(z+nz)/2,.5,b.height,length,Math.atan2(nx-x,nz-z));
      }
    }
    for(const b of B6_BOXES)this.solid(b.x,b.y,b.z,b.w,b.h,b.d,b.yaw);
    // Four boundary rails, beyond the campus paths.
    this.solid(BOUNDS.minX-1,2,-15,1,5,400);this.solid(BOUNDS.maxX+1,2,-15,1,5,400);this.solid(100,2,BOUNDS.minZ-1,600,5,1);this.solid(100,2,BOUNDS.maxZ+1,600,5,1);
    this.world.step();
  }
  solid(x:number,y:number,z:number,w:number,h:number,d:number,yaw=0){
    return this.world.createCollider(RAPIER.ColliderDesc.cuboid(w/2,h/2,d/2).setTranslation(x,y,z).setRotation({x:0,y:Math.sin(yaw/2),z:0,w:Math.cos(yaw/2)}));
  }
  add(id:string,p:Vec3=SPAWN){const actor=new Actor(this,id,p);this.actors.set(id,actor);return actor;}
  remove(id:string){const a=this.actors.get(id);if(a){this.world.removeRigidBody(a.body);this.world.removeCharacterController(a.controller);this.actors.delete(id);}}
  tick(){this.world.step();}
  dispose(){this.world.free();}
}
export class Actor {
  body:RAPIER.RigidBody;collider:RAPIER.Collider;controller:RAPIER.KinematicCharacterController;
  yaw=0;speed=0;vertical=0;vehicle=false; grounded=false;
  constructor(public sim:Simulation,public id:string,p:Vec3){
    this.body=sim.world.createRigidBody(RAPIER.RigidBodyDesc.kinematicPositionBased().setTranslation(p.x,p.y,p.z));
    this.collider=sim.world.createCollider(RAPIER.ColliderDesc.capsule(.5,.3),this.body);
    this.controller=sim.world.createCharacterController(.02);this.controller.enableAutostep(.22,.2,false);this.controller.enableSnapToGround(.25);this.controller.setSlideEnabled(true);
  }
  get position(){return this.body.translation();}
  setPosition(p:Vec3){this.body.setTranslation(p,true);this.body.setNextKinematicTranslation(p);this.sim.world.propagateModifiedBodyPositionsToColliders();this.vertical=0;this.grounded=false;}
  setVehicle(enabled:boolean){
    this.vehicle=enabled;this.speed=0;this.sim.world.removeCollider(this.collider,true);
    this.collider=this.sim.world.createCollider(enabled?RAPIER.ColliderDesc.cuboid(.88,.6,1.8):RAPIER.ColliderDesc.capsule(.5,.3),this.body);
    const p=this.position;this.setPosition({x:p.x,y:enabled?.65:1,z:p.z});
  }
  step(input:Input,dt=1/30){
    let dx=0,dz=0;
    if(this.vehicle){
      const target=input.z*12;this.speed+=(target-this.speed)*Math.min(1,dt*(input.z?2.6:4));
      this.yaw+=input.x*dt*1.4*Math.min(1,Math.abs(this.speed)/2)*Math.sign(this.speed||1);
      dx=Math.sin(this.yaw)*this.speed*dt;dz=Math.cos(this.yaw)*this.speed*dt;
      this.body.setRotation({x:0,y:Math.sin(this.yaw/2),z:0,w:Math.cos(this.yaw/2)},true);
    }else{
      const n=Math.max(1,Math.hypot(input.x,input.z)),speed=4.6;
      dx=input.x/n*speed*dt;dz=input.z/n*speed*dt;this.speed=Math.hypot(dx,dz)/dt;
      if(this.speed>.1)this.yaw=Math.atan2(dx,dz);
    }
    if(this.grounded){this.vertical=-.3;if(input.jump&&!this.vehicle)this.vertical=6;}
    this.vertical=Math.max(-20,this.vertical-18*dt);
    this.controller.computeColliderMovement(this.collider,{x:dx,y:this.vertical*dt,z:dz},undefined,undefined,c=>c!==this.collider);
    const delta=this.controller.computedMovement(),p=this.position;
    this.grounded=this.controller.computedGrounded();if(this.grounded&&this.vertical<0)this.vertical=0;
    this.body.setNextKinematicTranslation({x:p.x+delta.x,y:p.y+delta.y,z:p.z+delta.z});
    if(p.y<-8)this.setPosition(SPAWN);
  }
}
