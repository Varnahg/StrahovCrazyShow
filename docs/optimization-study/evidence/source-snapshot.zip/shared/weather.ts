import { getPosition } from 'suncalc';
export type Weather = { temperature:number|null;wind:number;windDirection:number;rain:number;cloud:number;observedAt:number|null;fetchedAt:number;source:string;cloudSource:string;stale:boolean;status:'live'|'fallback'|'unavailable' };
export function sunState(time=Date.now()){
  const sun=getPosition(new Date(time),50.08065,14.39175);
  const altitude=sun.altitude*Math.PI/180,azimuth=sun.azimuth*Math.PI/180;
  const daylight=Math.max(0,Math.min(1,(altitude+.12)/.35));
  return {altitude,azimuth,daylight,x:Math.sin(azimuth)*Math.cos(altitude),y:Math.sin(altitude),z:-Math.cos(azimuth)*Math.cos(altitude)};
}
export function parseStation(html:string,now=Date.now()):Weather {
  const decoded=html.replace(/&#(\d+);/g,(_,n)=>String.fromCharCode(Number(n))).replaceAll('&nbsp;',' ');
  const rows=[...decoded.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)].map(m=>m[1].replace(/<[^>]*>/g,' ').replace(/\s+/g,' '));
  const read=(label:string)=>{const row=rows.find(r=>r.includes(label));const match=row?.slice(row.indexOf(label)+label.length).match(/(-?\d+(?:\.\d+)?)/);return match?Number(match[1]):null;};
  const stamp=decoded.match(/\b(20\d\d-\d\d-\d\d) (\d\d:\d\d:\d\d)\b/);
  let observedAt:number|null=null;
  if(stamp){
    // Interpret station clock in Prague, including summer/winter offset.
    const utc=Date.parse(stamp[1]+'T'+stamp[2]+'Z');
    const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/Prague',timeZoneName:'shortOffset'}).formatToParts(utc);
    const offset=Number(parts.find(p=>p.type==='timeZoneName')?.value.replace('GMT',''))||1;
    observedAt=utc-offset*3600000;
  }
  const temperature=read('Teplota:'),wind=read('Charakter větru:')??0,rain=read('Intenzita deště:')??0;
  if(temperature===null||!observedAt)throw new Error('Stanice neobsahuje čitelné měření a čas.');
  const cloud=decoded.includes('fc-icon-partlycloudy')?.45:decoded.includes('fc-icon-cloudy')?.9:.2;
  return {temperature,wind,windDirection:110,rain,cloud,observedAt,fetchedAt:now,source:'Meteostanice Silicon Hill',cloudSource:'Orientační ikona předpovědi stanice',stale:now-observedAt>30*60000||observedAt>now+5*60000,status:'live'};
}
