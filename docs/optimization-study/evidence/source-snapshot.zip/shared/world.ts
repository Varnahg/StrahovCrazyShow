import rawMap from './data/map.json';
import type { WorldMap, Place, Vec3 } from './types';
export const MAP = rawMap as unknown as WorldMap;
export const BOUNDS = {minX:-130,maxX:345,minZ:-165,maxZ:130};
export const SPAWN:Vec3 = {x:22,y:1,z:-14};
export const GROUND_RECTS = [
  {x:-253.5,z:0,w:493,d:1000}, {x:258,z:0,w:484,d:1000},
  {x:4.5,z:240,w:23,d:520}, {x:4.5,z:-295,w:23,d:410},
  {x:-3.5,z:-83,w:7,d:14}, {x:-3.5,z:-45,w:7,d:50}
];
export const PLACES:Place[] = [
  {id:'b6',name:'Blok 6',x:-8,z:-73,description:'Vstup do B6. Rozvržení vychází z OSM a orientačního plánu SH; rozměry interiéru jsou přibližné.',source:'https://wiki.sh.cvut.cz/kolej/bloky/blok_6'},
  {id:'club6',name:'Klubovna B6',x:-3,z:-73,floor:4.5,description:'Klubovna mezi 4. a 5. patrem. Virtuální interiér je demonstrační.',source:'https://wiki.sh.cvut.cz/kolej/bloky/blok_6#klubovna'},
  {id:'seven',name:'Sedmička / Klub 007',x:41,z:-72,description:'Hudební klub na B7. Akce v tomto demu jsou fiktivní.',source:'https://www.siliconhill.cz/koleje-strahov'},
  {id:'rko',name:'R-ko',x:54,z:-11,description:'Společenské místo v centru areálu. Označení vyžaduje kontrolu přesného vstupu podle aktuálních fotografií.',source:'https://www.siliconhill.cz/koleje-strahov'},
  {id:'sports',name:'Mezi bloky',x:130,z:12,description:'Otevřený prostor pro společné herní aktivity.'}
];
export const HUNT_POINTS = [{x:21,z:-16},{x:43,z:-42},{x:126,z:12},{x:225,z:24},{x:270,z:-34}];
export type Box = {x:number;y:number;z:number;w:number;h:number;d:number;yaw?:number;kind:'wall'|'floor'|'stair'|'bench'};
export const B6_BOXES:Box[] = [];
const box=(x:number,y:number,z:number,w:number,h:number,d:number,kind:Box['kind']='wall')=>B6_BOXES.push({x,y,z,w,h,d,kind});
// Schematic B6 fit to the actual OSM footprint, 0–5 NP and basement.
// Dimensions, door locations and stair geometry await an on-site survey.
for(let level=-1;level<=5;level++) {
  const y=level*3;
  // Split corridor slabs leave a stair opening at the west centre.
  box(3,y-.15,-55,6,.3,70,'floor');box(13,y-.15,-55,6,.3,70,'floor');
  box(8,y-.15,-45,4,.3,50,'floor');box(8,y-.15,-84,4,.3,12,'floor');
  box(-3.5,y-.15,-73,7,.3,6,'floor');
  box(16,y+1.45,-55,.35,2.9,70); box(8,y+1.45,-90,16,2.9,.35);box(8,y+1.45,-20,16,2.9,.35);
  box(0,y+1.45,-46, .35,2.9,48);box(0,y+1.45,-83,.35,2.9,14);
  if(level!==0)box(-7,y+1.45,-73,.35,2.9,6);box(-3.5,y+1.45,-76,7,2.9,.3);box(-3.5,y+1.45,-70,7,2.9,.3);
  // Open entry at ground level, rooms opening into a central corridor.
  if(level===0) { B6_BOXES.pop(); box(-5,y+1.45,-70,4,2.9,.3); }
  for(const side of [3,13]) for(let row=0;row<12;row++) {
    const z=-23-row*5.4;
    box(side,y+1.45,z,6,2.9,.15);
    const wallX=side===3?6:10;
    box(wallX,y+1.45,z-2.9,.16,2.9,3.8);box(wallX,y+2.65,z-5,.16,.5,1.6);
  }
  if(level<5) {
    // Ramp-like small steps: full-width central stairs, 3 m rise / 8 m run.
    for(let step=0;step<20;step++)box(8,y+(step+1)*.15-.075,-78+step*.4,3.2,.15,.4,'stair');
  }
}
box(8,18,-55,16,.25,70,'floor');box(-3.5,18,-73,7,.25,6,'floor');
// Door in west lobby and passage to staircase.
export function blockNumber(name:string) { const m=name.match(/blok (\d+)/);return m?Number(m[1]):null; }
export function buildingVisible(points:[number,number][]) { return points.some(([x,z])=>x>BOUNDS.minX-25&&x<BOUNDS.maxX+25&&z>BOUNDS.minZ-25&&z<BOUNDS.maxZ+25); }
export const BUILDINGS=MAP.buildings.filter(b=>buildingVisible(b.points));
export function nearestPlace(x:number,z:number) { return [...PLACES].sort((a,b)=>Math.hypot(a.x-x,a.z-z)-Math.hypot(b.x-x,b.z-z))[0]; }
export function zoneAt(p:Vec3) { return p.x>-8&&p.x<17&&p.z>-91&&p.z<-19 ? `b6:${Math.round(p.y/3)}`:'outside'; }
