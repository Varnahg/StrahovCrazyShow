import { Engine, Scene, Color3, Color4, Vector3, UniversalCamera, HemisphericLight, DirectionalLight, PointLight, MeshBuilder, Mesh, TransformNode, StandardMaterial, VertexData, DynamicTexture, Ray, Matrix, ParticleSystem, Texture } from '@babylonjs/core';
import earcut from 'earcut';
import { Simulation, initPhysics, type Actor } from '../shared/simulation';
import { BUILDINGS, B6_BOXES, MAP, PLACES, SPAWN, HUNT_POINTS, BOUNDS, blockNumber, zoneAt, GROUND_RECTS } from '../shared/world';
import { sunState, type Weather } from '../shared/weather';
import type { Player, Profile, Input, AvatarConfig } from '../shared/types';

export type GameStats={fps:number;triangles:number;drawCalls:number;x:number;y:number;z:number;speed:number;vehicle:boolean;zone:string;hint:string;labels:{id:string;name:string;x:number;y:number;emote:string}[]};
type Avatar={root:TransformNode;left:TransformNode;right:TransformNode;arm:TransformNode;profile:string;target:Player};
export class Game {
  engine:Engine;scene:Scene;camera:UniversalCamera;sim!:Simulation;actor!:Actor;localId='guest';
  onInput?:(input:Input)=>void;onAction?:(action:string,data?:unknown)=>void;onStats?:(stats:GameStats)=>void;onNotice?:(message:string)=>void;
  network=false;ready=false;firstPerson=false;quality='low';keys=new Set<string>();avatars=new Map<string,Avatar>();
  yaw=Math.PI;pitch=.28;distance=8;seq=0;accumulator=0;lastStats=0;profile:Profile;localPlayer:Player;
  weather?:Weather;sun:DirectionalLight;ambient:HemisphericLight;clouds:Mesh[]=[];lamps:StandardMaterial;rain?:ParticleSystem;
  car:TransformNode;parkedCar:TransformNode;found=new Set<string>();huntMeshes:Mesh[]=[];soloDelivery=0;rewarded=false;
  materials=new Map<string,StandardMaterial>();staticMeshes=new Map<StandardMaterial,Mesh[]>();lights:PointLight[]=[];disposed=false;timeOverride:number|null=null;frames:number[]=[];
  constructor(public canvas:HTMLCanvasElement,profile:Profile){
    this.profile=profile;this.engine=new Engine(canvas,true,{stencil:true,preserveDrawingBuffer:false},false);this.engine.setHardwareScalingLevel(1.3);
    this.scene=new Scene(this.engine);this.scene.useRightHandedSystem=true;this.scene.clearColor=new Color4(.58,.72,.73,1);this.scene.fogMode=Scene.FOGMODE_EXP2;this.scene.fogDensity=.0018;
    this.camera=new UniversalCamera('follow',new Vector3(22,4,-6),this.scene);this.camera.minZ=.08;this.camera.maxZ=700;this.camera.fov=.85;
    this.ambient=new HemisphericLight('sky',new Vector3(0,1,0),this.scene);this.ambient.intensity=.85;this.ambient.groundColor=new Color3(.27,.32,.24);
    this.sun=new DirectionalLight('sun',new Vector3(-1,-1,.2),this.scene);this.sun.intensity=1.2;
    this.lamps=this.mat('#f7d590');this.lamps.emissiveColor=Color3.FromHexString('#f7d590').scale(.4);
    this.buildWorld();this.car=this.makeCar();this.car.setEnabled(false);this.parkedCar=this.makeCar();this.parkedCar.position.set(25,0,-9);
    this.localPlayer={...profile,...SPAWN,id:'guest',yaw:0,emote:'',vehicle:false,speed:0,ack:0,zone:'outside'};
    window.addEventListener('keydown',this.keyDown);window.addEventListener('keyup',this.keyUp);window.addEventListener('blur',this.blur);document.addEventListener('mousemove',this.mouse);canvas.addEventListener('click',this.lock);canvas.addEventListener('wheel',this.wheel,{passive:true});window.addEventListener('resize',this.resize);
  }
  async start(){await initPhysics();if(this.disposed)return;this.sim=new Simulation();this.actor=this.sim.add('local');this.ready=true;this.updatePlayers([this.localPlayer]);this.engine.runRenderLoop(()=>this.frame());}
  mat(hex:string){if(this.materials.has(hex))return this.materials.get(hex)!;const m=new StandardMaterial('m'+hex,this.scene);m.diffuseColor=Color3.FromHexString(hex);m.specularColor=new Color3(.08,.08,.08);this.materials.set(hex,m);return m;}
  box(name:string,x:number,y:number,z:number,w:number,h:number,d:number,color:string,staticGroup=true,yaw=0){const m=MeshBuilder.CreateBox(name,{width:w,height:h,depth:d},this.scene);m.position.set(x,y,z);m.rotation.y=yaw;m.material=this.mat(color);if(staticGroup){const material=m.material as StandardMaterial;const group=this.staticMeshes.get(material)||[];group.push(m);this.staticMeshes.set(material,group);}return m;}
  sphere(name:string,x:number,y:number,z:number,size:number,color:string){const m=MeshBuilder.CreateSphere(name,{diameter:size,segments:6},this.scene);m.position.set(x,y,z);m.material=this.mat(color);return m;}
  label(text:string,x:number,y:number,z:number,width=4){const texture=new DynamicTexture('label',{width:512,height:128},this.scene,false);texture.hasAlpha=true;texture.drawText(text,null,87,'bold 62px sans-serif','#f2f8ed','#193d32',true);const material=new StandardMaterial('sign',this.scene);material.diffuseTexture=texture;material.emissiveTexture=texture;material.specularColor=Color3.Black();material.backFaceCulling=false;const m=MeshBuilder.CreatePlane('label',{width,height:width/4},this.scene);m.position.set(x,y,z);m.material=material;m.billboardMode=Mesh.BILLBOARDMODE_Y;m.isPickable=false;return m;}
  polygonBuilding(points:[number,number][],height:number,color:string){
    const positions:number[]=[],indices:number[]=[],uvs:number[]=[];
    for(let i=1;i<points.length;i++){
      const [x,z]=points[i-1],[nx,nz]=points[i],start=positions.length/3;
      positions.push(x,0,z,nx,0,nz,nx,height,nz,x,height,z);indices.push(start,start+1,start+2,start,start+2,start+3);uvs.push(0,0,1,0,1,1,0,1);
    }
    const flat=points.slice(0,-1).flat(),roofStart=positions.length/3;
    for(let i=0;i<flat.length;i+=2){positions.push(flat[i],height,flat[i+1]);uvs.push(flat[i]/15,flat[i+1]/15);}
    indices.push(...earcut(flat).map(i=>i+roofStart));const data=new VertexData();data.positions=positions;data.indices=indices;data.uvs=uvs;const normals:number[]=[];VertexData.ComputeNormals(positions,indices,normals);data.normals=normals;
    const mesh=new Mesh('building',this.scene);data.applyToMesh(mesh);const material=this.mat(color);material.backFaceCulling=false;mesh.material=material;mesh.metadata={solid:true};mesh.freezeWorldMatrix();return mesh;
  }
  buildWorld(){
    for(const {x,z,w,d}of GROUND_RECTS)this.box('ground',x,-.08,z,w,.16,d,'#7b9163');
    // Only actual downloaded roads inside the campus; no imaginary connecting routes.
    for(const path of MAP.paths){const width=['residential','service','unclassified','secondary','tertiary'].includes(path.kind)?6:path.kind==='footway'?1.8:2.5;
      for(let i=1;i<path.points.length;i++){const[a,z]=path.points[i-1],[b,nz]=path.points[i];const x=(a+b)/2,cz=(z+nz)/2;if(x<BOUNDS.minX||x>BOUNDS.maxX||cz<BOUNDS.minZ||cz>BOUNDS.maxZ)continue;this.box('path',x,.015,cz,width,.035,Math.hypot(b-a,nz-z),width>3?'#a7ada1':'#c2bca4',true,Math.atan2(b-a,nz-z));}
    }
    const palettes=['#d0cdb9','#e6d5b1','#c8c9b3','#d4c2a7'];
    for(const b of BUILDINGS){const number=blockNumber(b.name);if(number===6)continue;
      this.polygonBuilding(b.points,b.height,number?palettes[number%4]:'#c4c8b8');
      if(number){
        for(let edge=1;edge<b.points.length;edge++){const[a,z]=b.points[edge-1],[nx,nz]=b.points[edge];const length=Math.hypot(nx-a,nz-z);if(length<8)continue;
          const yaw=Math.atan2(nx-a,nz-z);for(let y=1.5;y<b.height-.4;y+=3)for(let t=2;t<length-1;t+=2.7){const f=t/length;this.box('window',a+(nx-a)*f+Math.cos(yaw)*.22,y,z+(nz-z)*f-Math.sin(yaw)*.22,.12,1.35,1.25,'#304e50',true,yaw);}
        }
        const xs=b.points.map(p=>p[0]),zs=b.points.map(p=>p[1]);this.label('B'+number,(Math.min(...xs)+Math.max(...xs))/2,b.height+2,(Math.min(...zs)+Math.max(...zs))/2,5);
      }
    }
    for(const b of B6_BOXES)this.box('B6 '+b.kind,b.x,b.y,b.z,b.w,b.h,b.d,b.kind==='floor'?'#b9aa8c':b.kind==='stair'?'#b0b4a4':'#dbd6bd');
    for(let floor=0;floor<=5;floor++){
      for(let row=0;row<12;row++)for(const x of [-.22,16.22])this.box('B6 window',x,floor*3+1.65,-25-row*5.3,.09,1.4,1.8,'#345458');
      this.label(floor+' NP',-5,floor*3+1.7,-73,1.7);
      // Representative room furniture; instanced-looking repeated geometry, merged by material.
      for(const z of [-28,-44,-60,-84]){
        this.box('bed',2.2,floor*3+.4,z,1.2,.7,2.1,'#537d70');this.box('mattress',2.2,floor*3+.79,z,1.22,.12,2.1,'#ede6d1');this.box('desk',4.4,floor*3+.85,z,1.2,.12,.7,'#b88e5e');
      }
      if(floor>0)this.box('light',8,floor*3+2.6,-47,.4,.08,2,'#f7d590');
    }
    this.label('B6',8,20,-55,6);this.label('KLUBOVNA',-3.5,15.9,-73,3);this.label('VSTUP B6',-8,3,-73,3);
    // Demo club furnishings, fitted into the actual west projection.
    this.box('club table',-3.2,15.8,-73,2,.12,1.2,'#a98558');this.box('club sofa',-5.4,15.4,-74.2,1,.8,2,'#57796e');
    for(const p of PLACES)if(p.id!=='club6'&&p.id!=='b6')this.label(p.name,p.x,3.4,p.z,5.5);
    for(const[i,p]of HUNT_POINTS.entries()){const m=MeshBuilder.CreatePolyhedron('hunt'+i,{type:1,size:.4},this.scene);m.position.set(p.x,1.2,p.z);m.material=this.mat('#d4f36a');this.huntMeshes.push(m);}
    let seed=79;const rand=()=>{seed=(seed*16807)%2147483647;return(seed-1)/2147483646;};
    for(let i=0;i<90;i++){const x=BOUNDS.minX+rand()*(BOUNDS.maxX-BOUNDS.minX),z=BOUNDS.minZ+rand()*(BOUNDS.maxZ-BOUNDS.minZ);if(BUILDINGS.some(b=>{const xs=b.points.map(p=>p[0]),zs=b.points.map(p=>p[1]);return x>Math.min(...xs)-6&&x<Math.max(...xs)+6&&z>Math.min(...zs)-6&&z<Math.max(...zs)+6;}))continue;if(x>0&&x<260&&z>-30&&z<40)continue;
      this.box('tree trunk',x,1.1,z,.3,2.2,.3,'#6e6249');const crown=this.sphere('tree crown',x,3.7,z,4+rand()*2,'#526f4d');const group=this.staticMeshes.get(crown.material as StandardMaterial)||[];group.push(crown);this.staticMeshes.set(crown.material as StandardMaterial,group);
    }
    for(let x=20;x<290;x+=45){this.box('lamp',x,2.5,2,.12,5,.12,'#52625a');const lamp=this.box('lamp glow',x,5,2,.7,.15,.5,'#f7d590');const light=new PointLight('lamp',new Vector3(x,4.7,2),this.scene);light.diffuse=new Color3(1,.85,.57);light.range=16;light.intensity=.7;this.lights.push(light);}
    for(let x=40;x<250;x+=50){this.box('bench',x,.5,18,2,.15,.65,'#886c4a');this.box('bench back',x,.85,18.3,2,.6,.12,'#886c4a');}
    // Merge thousands of static pieces by material into a handful of draw calls.
    for(const meshes of this.staticMeshes.values()){const merged=Mesh.MergeMeshes(meshes,true,true,undefined,false,true);if(merged){merged.metadata={solid:true};merged.freezeWorldMatrix();}}this.staticMeshes.clear();
    for(let i=0;i<24;i++){const puffs:Mesh[]=[];for(let j=0;j<4;j++){const m=this.sphere('cloud',-200+i*32+j*5,85+(i%4)*6,-160+(i%5)*70,20,'#ecede1');m.scaling.set(1.5,.35,1);puffs.push(m);}const cloud=Mesh.MergeMeshes(puffs,true,true)!;cloud.isPickable=false;this.clouds.push(cloud);}
  }
  makeCar(){const root=new TransformNode('car',this.scene);const parts=[this.box('body',0,.65,0,1.7,.65,3.5,'#d9e997',false),this.box('cabin',0,1.15,-.15,1.45,.7,1.8,'#345557',false),this.box('roof',0,1.55,-.15,1.55,.12,1.9,'#d9e997',false),this.box('front',0,.8,1.76,1.3,.16,.04,'#fff1c5',false),this.box('tail',0,.8,-1.76,1.3,.16,.04,'#dd7b62',false)];
    for(const x of [-.85,.85])for(const z of [-1.1,1.1]){const wheel=MeshBuilder.CreateCylinder('wheel',{diameter:.65,height:.2,tessellation:10},this.scene);wheel.position.set(x,.35,z);wheel.rotation.z=Math.PI/2;wheel.material=this.mat('#293b37');parts.push(wheel);}for(const p of parts)p.parent=root;return root;}
  makeAvatar(p:Player):Avatar {
    const root=new TransformNode('avatar '+p.id,this.scene),config=p.avatar;const body=this.box('torso',0,.85,0,.57,.7,.35,config.shirt,false);body.parent=root;
    const head=this.sphere('head',0,1.48,0,.49,config.skin);head.scaling.x=.9+config.face*.15;head.parent=root;
    const hair=this.sphere('hair',0,1.64,-.025,.49,config.hair);hair.scaling.set(1,.45,1);hair.parent=root;
    const left=new TransformNode('legL',this.scene),right=new TransformNode('legR',this.scene);left.position.set(-.17,.52,0);right.position.set(.17,.52,0);left.parent=root;right.parent=root;
    for(const leg of [left,right]){const m=this.box('leg',0,-.28,0,.23,.56,.25,config.trousers,false);m.parent=leg;const shoe=this.box('shoe',0,-.52,.04,.25,.13,.37,'#243732',false);shoe.parent=leg;}
    const arm=new TransformNode('arm',this.scene);arm.position.set(-.4,1.1,0);arm.parent=root;const a=this.box('arm',0,-.23,0,.18,.58,.23,config.skin,false);a.parent=arm;const a2=this.box('arm2',.4,.87,0,.18,.58,.23,config.skin,false);a2.parent=root;
    if(config.glasses)for(const x of [-.12,.12]){const glass=this.box('glasses',x,1.49,.23,.2,.11,.025,'#283f38',false);glass.parent=root;}
    if(config.beard){const beard=this.sphere('beard',0,1.34,.1,.34,config.hair);beard.scaling.y=.6;beard.parent=root;}
    const height=[1,1.04,.96,1.02,.98,1][config.preset];root.scaling.y=height;return {root,left,right,arm,profile:JSON.stringify(config),target:p};
  }
  updatePlayers(players:Player[]){
    const ids=new Set(players.map(p=>p.id));for(const[id,a]of this.avatars)if(!ids.has(id)){a.root.dispose(false,false);this.avatars.delete(id);}
    for(const p of players){let a=this.avatars.get(p.id);if(a&&a.profile!==JSON.stringify(p.avatar)){a.root.dispose(false,false);this.avatars.delete(p.id);a=undefined;}if(!a){a=this.makeAvatar(p);this.avatars.set(p.id,a);a.root.position.set(p.x,p.y-.8,p.z);}a.target={...p};}
  }
  setProfile(profile:Profile){this.profile=profile;this.localPlayer={...this.localPlayer,...profile};const a=this.avatars.get(this.localId);if(a)this.updatePlayers([...this.avatars.values()].map(a=>a.target.id===this.localId?{...a.target,...profile}:a.target));}
  setLocalId(id:string){const old=this.localId;this.localId=id;const a=this.avatars.get(old);if(a){a.root.dispose();this.avatars.delete(old);}this.localPlayer.id=id;}
  syncMotion(rows:any[]){for(const row of rows){const[id,x,y,z,yaw,speed,ack,vehicle,zone]=row;const a=this.avatars.get(id);if(a)Object.assign(a.target,{x,y,z,yaw,speed,ack,vehicle:!!vehicle,zone});if(id===this.localId&&this.actor){if(this.actor.vehicle!==!!vehicle)this.actor.setVehicle(!!vehicle);const current=this.actor.position;const error=Math.hypot(x-current.x,y-current.y,z-current.z);if(error>.75)this.actor.setPosition({x,y,z});this.actor.yaw=yaw;}}}
  setWeather(weather:Weather){this.weather=weather;this.scene.fogDensity=weather.rain>.1?.006:.0018;}
  setQuality(quality:string){this.quality=quality;this.engine.setHardwareScalingLevel(quality==='low'?1.3:1);this.scene.fogDensity=quality==='low'?.0025:.0015;}
  interact(){
    if(!this.ready)return;const p=this.actor.position;
    const nearby=HUNT_POINTS.findIndex((h,i)=>!this.found.has(String(i))&&Math.hypot(h.x-p.x,h.z-p.z)<4);
    if(nearby>=0){if(this.network)this.onAction?.('find',nearby);else{this.found.add(String(nearby));this.huntMeshes[nearby].setEnabled(false);this.onNotice?.(`Nalezeno ${this.found.size}/${HUNT_POINTS.length}`);if(this.found.size===HUNT_POINTS.length)this.onAction?.('reward','Průzkumník kopce');}return;}
    if(this.network){this.onAction?.('vehicle');return;}
    if(this.actor.vehicle){const p=this.actor.position;this.actor.setVehicle(false);this.actor.setPosition({x:p.x+2,y:1,z:p.z});}
    else if(Math.hypot(p.x-this.parkedCar.position.x,p.z-this.parkedCar.position.z)<5){this.actor.setPosition({x:this.parkedCar.position.x,y:.65,z:this.parkedCar.position.z});this.actor.setVehicle(true);}
    else if(this.soloDelivery===0&&Math.hypot(p.x-22,p.z+14)<6){this.soloDelivery=1;this.onNotice?.('Balíček vyzvednutý. Dones jej ke vstupu B6 (značka na mapě).');}
    else if(this.soloDelivery===1&&Math.hypot(p.x+8,p.z+73)<5){this.soloDelivery=2;this.onNotice?.('Doručeno! Odemčená kosmetická odměna.');this.onAction?.('reward','Strahovský kurýr');}
    else this.onNotice?.('Přibliž se k autu, značce nebo místu úkolu.');
  }
  setFound(ids:string[]){this.found=new Set(ids);this.huntMeshes.forEach((m,i)=>m.setEnabled(!this.found.has(String(i))));}
  resize=()=>this.engine.resize();blur=()=>this.keys.clear();
  keyDown=(e:KeyboardEvent)=>{if((e.target as HTMLElement)?.closest('input,textarea,select'))return;if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();this.keys.add(e.code);if(!e.repeat){if(e.code==='KeyE')this.interact();if(e.code==='KeyV')this.firstPerson=!this.firstPerson;if(e.code==='KeyR'){if(this.network)this.onAction?.('respawn');else{this.actor.setVehicle(false);this.actor.setPosition(SPAWN);}}if(e.code==='KeyM')window.dispatchEvent(new CustomEvent('toggle-map'));}};
  keyUp=(e:KeyboardEvent)=>this.keys.delete(e.code);
  lock=()=>{this.canvas.focus();this.canvas.requestPointerLock?.();};
  mouse=(e:MouseEvent)=>{if(document.pointerLockElement===this.canvas){this.yaw-=e.movementX*.003;this.pitch=Math.max(-.55,Math.min(1.1,this.pitch+e.movementY*.002));}};
  wheel=(e:WheelEvent)=>{this.distance=Math.max(3,Math.min(15,this.distance+e.deltaY*.006));};
  frame(){
    if(!this.ready||this.disposed)return;const dt=Math.min(.1,this.engine.getDeltaTime()/1000);this.accumulator+=dt;
    const forward=(this.keys.has('KeyW')||this.keys.has('ArrowUp')?1:0)-(this.keys.has('KeyS')||this.keys.has('ArrowDown')?1:0),side=(this.keys.has('KeyD')||this.keys.has('ArrowRight')?1:0)-(this.keys.has('KeyA')||this.keys.has('ArrowLeft')?1:0);
    while(this.accumulator>=1/30){const input:Input={x:this.actor.vehicle?side:Math.sin(this.yaw)*forward+Math.cos(this.yaw)*side,z:this.actor.vehicle?forward:Math.cos(this.yaw)*forward-Math.sin(this.yaw)*side,yaw:this.yaw,jump:this.keys.has('Space'),seq:++this.seq};this.actor.step(input);this.sim.tick();this.onInput?.(input);this.accumulator-=1/30;}
    const pos=this.actor.position;Object.assign(this.localPlayer,pos,{yaw:this.actor.yaw,speed:this.actor.speed,vehicle:this.actor.vehicle,zone:zoneAt(pos)});const self=this.avatars.get(this.localId);if(self)Object.assign(self.target,this.localPlayer);
    const time=performance.now()/1000;
    for(const[id,a]of this.avatars){const p=a.target,target=new Vector3(p.x,p.y-.8,p.z);a.root.position=Vector3.Lerp(a.root.position,target,id===this.localId?1:Math.min(1,dt*14));a.root.rotation.y=p.yaw;a.root.setEnabled(!p.vehicle&&!(id===this.localId&&this.firstPerson));const move=Math.sin(time*10)*Math.min(1,p.speed/4)*.45;a.left.rotation.x=move;a.right.rotation.x=-move;a.arm.rotation.x=p.emote?Math.sin(time*8)*.35-2:-move*.5;}
    const driving=[...this.avatars.values()].find(a=>a.target.vehicle);this.car.setEnabled(this.actor.vehicle||!!driving);this.parkedCar.setEnabled(!this.actor.vehicle&&!driving);
    if(this.actor.vehicle){this.car.position.set(pos.x,pos.y-.6,pos.z);this.car.rotation.y=this.actor.yaw;this.parkedCar.position.copyFrom(this.car.position);}else if(driving){this.car.position.set(driving.target.x,driving.target.y-.6,driving.target.z);this.car.rotation.y=driving.target.yaw;}
    const target=new Vector3(pos.x,pos.y+(this.actor.vehicle?.7:.6),pos.z);
    let desired=this.firstPerson&&!this.actor.vehicle?target.add(new Vector3(0,.1,0)):target.add(new Vector3(-Math.sin(this.yaw)*this.distance,2+this.pitch*4,-Math.cos(this.yaw)*this.distance));
    if(!this.firstPerson){const delta=desired.subtract(target),length=delta.length();const hit=this.scene.pickWithRay(new Ray(target,delta.normalize(),length),m=>m.metadata?.solid===true);if(hit?.hit&&hit.distance>0)desired=target.add(delta.scale(Math.max(.5,hit.distance-.3)));}
    this.camera.position=Vector3.Lerp(this.camera.position,desired,Math.min(1,dt*12));this.camera.setTarget(this.firstPerson?target.add(new Vector3(Math.sin(this.yaw),-this.pitch,Math.cos(this.yaw))):target);
    this.huntMeshes.forEach((m,i)=>{m.rotation.y+=dt;m.position.y=1.3+Math.sin(time*2+i)*.12;});
    const sun=sunState(this.timeOverride??Date.now()),cloud=this.weather?.cloud??.4;
    this.sun.direction.set(-sun.x,-sun.y,-sun.z);this.sun.intensity=sun.daylight*(1.1-cloud*.6);this.ambient.intensity=.27+sun.daylight*.55;
    const sky=Color3.Lerp(new Color3(.025,.055,.10),new Color3(.55-cloud*.16,.70-cloud*.17,.75-cloud*.13),sun.daylight);this.scene.clearColor=new Color4(sky.r,sky.g,sky.b,1);this.scene.fogColor=sky;
    this.lights.forEach(l=>l.intensity=(1-sun.daylight)*1.8);this.clouds.forEach((c,i)=>{c.setEnabled(i<Math.max(2,Math.round(cloud*24)));c.position.x+=dt*(.3+(this.weather?.wind??1)*.3);if(c.position.x>500)c.position.x=-300;});
    this.scene.render();this.frames.push(dt*1000);if(this.frames.length>600)this.frames.shift();
    if(performance.now()-this.lastStats>200){this.lastStats=performance.now();const labels=[];for(const[id,a]of this.avatars){if(id===this.localId||a.target.vehicle)continue;const projected=Vector3.Project(a.root.position.add(new Vector3(0,2.1,0)),Matrix.Identity(),this.scene.getTransformMatrix(),this.camera.viewport.toGlobal(this.engine.getRenderWidth(),this.engine.getRenderHeight()));if(projected.z>0&&projected.z<1)labels.push({id,name:a.target.nickname,x:projected.x/this.engine.getRenderWidth()*100,y:projected.y/this.engine.getRenderHeight()*100,emote:a.target.emote});}
      let hint=this.actor.vehicle?'E · vystoupit z auta':Math.hypot(pos.x-this.parkedCar.position.x,pos.z-this.parkedCar.position.z)<5?'E · nastoupit do auta':'';
      if(HUNT_POINTS.some((h,i)=>!this.found.has(String(i))&&Math.hypot(h.x-pos.x,h.z-pos.z)<4))hint='E · najít značku';
      if(!this.network&&!hint&&this.soloDelivery===0&&Math.hypot(pos.x-22,pos.z+14)<6)hint='E · vyzvednout balíček pro B6';
      if(!this.network&&this.soloDelivery===1)hint='Doruč balíček ke vstupu B6 · E';
      this.onStats?.({fps:Math.round(this.engine.getFps()),triangles:Math.round(this.scene.getActiveIndices()/3),drawCalls:(this.engine as any)._drawCalls?.current??0,...pos,speed:this.actor.speed,vehicle:this.actor.vehicle,zone:zoneAt(pos),hint,labels});
    }
  }
  dispose(){this.disposed=true;window.removeEventListener('keydown',this.keyDown);window.removeEventListener('keyup',this.keyUp);window.removeEventListener('blur',this.blur);document.removeEventListener('mousemove',this.mouse);this.canvas.removeEventListener('click',this.lock);this.canvas.removeEventListener('wheel',this.wheel);window.removeEventListener('resize',this.resize);if(document.pointerLockElement===this.canvas)document.exitPointerLock();this.engine.stopRenderLoop();this.sim?.dispose();this.scene.dispose();this.engine.dispose();}
}
